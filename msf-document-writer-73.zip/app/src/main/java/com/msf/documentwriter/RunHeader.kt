package com.msf.documentwriter

import android.graphics.Canvas
import android.graphics.Paint
import java.io.File

/** The running header of a Word file ("book title + page number" at the top of every page, with a thin line under it). */
object RunHeader {
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF666666.toInt() }
    private val lineP = Paint().apply { color = 0xFF9A9A9A.toInt(); style = Paint.Style.STROKE }

    class Hdr(val text: String, val color: Int, val size: Float)
    private val NONE = Hdr("", 0xFF666666.toInt(), 11f)

    /** Text, colour and size of the page header of a .docx (the page-number field is left out; empty text = no header). */
    fun of(f: File): Hdr = try {
        java.util.zip.ZipFile(f).use { z ->
            val names = z.entries().asSequence().map { it.name }.filter { Regex("word/header\\d*\\.xml").matches(it) }.sorted().toList()
            var best: Hdr = NONE
            for (n in names) {
                val e = z.getEntry(n) ?: continue
                var x = z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
                val dot = RegexOption.DOT_MATCHES_ALL
                x = x.replace(Regex("<w:fldSimple .*?</w:fldSimple>", dot), " ")
                x = x.replace(Regex("<w:fldChar w:fldCharType=\"begin\"/>.*?<w:fldChar w:fldCharType=\"end\"/>", dot), " ")
                val paras = Regex("<w:p[ >].*?</w:p>", dot).findAll(x).map { p ->
                    Regex("<w:t(?: [^>]*)?>(.*?)</w:t>", dot).findAll(p.value).joinToString("") {
                        it.groupValues[1].replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
                    }.trim()
                }.filter { it.isNotEmpty() }.toList()
                val t = paras.joinToString("  ").trim()
                if (t.isNotEmpty()) {
                    val col = Regex("<w:color w:val=\"([0-9A-Fa-f]{6})\"").find(x)?.groupValues?.get(1)?.toIntOrNull(16)?.let { 0xFF000000.toInt() or it } ?: NONE.color
                    val sz = Regex("<w:sz w:val=\"(\\d+)\"").find(x)?.groupValues?.get(1)?.toFloatOrNull()?.div(2f)?.coerceIn(8f, 18f) ?: NONE.size
                    best = Hdr(t.take(200), col, sz)
                    break
                }
            }
            best
        }
    } catch (e: Throwable) { NONE }

    /** Draws the header text (and the page number, when it sits in the header) with a thin line below it. */
    fun draw(c: Canvas, text: String, num: String?, left: Float, right: Float, baseline: Float, size: Float, rtl: Boolean, align: Int, lineW: Float, color: Int = 0xFF666666.toInt(), line: Boolean = true, hAlign: Int = -1) {
        textP.textSize = size
        textP.color = color
        val s = if (num == null) text else if (rtl) "$num  $text" else "$text  $num"
        val a = if (hAlign in 0..2) hAlign else if (num != null) align else if (rtl) 2 else 0
        val x: Float
        when (a) {
            0 -> { textP.textAlign = Paint.Align.LEFT; x = left }
            2 -> { textP.textAlign = Paint.Align.RIGHT; x = right }
            else -> { textP.textAlign = Paint.Align.CENTER; x = (left + right) / 2f }
        }
        c.drawText(s, x, baseline, textP)
        if (!line) return
        lineP.strokeWidth = lineW
        val ly = baseline + size * 0.45f
        c.drawLine(left, ly, right, ly, lineP)
    }

    /** "Header from top" of a .docx in points (w:pgMar w:header), null when the file does not say. */
    fun distOf(f: File): Float? = try {
        java.util.zip.ZipFile(f).use { z ->
            val e = z.getEntry("word/document.xml") ?: return@use null
            val xml = z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
            val m = Regex("<w:pgMar [^>]*>").find(xml)?.value ?: return@use null
            Regex("w:header=\"(\\d+)\"").find(m)?.groupValues?.get(1)?.toFloatOrNull()?.div(20f)?.coerceIn(0f, 200f)
        }
    } catch (e: Throwable) { null }
}
