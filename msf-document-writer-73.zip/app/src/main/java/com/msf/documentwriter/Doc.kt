package com.msf.documentwriter

import android.content.Context
import android.net.Uri
import android.text.SpannableStringBuilder
import java.io.File
import java.io.FileInputStream

/** The document currently open in the editor (shared by editor, save and settings screens). */
object Doc {
    var text = SpannableStringBuilder()
    var trans = SpannableStringBuilder()
    var name = ""
    var kind = DocKind.WORD
    var rtl = false
    var justify = false
    var baseSize = 16
    var font: String? = null
    var image: Uri? = null
    /** drawn signature, stamped at the end of the last page of the PDF / Image */
    var signature: android.graphics.Bitmap? = null
    var pickImage = false
    var dirty = false
    var lang = 0
    /** 0 = plain page, otherwise the id of a PageDesigns border. */
    var pageDesign = 0
    /** Print the page number at the bottom of every page (PDF / Word / Image-with-pages). */
    var pageNumbers = true
    /** Thin frame line around every page; page numbers then read "- 1 -". */
    var pageBorder = false
    /** Paper size index (see [Paper]) and orientation of the open document. */
    var paper = 0
    var landscape = false
    /** Page margins in points; null = the classic margins (40 pt in PDF, 1 inch in Word). The Blank Page editor uses 72 pt. */
    var mar: Mar? = null
    /** True when the user chose the margins in Page Setup (otherwise the Blank Page editor picks them from the paper size). */
    var marCustom = false
    /** Page number position / alignment / format / first number (see the Page Number dialog). */
    var pn = PageNumCfg()
    /** Line spacing multiple (1.0 = normal). */
    var lineSpacing = 1f
    /** Line spacing "Exactly (pt)" chosen in the Spacing page; 0 = the multiple above is used. */
    var lineExact = 0
    /** Text columns: 0 One, 1 Two, 2 Three, 3 Left, 4 Right (see [Cols]). */
    var columns = 0
    val saved = mutableMapOf<String, File>()
    /**
     * Very long documents are opened in parts so the editor never freezes: [text] is the part being edited,
     * [tail] is the rest. The rest is kept untouched and is written back when the document is saved.
     */
    var tail: CharSequence = ""
    // a whole book (80,000+ words, ~600 000 characters) opens in ONE piece; only absurdly large files are split
    const val BIG = 1500000
    const val CHUNK = 1400000
    private var big = BIG
    private var chunk = CHUNK

    private fun cutAt(s: String, from: Int): Int {
        var cut = s.indexOf('\n', from)
        if (cut < 0) return s.length
        cut++
        // never cut through the middle of a table (table rows start with "|")
        while (cut < s.length && s[cut] == '|') { val n = s.indexOf('\n', cut); if (n < 0) return s.length; cut = n + 1 }
        return cut
    }

    private fun splitBig() {
        if (text.length <= big) return
        val cut = cutAt(text.toString(), chunk)
        if (cut >= text.length) return
        tail = SpannableStringBuilder(text, cut, text.length)
        text = SpannableStringBuilder(text, 0, cut)
    }

    /** Next part of a long document (for "Load next part"); empty when everything is already open. */
    fun nextChunk(): CharSequence {
        if (tail.isEmpty()) return ""
        val cut = cutAt(tail.toString(), chunk)
        val part = SpannableStringBuilder(tail, 0, cut)
        tail = if (cut >= tail.length) "" else SpannableStringBuilder(tail, cut, tail.length)
        return part
    }
    /** Where the page editor started each new page (character offsets in [text]); used so the PDF has the same pages. */
    var pageStarts: List<Int> = emptyList()
    /** Design of each page (index = page number - 1; later pages keep the last one). Empty = [pageDesign] on every page. 0 = plain page. */
    var pageDesigns: List<Int> = emptyList()

    fun new(c: Context, kind: DocKind, title: String = "", body: String = "", rtl: Boolean = false) {
        big = BIG; chunk = CHUNK; safeMode = false; diag = ""; headerText = ""; headerColor = 0xFF666666.toInt(); headerSize = 11f; headerDist = 35.4f; headerLine = true; headerAlign = -1
        tail = ""; text = SpannableStringBuilder(body); trans = SpannableStringBuilder(); name = title; this.kind = kind; this.rtl = rtl
        justify = false; baseSize = Prefs.fontSize(c); font = null; image = null; signature = null
        pickImage = false; dirty = false; BookmarkStore.clear(); InkStore.strokes.clear(); lang = 0; pageDesign = 0; pageNumbers = true; pageBorder = false; saved.clear()
        paper = Prefs.paper(c); landscape = Prefs.landscape(c); mar = null; marCustom = false; pn = PageNumCfg(); lineSpacing = 1f; lineExact = 0; columns = 0
        pageStarts = emptyList(); pageDesigns = emptyList()
    }

    /** Incremented whenever a slow reader is abandoned, so that it can never write into the open document afterwards. */
    @Volatile var openToken = 0

    /**
     * Opens a document with the FULL reader only (fonts, colours, tables, headers, page numbers). There is no plain-text mode any more:
     * the reader has no time limit, and if it really cannot read the file the open fails with the reason (see [diag]) instead of
     * silently dropping the formatting.
     */
    fun open(c: Context, f: File, forceSafe: Boolean) {
        val err = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        val th = Thread(null, {
            RichDocx.limit.set(null)
            try { edit(c, f) } catch (t: Throwable) {
                err.set(t)
                diag = "rich failed: " + t.javaClass.simpleName + " " + (t.message ?: RichDocx.lastError).take(140)
            }
        }, "msf-parse", 64L * 1024 * 1024)
        th.start()
        try { th.join() } catch (_: InterruptedException) {}
        err.get()?.let { throw it }
    }

    fun edit(c: Context, f: File) {
        val my = ++openToken
        new(c, kindOf(f.name) ?: DocKind.TEXT)
        name = f.nameWithoutExtension
        saved[f.extension.lowercase()] = f
        try {
            if (f.extension.lowercase() == "docx") {
                val t0 = System.currentTimeMillis()
                Work.progress("فارمیٹنگ، ٹیبل اور رنگ پڑھ رہا ہے… / Reading fonts, tables, colours…")
                val r = RichDocx.parse(f)
                if (my != openToken) return
                if (r.text.isBlank()) throw IllegalStateException("rich reader found no text: " + RichDocx.lastError)
                diag = "rich ok (" + RichDocx.how + ") " + (System.currentTimeMillis() - t0) + "ms " + r.text.length + " chars"
                text = r.text; baseSize = r.size; rtl = r.rtl; justify = r.justify; font = r.font
                Work.progress("متن پڑھ لیا (" + r.text.length + " حروف)، صفحے کا ڈیزائن… / step 2")
                pageDesign = RichDocx.designOf(f)
                Work.progress("سرخی اور صفحہ نمبر… / step 3")
                RunHeader.of(f).let { headerText = it.text; headerColor = it.color; headerSize = it.size }
                RunHeader.distOf(f)?.let { headerDist = it }
                val cfg = RichDocx.numbersOf(f)
                pageNumbers = cfg != null
                if (cfg != null) pn = cfg
                Work.progress("مارجن اور کاغذ… / step 4")
                if (pageDesign == 0) RichDocx.marginsOf(f)?.let { mar = it; marCustom = true }
                RichDocx.pageOf(f)?.let { paper = it.first; landscape = it.second }
                RichDocx.colsOf(f)?.let { columns = it }
            } else text = SpannableStringBuilder(f.readText())
            if (f.extension.lowercase() == "docx") {
                // a long Word file opens in parts so the page editor stays responsive; the rest is added automatically (see PageSheets)
                Work.progress("صفحے بنا رہا ہے… / Building pages…")
                big = 60000; chunk = 50000
            }
            splitBig()
        } catch (e: java.util.concurrent.TimeoutException) { throw e }
    }

    /**
     * Safe mode: used when the last attempt to open this file killed the app (not enough memory).
     * Plain text only (no fonts / colours), small parts, and saving goes to a NEW file so the original is never overwritten.
     */
    fun editSafe(c: Context, f: File, full: Boolean = false) {
        openToken++
        val keepDiag = diag
        new(c, kindOf(f.name) ?: DocKind.TEXT)
        diag = keepDiag
        name = f.nameWithoutExtension + " (safe)"
        val plain = try {
            if (f.extension.lowercase() == "docx") FastDocx.text(f) else f.readText()
        } catch (t: Throwable) { diag += " | plain failed: " + t.javaClass.simpleName; "" }
        diag += " | plain " + plain.length + " chars"
        rtl = plain.take(3000).any { val d = Character.getDirectionality(it); d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC }
        // after a crash: bigger parts than before (the rest opens from the menu); after a slow read: everything at once
        if (full) { big = BIG; chunk = CHUNK } else { big = 150000; chunk = 120000 }
        text = SpannableStringBuilder(plain)
        splitBig()
        safeMode = true
    }
    var safeMode = false
    /** Running page header of the open Word file ("title" at the top of every page); empty = none. */
    var headerText = ""
    var headerColor = 0xFF666666.toInt()
    var headerSize = 11f
    /** Distance of the header from the top edge of the paper (points, Word's "Header from top"), the line under it, and its alignment (-1 = automatic, 0 left, 1 centre, 2 right). */
    var headerDist = 35.4f
    var headerLine = true
    var headerAlign = -1
    /** Height the header needs from the top edge: the text starts below it, like in Word. */
    fun headerTop(): Float = if (headerText.isNotEmpty()) headerDist + headerSize * 1.25f + 8f else 0f
    /** Short note about HOW the last file was opened (shown next to "Full text" while we test big files). */
    @Volatile var diag = ""

    /** Main text, plus the Urdu translation panel (if used) appended after it. */
    fun combined(): CharSequence {
        val main: CharSequence = if (tail.isEmpty()) text else SpannableStringBuilder(text).append(tail)
        if (trans.isEmpty()) return main
        val b = SpannableStringBuilder(main)
        if (b.isNotEmpty()) b.append("\n\n")
        b.append("اردو ترجمہ\n")
        b.append(trans)
        return b
    }

    fun extOf(k: DocKind) = when (k) {
        DocKind.WORD -> "docx"; DocKind.PDF -> "pdf"; DocKind.TEXT -> "txt"; DocKind.IMAGE -> "jpg"
    }

    /** The page design that can actually be drawn (portrait pages only). */
    private fun designId(c: Context): Int = if (landscape || PageDesigns.spec(pageDesign) == null) 0 else pageDesign

    private fun writePdf(c: Context, t: CharSequence, target: File) {
        val d = designId(c)
        val ids = if (d != 0) pageDesigns.map { if (PageDesigns.spec(it) != null) it else 0 } else emptyList()
        val b = PdfBuilder(paper, landscape, if (d != 0) PageDesigns.bitmap(c, d) else null, PageDesigns.spec(d), pageNumbers, mar, ids.mapNotNull { PageDesigns.spec(it) }, pn)
        if (ids.isNotEmpty()) b.pageBg = { n ->
            val id = ids[minOf(n - 1, ids.size - 1).coerceAtLeast(0)]
            if (id == 0) null else PageDesigns.bitmap(c, id)
        }
        image?.let { u -> decodeBitmap(c, u, 1600)?.let { b.image(it) } }
        b.cols = Cols.count(columns)
        b.colRtl = rtl
        b.headerText = headerText; b.headerColor = headerColor; b.headerSize = headerSize
        b.headerDist = headerDist; b.headerLine = headerLine; b.headerAlign = headerAlign
        b.applyHeaderTop()
        // with columns the PDF flows the text itself (the editor's page starts are column starts there)
        b.breaks = if (Cols.count(columns) > 1) emptySet() else pageStarts.toSet()
        b.border = pageBorder
        b.ink = true
        b.rich(t, baseSize, font, rtl, justify)
        signature?.let { b.signature(it) }
        b.finish(target)
    }

    fun write(c: Context, k: DocKind, target: File) {
        // indents / paragraph spacing are measured in points: 1 pt = 1 px in the exported file
        val oldPx = ParaScale.px
        ParaScale.px = 1f
        try { writeNow(c, k, target) } finally { ParaScale.px = oldPx }
    }

    private fun writeNow(c: Context, k: DocKind, target: File) {
        val t: CharSequence = combined()
        when (k) {
            DocKind.WORD -> {
                val d = designId(c)
                RichDocx.write(target, t, baseSize, rtl, justify, font, paper, landscape, d, if (d != 0) PageDesigns.bytes(c, d) else null, pageNumbers, mar, pageBorder, pn, Cols.count(columns))
            }
            DocKind.PDF -> writePdf(c, t, target)
            DocKind.TEXT -> target.writeText(t.toString())
            DocKind.IMAGE -> {
                if (designId(c) != 0 || t.indexOf(PAGE_BREAK) >= 0 || Tables.any(t.toString()) || Cols.count(columns) > 1) {
                    val tmp = File(c.cacheDir, "image_pages.pdf")
                    writePdf(c, t, tmp)
                    try { Render.pdfToJpeg(tmp, target) } finally { tmp.delete() }
                } else Render.toJpeg(t, baseSize, font, rtl, justify, image?.let { decodeBitmap(c, it, 1600) }, target)
            }
        }
    }

    fun saveTo(c: Context, k: DocKind, base: String): File {
        val ext = extOf(k)
        val clean = base.trim().ifEmpty { "Document" }.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val old = saved[ext]
        val target = if (old != null && old.nameWithoutExtension == clean) old else Store.uniqueFile(c, clean, ext)
        write(c, k, target)
        PublicSave.copy(c, target)   // visible in the phone's File Manager
        if (old != null && old != target) old.delete()
        saved[ext] = target
        name = target.nameWithoutExtension
        return target
    }
}

/** Column presets of the Aa sheet: 0 One, 1 Two, 2 Three, 3 Left, 4 Right. */
object Cols {
    /** Number of text columns of a preset (Left / Right are two columns). */
    fun count(mode: Int): Int = when (mode) { 1 -> 2; 2 -> 3; 3, 4 -> 2; else -> 1 }
}
