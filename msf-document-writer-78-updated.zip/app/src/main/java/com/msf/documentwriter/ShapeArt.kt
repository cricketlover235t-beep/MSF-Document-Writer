package com.msf.documentwriter

import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.net.URLDecoder
import java.net.URLEncoder
import kotlin.math.abs
import android.text.style.ReplacementSpan
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * A drawn shape (not a text symbol): one object character (U+FFFC) in the text. Its colour is the text colour and its height is the
 * font size (the Shapes sheet / the shape's own edit window set them). [wScale] stretches the width (1 = normal), [label] is the text
 * written inside the shape and [labelColor] its colour (null = automatic black / white). [id] is the name of Word's preset shape
 * (rightArrow, star5 ...), so it is saved to .docx as a real Word shape (DrawingML) and read back.
 */
class ShapeSpan(
    val id: String,
    val fill: Boolean,
    val wScale: Float = 1f,
    val label: String = "",
    val labelColor: Int? = null
) : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int {
        val side = paint.textSize
        if (fm != null) {
            val up = (side * 0.85f).roundToInt()
            val down = (side * 0.15f).roundToInt()
            fm.ascent = -up; fm.top = -up; fm.descent = down; fm.bottom = down
        }
        return (side * ShapeArt.aspect(id) * wScale).roundToInt()
    }

    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        val side = paint.textSize
        val w = side * ShapeArt.aspect(id) * wScale
        val inset = max(1f, side * 0.03f)
        val l = x + inset
        val t = y - side * 0.85f + inset
        val bw = w - 2 * inset
        val bh = side - 2 * inset
        ShapeArt.draw(canvas, id, l, t, bw, bh, paint.color, fill, max(1.5f, side * 0.045f))
        if (label.isNotEmpty()) ShapeArt.drawLabel(canvas, label, l, t, bw, bh, labelColor ?: ShapeArt.autoText(paint.color, fill), paint.typeface)
    }

    /** Text saved in the .docx (wp:docPr descr): msfshape:<id>:<1 filled / 0 outline>[;w=<width %>][;c=<text colour>][;t=<text, URL-encoded>] */
    fun descr(): String {
        val sb = StringBuilder("msfshape:").append(id).append(':').append(if (fill) 1 else 0)
        if (abs(wScale - 1f) > 0.005f) sb.append(";w=").append((wScale * 100f).roundToInt())
        if (labelColor != null) sb.append(";c=").append(String.format("%08X", labelColor))
        if (label.isNotEmpty()) sb.append(";t=").append(URLEncoder.encode(label, "UTF-8"))
        return sb.toString()
    }

    companion object {
        private const val EXT = "((?:;[a-z]=[A-Za-z0-9%+._*-]*)*)"
        /** Finds our marker anywhere in a piece of XML: groups = id, filled, extras. */
        val RX = Regex("msfshape:([A-Za-z0-9]+):([01])$EXT")

        fun make(id: String, fill: String, ext: String): ShapeSpan? {
            if (!ShapeArt.has(id)) return null
            var w = 1f
            var c: Int? = null
            var t = ""
            for (part in ext.split(';')) {
                if (part.length < 2 || part[1] != '=') continue
                val v = part.substring(2)
                try {
                    when (part[0]) {
                        'w' -> v.toIntOrNull()?.let { w = (it / 100f).coerceIn(0.1f, 10f) }
                        'c' -> v.toLongOrNull(16)?.let { c = it.toInt() }
                        't' -> t = URLDecoder.decode(v, "UTF-8")
                    }
                } catch (_: Exception) { }
            }
            return ShapeSpan(id, fill == "1", w, t, c)
        }

        fun fromDescr(d: String): ShapeSpan? {
            val m = RX.matchEntire(d.trim()) ?: return null
            return make(m.groupValues[1], m.groupValues[2], m.groupValues[3])
        }
    }
}

/** Geometry of every shape of Word's Insert > Shapes gallery, drawn in a 100 x 100 box. */
object ShapeArt {
    class Art(
        val main: Path,
        val detail: Path? = null,
        val open: Boolean = false,
        val heads: Path? = null,
        val evenOdd: Boolean = false,
        val inner: Boolean = true,
        val dash: Boolean = false
    )

    val groups: List<Pair<String, List<String>>> = listOf(
        "Lines" to listOf(
            "line", "lineArrow", "lineDArrow", "bentConnector3", "bentConnectorArrow", "bentConnectorDArrow",
            "curvedConnector3", "curvedConnectorArrow", "curvedConnectorDArrow", "curve", "freeform", "scribble"
        ),
        "Rectangles" to listOf(
            "rect", "roundRect", "snip1Rect", "snip2SameRect", "snip2DiagRect", "snipRoundRect", "round1Rect", "round2SameRect", "round2DiagRect"
        ),
        "Basic Shapes" to listOf(
            "textBox", "ellipse", "triangle", "rtTriangle", "parallelogram", "trapezoid", "diamond", "pentagon", "hexagon", "heptagon", "octagon", "decagon",
            "dodecagon", "pie", "chord", "teardrop", "frame", "halfFrame", "corner", "diagStripe", "plus", "plaque", "can", "cube",
            "bevel", "donut", "noSmoking", "blockArc", "foldedCorner", "smileyFace", "heart", "lightningBolt", "sun", "moon", "cloud", "arc",
            "bracketPair", "bracePair", "leftBracket", "rightBracket", "leftBrace", "rightBrace"
        ),
        "Block Arrows" to listOf(
            "rightArrow", "leftArrow", "upArrow", "downArrow", "leftRightArrow", "upDownArrow", "quadArrow", "leftRightUpArrow", "bentArrow", "uturnArrow", "leftUpArrow", "bentUpArrow",
            "curvedRightArrow", "curvedLeftArrow", "curvedUpArrow", "curvedDownArrow", "stripedRightArrow", "notchedRightArrow", "homePlate", "chevron",
            "rightArrowCallout", "downArrowCallout", "leftArrowCallout", "upArrowCallout", "leftRightArrowCallout", "quadArrowCallout", "circularArrow"
        ),
        "Equation Shapes" to listOf("mathPlus", "mathMinus", "mathMultiply", "mathDivide", "mathEqual", "mathNotEqual"),
        "Flowchart" to listOf(
            "flowChartProcess", "flowChartAlternateProcess", "flowChartDecision", "flowChartInputOutput", "flowChartPredefinedProcess", "flowChartInternalStorage",
            "flowChartDocument", "flowChartMultidocument", "flowChartTerminator", "flowChartPreparation", "flowChartManualInput", "flowChartManualOperation",
            "flowChartConnector", "flowChartOffpageConnector", "flowChartPunchedCard", "flowChartPunchedTape", "flowChartSummingJunction", "flowChartOr",
            "flowChartCollate", "flowChartSort", "flowChartExtract", "flowChartMerge", "flowChartOnlineStorage", "flowChartDelay",
            "flowChartMagneticTape", "flowChartMagneticDisk", "flowChartMagneticDrum", "flowChartDisplay"
        ),
        "Stars and Banners" to listOf(
            "irregularSeal1", "irregularSeal2", "star4", "star5", "star6", "star7", "star8", "star10", "star12", "star16", "star24", "star32",
            "ribbon2", "ribbon", "ellipseRibbon2", "ellipseRibbon", "verticalScroll", "horizontalScroll", "wave", "doubleWave"
        ),
        "Callouts" to listOf(
            "wedgeRectCallout", "wedgeRoundRectCallout", "wedgeEllipseCallout", "cloudCallout",
            "borderCallout1", "borderCallout2", "borderCallout3", "accentCallout1", "accentCallout2", "accentCallout3",
            "callout1", "callout2", "callout3", "accentBorderCallout1", "accentBorderCallout2", "accentBorderCallout3"
        )
    )

    private val ALL: Set<String> = groups.flatMap { it.second }.toSet()
    fun has(id: String) = id in ALL

    /** Shapes that are wider than high when inserted (like in Word). */
    private val WIDE = setOf(
        "rect", "roundRect", "snip1Rect", "snip2SameRect", "snip2DiagRect", "snipRoundRect", "round1Rect", "round2SameRect", "round2DiagRect",
        "textBox", "parallelogram", "trapezoid", "plaque", "foldedCorner", "rightArrow", "leftArrow", "leftRightArrow", "stripedRightArrow", "notchedRightArrow",
        "homePlate", "chevron", "rightArrowCallout", "leftArrowCallout", "leftRightArrowCallout",
        "flowChartProcess", "flowChartAlternateProcess", "flowChartInputOutput", "flowChartPredefinedProcess", "flowChartInternalStorage", "flowChartDocument",
        "flowChartMultidocument", "flowChartTerminator", "flowChartPreparation", "flowChartManualInput", "flowChartManualOperation", "flowChartPunchedCard",
        "flowChartPunchedTape", "flowChartOnlineStorage", "flowChartDelay", "flowChartMagneticDrum", "flowChartDisplay",
        "ribbon", "ribbon2", "ellipseRibbon", "ellipseRibbon2", "horizontalScroll", "wave", "doubleWave",
        "wedgeRectCallout", "wedgeRoundRectCallout", "borderCallout1", "borderCallout2", "borderCallout3", "accentCallout1", "accentCallout2", "accentCallout3",
        "callout1", "callout2", "callout3", "accentBorderCallout1", "accentBorderCallout2", "accentBorderCallout3"
    )
    fun aspect(id: String): Float = if (id in WIDE) 1.5f else 1f

    /** Name of the preset geometry in Word (a:prstGeom). */
    fun prst(id: String): String = when {
        id == "textBox" -> "rect"
        id.startsWith("line") -> "line"
        id.startsWith("bentConnector") -> "bentConnector3"
        id.startsWith("curvedConnector") -> "curvedConnector3"
        id == "curve" -> "arc"
        id == "freeform" || id == "scribble" -> "line"
        else -> id
    }
    fun tailArrow(id: String) = id.endsWith("Arrow") && (id.startsWith("line") || id.startsWith("bentConnector") || id.startsWith("curvedConnector"))
    fun headArrow(id: String) = id.endsWith("DArrow")

    private val cache = HashMap<String, Art?>()
    fun art(id: String): Art? = cache[id] ?: try { build(id)?.also { cache[id] = it } } catch (e: Throwable) { null }

    private fun build(id: String): Art? =
        lines(id) ?: rects(id) ?: basic(id) ?: basic2(id) ?: arrows(id) ?: arrows2(id) ?: equation(id) ?: flow(id) ?: stars(id) ?: callouts(id)

    /** Draws the shape in the box (l, t, w, h): outline only, or filled; the colour is [color]. */
    fun draw(c: Canvas, id: String, l: Float, t: Float, w: Float, h: Float, color: Int, fill: Boolean, strokeW: Float) {
        val a = art(id) ?: return
        val m = Matrix()
        m.setScale(w / 100f, h / 100f)
        m.postTranslate(l, t)
        val main = Path(); a.main.transform(m, main)
        if (a.evenOdd) main.fillType = Path.FillType.EVEN_ODD
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        val filled = fill && !a.open
        if (filled) {
            p.style = Paint.Style.FILL_AND_STROKE; p.color = color; p.strokeWidth = strokeW * 0.6f
            c.drawPath(main, p)
        } else {
            p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = strokeW
            c.drawPath(main, p)
        }
        a.detail?.let { d ->
            val dp = Path(); d.transform(m, dp)
            val q = Paint(Paint.ANTI_ALIAS_FLAG)
            q.style = Paint.Style.STROKE
            q.strokeWidth = strokeW * 0.8f
            q.strokeJoin = Paint.Join.ROUND
            q.strokeCap = Paint.Cap.ROUND
            q.color = if (filled && a.inner) 0xFFFFFFFF.toInt() else color
            if (a.dash) q.pathEffect = DashPathEffect(floatArrayOf(strokeW * 2.5f, strokeW * 2f), 0f)
            c.drawPath(dp, q)
        }
        a.heads?.let { hd ->
            val hp = Path(); hd.transform(m, hp)
            val q = Paint(Paint.ANTI_ALIAS_FLAG)
            q.style = Paint.Style.FILL_AND_STROKE; q.color = color; q.strokeWidth = strokeW * 0.6f; q.strokeJoin = Paint.Join.ROUND
            c.drawPath(hp, q)
        }
    }

    /** Black or white text, whichever can be read on the shape (filled = on the colour, outline = on the page). */
    fun autoText(shapeColor: Int, filled: Boolean): Int {
        if (!filled) return 0xFF000000.toInt()
        val r = (shapeColor shr 16) and 0xFF
        val g = (shapeColor shr 8) and 0xFF
        val b = shapeColor and 0xFF
        val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
        return if (lum < 0.55f) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
    }

    /** Writes [text] in the middle of the box (l, t, w, h); the letters shrink until all of it fits. */
    fun drawLabel(c: Canvas, text: String, l: Float, t: Float, w: Float, h: Float, color: Int, tf: Typeface?) {
        val iw = (w * 0.76f).toInt()
        if (iw < 6 || h < 6f) return
        val ih = h * 0.76f
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.color = color
        if (tf != null) tp.typeface = tf
        var size = h * 0.42f
        fun build(sz: Float): StaticLayout {
            tp.textSize = sz
            return StaticLayout.Builder.obtain(text, 0, text.length, tp, iw).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        }
        var lay = build(size)
        while (lay.height > ih && size > 5f) {
            size *= 0.88f
            lay = build(size)
        }
        c.save()
        c.translate(l + (w - iw) / 2f, t + (h - lay.height) / 2f)
        lay.draw(c)
        c.restore()
    }

    // ───────────────────────── helpers (all coordinates 0..100)
    private fun fl(n: Number) = n.toFloat()
    private fun poly(vararg v: Number): Path {
        val p = Path(); p.moveTo(fl(v[0]), fl(v[1]))
        var i = 2
        while (i + 1 < v.size) { p.lineTo(fl(v[i]), fl(v[i + 1])); i += 2 }
        p.close(); return p
    }
    private fun line(vararg v: Number): Path {
        val p = Path(); p.moveTo(fl(v[0]), fl(v[1]))
        var i = 2
        while (i + 1 < v.size) { p.lineTo(fl(v[i]), fl(v[i + 1])); i += 2 }
        return p
    }
    private fun oval(l: Number, t: Number, r: Number, b: Number) = Path().apply { addOval(RectF(fl(l), fl(t), fl(r), fl(b)), Path.Direction.CW) }
    private fun circ(cx: Number, cy: Number, r: Number) = oval(fl(cx) - fl(r), fl(cy) - fl(r), fl(cx) + fl(r), fl(cy) + fl(r))
    private fun rect(l: Number, t: Number, r: Number, b: Number) = Path().apply { addRect(RectF(fl(l), fl(t), fl(r), fl(b)), Path.Direction.CW) }
    private fun rrect(l: Number, t: Number, r: Number, b: Number, rad: Number) =
        Path().apply { addRoundRect(RectF(fl(l), fl(t), fl(r), fl(b)), fl(rad), fl(rad), Path.Direction.CW) }
    private fun rf(l: Number, t: Number, r: Number, b: Number) = RectF(fl(l), fl(t), fl(r), fl(b))
    private fun un(vararg ps: Path): Path {
        var r = Path(ps[0])
        for (i in 1 until ps.size) { val o = Path(); o.op(r, ps[i], Path.Op.UNION); r = o }
        return r
    }
    private fun tf(p: Path, f: Matrix.() -> Unit): Path { val m = Matrix(); m.f(); val o = Path(); p.transform(m, o); return o }
    private fun rot(p: Path, deg: Number) = tf(p) { setRotate(fl(deg), 50f, 50f) }
    private fun flipH(p: Path) = tf(p) { setScale(-1f, 1f, 50f, 50f) }
    private fun flipV(p: Path) = tf(p) { setScale(1f, -1f, 50f, 50f) }
    private fun ngon(n: Int, cx: Float, cy: Float, r: Float, startDeg: Float): Path {
        val p = Path()
        for (i in 0 until n) {
            val a = (startDeg + 360f * i / n) * PI / 180.0
            val x = cx + r * cos(a).toFloat(); val y = cy + r * sin(a).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close(); return p
    }
    private fun star(n: Int, ro: Float, ri: Float): Path {
        val p = Path()
        for (i in 0 until 2 * n) {
            val r = if (i % 2 == 0) ro else ri
            val a = (-90.0 + 180.0 * i / n) * PI / 180.0
            val x = 50f + r * cos(a).toFloat(); val y = 50f + r * sin(a).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close(); return p
    }
    private fun burst(outer: List<Float>, inner: List<Float>): Path {
        val n = outer.size
        val p = Path()
        for (i in 0 until n) {
            val a1 = (-90.0 + 360.0 * i / n) * PI / 180.0
            val a2 = (-90.0 + 360.0 * (i + 0.5) / n) * PI / 180.0
            val x1 = 50f + outer[i] * cos(a1).toFloat(); val y1 = 50f + outer[i] * sin(a1).toFloat()
            val x2 = 50f + inner[i] * cos(a2).toFloat(); val y2 = 50f + inner[i] * sin(a2).toFloat()
            if (i == 0) p.moveTo(x1, y1) else p.lineTo(x1, y1)
            p.lineTo(x2, y2)
        }
        p.close(); return p
    }
    /** Arrowhead (filled triangle) at (x, y) looking in direction [deg]. */
    private fun head(x: Float, y: Float, deg: Float, s: Float = 11f): Path {
        val a = deg * PI / 180.0
        val dx = cos(a).toFloat(); val dy = sin(a).toFloat()
        val bx = x - dx * s; val by = y - dy * s
        return poly(x, y, bx - dy * s * 0.5f, by + dx * s * 0.5f, bx + dy * s * 0.5f, by - dx * s * 0.5f)
    }
    private fun bezier(p0: PointF, p1: PointF, p2: PointF, p3: PointF): (Float) -> PointF = { t ->
        val u = 1f - t
        PointF(
            u * u * u * p0.x + 3 * u * u * t * p1.x + 3 * u * t * t * p2.x + t * t * t * p3.x,
            u * u * u * p0.y + 3 * u * u * t * p1.y + 3 * u * t * t * p2.y + t * t * t * p3.y
        )
    }
    /** A thick curved arrow along the centre line [pt] (t = 0..1). */
    private fun bandArrow(pt: (Float) -> PointF, w: Float, hw: Float, tb: Float): Path {
        fun tan(t: Float): PointF {
            val a = pt((t - 0.01f).coerceAtLeast(0f)); val b = pt((t + 0.01f).coerceAtMost(1f))
            val dx = b.x - a.x; val dy = b.y - a.y; val l = max(hypot(dx, dy), 1e-3f)
            return PointF(dx / l, dy / l)
        }
        val n = 28
        val left = ArrayList<PointF>(); val right = ArrayList<PointF>()
        for (i in 0..n) {
            val t = tb * i / n; val p = pt(t); val d = tan(t)
            left.add(PointF(p.x - d.y * w / 2, p.y + d.x * w / 2)); right.add(PointF(p.x + d.y * w / 2, p.y - d.x * w / 2))
        }
        val bp = pt(tb); val bd = tan(tb); val tip = pt(1f)
        val out = Path()
        out.moveTo(left[0].x, left[0].y)
        for (i in 1..n) out.lineTo(left[i].x, left[i].y)
        out.lineTo(bp.x - bd.y * hw / 2, bp.y + bd.x * hw / 2)
        out.lineTo(tip.x, tip.y)
        out.lineTo(bp.x + bd.y * hw / 2, bp.y - bd.x * hw / 2)
        for (i in n downTo 0) out.lineTo(right[i].x, right[i].y)
        out.close(); return out
    }
    private fun curvedRight(): Path = bandArrow(bezier(PointF(30f, 2f), PointF(-5f, 20f), PointF(0f, 62f), PointF(97f, 76f)), 16f, 36f, 0.78f)
    private fun docPath(l: Float, t: Float, r: Float, b: Float): Path {
        val h = b - t
        return Path().apply {
            moveTo(l, t); lineTo(r, t); lineTo(r, b - h * 0.18f)
            cubicTo(l + (r - l) * 0.75f, b + h * 0.06f, l + (r - l) * 0.25f, b - h * 0.42f, l, b - h * 0.18f); close()
        }
    }
    private fun cloud(): Path = un(circ(27, 64, 19), circ(46, 42, 23), circ(72, 50, 21), circ(78, 70, 15), circ(48, 70, 21))
    private fun brL(x0: Float, x1: Float) = Path().apply { moveTo(x1, 0f); quadTo(x0, 0f, x0, 15f); lineTo(x0, 85f); quadTo(x0, 100f, x1, 100f) }
    private fun brR(x0: Float, x1: Float) = Path().apply { moveTo(x0, 0f); quadTo(x1, 0f, x1, 15f); lineTo(x1, 85f); quadTo(x1, 100f, x0, 100f) }
    private fun bcL(x0: Float, x1: Float): Path {
        val xm = (x0 + x1) / 2
        return Path().apply {
            moveTo(x1, 0f); quadTo(xm, 0f, xm, 15f); lineTo(xm, 38f); quadTo(xm, 50f, x0, 50f); quadTo(xm, 50f, xm, 62f); lineTo(xm, 85f); quadTo(xm, 100f, x1, 100f)
        }
    }
    private fun bcR(x0: Float, x1: Float): Path {
        val xm = (x0 + x1) / 2
        return Path().apply {
            moveTo(x0, 0f); quadTo(xm, 0f, xm, 15f); lineTo(xm, 38f); quadTo(xm, 50f, x1, 50f); quadTo(xm, 50f, xm, 62f); lineTo(xm, 85f); quadTo(xm, 100f, x0, 100f)
        }
    }
    private fun union2(a: Path, b: Path): Path = un(a, b)

    // ───────────────────────── Lines
    private fun lines(id: String): Art? {
        val zElbow = line(4, 14, 50, 14, 50, 86, 96, 86)
        val sCurve = Path().apply { moveTo(4f, 14f); cubicTo(58f, 14f, 42f, 86f, 96f, 86f) }
        return when (id) {
            "line" -> Art(line(5, 5, 95, 95), open = true)
            "lineArrow" -> Art(line(5, 5, 90, 90), open = true, heads = head(95f, 95f, 45f))
            "lineDArrow" -> Art(line(10, 10, 90, 90), open = true, heads = un(head(95f, 95f, 45f), head(5f, 5f, 225f)))
            "bentConnector3" -> Art(zElbow, open = true)
            "bentConnectorArrow" -> Art(line(4, 14, 50, 14, 50, 86, 90, 86), open = true, heads = head(96f, 86f, 0f))
            "bentConnectorDArrow" -> Art(line(10, 14, 50, 14, 50, 86, 90, 86), open = true, heads = un(head(96f, 86f, 0f), head(4f, 14f, 180f)))
            "curvedConnector3" -> Art(sCurve, open = true)
            "curvedConnectorArrow" -> Art(Path().apply { moveTo(4f, 14f); cubicTo(58f, 14f, 42f, 86f, 88f, 86f) }, open = true, heads = head(96f, 86f, 0f))
            "curvedConnectorDArrow" -> Art(Path().apply { moveTo(12f, 14f); cubicTo(58f, 14f, 42f, 86f, 88f, 86f) }, open = true, heads = un(head(96f, 86f, 0f), head(4f, 14f, 180f)))
            "curve" -> Art(Path().apply { moveTo(8f, 88f); cubicTo(8f, 10f, 92f, 10f, 92f, 88f) }, open = true)
            "freeform" -> Art(line(8, 86, 28, 30, 50, 70, 74, 18, 92, 58), open = true)
            "scribble" -> Art(Path().apply { moveTo(6f, 70f); cubicTo(16f, 5f, 34f, 95f, 46f, 40f); cubicTo(56f, -5f, 78f, 15f, 94f, 62f) }, open = true)
            else -> null
        }
    }

    // ───────────────────────── Rectangles
    private fun rects(id: String): Art? = when (id) {
        "rect" -> Art(rect(0, 0, 100, 100))
        "roundRect" -> Art(rrect(0, 0, 100, 100, 18))
        "snip1Rect" -> Art(poly(0, 0, 75, 0, 100, 25, 100, 100, 0, 100))
        "snip2SameRect" -> Art(poly(25, 0, 75, 0, 100, 25, 100, 100, 0, 100, 0, 25))
        "snip2DiagRect" -> Art(poly(25, 0, 100, 0, 100, 75, 75, 100, 0, 100, 0, 25))
        "snipRoundRect" -> Art(Path().apply { moveTo(0f, 25f); arcTo(rf(0, 0, 50, 50), 180f, 90f, false); lineTo(75f, 0f); lineTo(100f, 25f); lineTo(100f, 100f); lineTo(0f, 100f); close() })
        "round1Rect" -> Art(Path().apply { moveTo(0f, 0f); lineTo(75f, 0f); arcTo(rf(50, 0, 100, 50), 270f, 90f, false); lineTo(100f, 100f); lineTo(0f, 100f); close() })
        "round2SameRect" -> Art(Path().apply {
            moveTo(25f, 0f); lineTo(75f, 0f); arcTo(rf(50, 0, 100, 50), 270f, 90f, false); lineTo(100f, 100f); lineTo(0f, 100f); lineTo(0f, 25f); arcTo(rf(0, 0, 50, 50), 180f, 90f, false); close()
        })
        "round2DiagRect" -> Art(Path().apply {
            moveTo(0f, 25f); arcTo(rf(0, 0, 50, 50), 180f, 90f, false); lineTo(100f, 0f); lineTo(100f, 75f); arcTo(rf(50, 50, 100, 100), 0f, 90f, false); lineTo(0f, 100f); close()
        })
        else -> null
    }

    // ───────────────────────── Basic shapes (1)
    private fun basic(id: String): Art? = when (id) {
        "textBox" -> Art(rect(0, 0, 100, 100), detail = Path().apply { addPath(line(16, 30, 84, 30)); addPath(line(16, 50, 84, 50)); addPath(line(16, 70, 60, 70)) })
        "ellipse" -> Art(oval(2, 2, 98, 98))
        "triangle" -> Art(poly(50, 3, 98, 97, 2, 97))
        "rtTriangle" -> Art(poly(3, 3, 97, 97, 3, 97))
        "parallelogram" -> Art(poly(25, 0, 100, 0, 75, 100, 0, 100))
        "trapezoid" -> Art(poly(25, 0, 75, 0, 100, 100, 0, 100))
        "diamond" -> Art(poly(50, 0, 100, 50, 50, 100, 0, 50))
        "pentagon" -> Art(ngon(5, 50f, 53f, 49f, -90f))
        "hexagon" -> Art(poly(25, 4, 75, 4, 100, 50, 75, 96, 25, 96, 0, 50))
        "heptagon" -> Art(ngon(7, 50f, 53f, 48f, -90f))
        "octagon" -> Art(ngon(8, 50f, 50f, 50f, -67.5f))
        "decagon" -> Art(ngon(10, 50f, 50f, 50f, -90f))
        "dodecagon" -> Art(ngon(12, 50f, 50f, 50f, -75f))
        "pie" -> Art(Path().apply { moveTo(50f, 50f); lineTo(98f, 50f); arcTo(rf(2, 2, 98, 98), 0f, 270f, false); close() })
        "chord" -> Art(Path().apply { arcTo(rf(2, 2, 98, 98), 45f, 225f, true); close() })
        "teardrop" -> Art(Path().apply { moveTo(50f, 8f); arcTo(rf(4, 8, 96, 100), 270f, -270f, false); lineTo(96f, 8f); close() })
        "frame" -> Art(Path().apply { addRect(rf(0, 0, 100, 100), Path.Direction.CW); addRect(rf(16, 16, 84, 84), Path.Direction.CCW) }, evenOdd = true)
        "halfFrame" -> Art(poly(0, 0, 100, 0, 64, 32, 32, 32, 32, 64, 0, 100))
        "corner" -> Art(poly(0, 0, 34, 0, 34, 66, 100, 66, 100, 100, 0, 100))
        "diagStripe" -> Art(poly(0, 50, 50, 0, 100, 0, 0, 100))
        "plus" -> Art(poly(33, 0, 67, 0, 67, 33, 100, 33, 100, 67, 67, 67, 67, 100, 33, 100, 33, 67, 0, 67, 0, 33, 33, 33))
        "plaque" -> Art(Path().apply {
            moveTo(15f, 0f); lineTo(85f, 0f); quadTo(85f, 15f, 100f, 15f); lineTo(100f, 85f); quadTo(85f, 85f, 85f, 100f)
            lineTo(15f, 100f); quadTo(15f, 85f, 0f, 85f); lineTo(0f, 15f); quadTo(15f, 15f, 15f, 0f); close()
        })
        "can" -> Art(
            Path().apply {
                moveTo(0f, 15f); lineTo(0f, 85f); arcTo(rf(0, 70, 100, 100), 180f, -180f, false); lineTo(100f, 15f)
                arcTo(rf(0, 0, 100, 30), 0f, -180f, false); close()
            },
            detail = Path().apply { moveTo(0f, 15f); arcTo(rf(0, 0, 100, 30), 180f, -180f, false) }
        )
        "cube" -> Art(Path().apply { addPath(rect(0, 25, 75, 100)); addPath(poly(0, 25, 25, 0, 100, 0, 75, 25)); addPath(poly(75, 25, 100, 0, 100, 75, 75, 100)) })
        "bevel" -> Art(rect(0, 0, 100, 100), detail = Path().apply {
            addPath(rect(16, 16, 84, 84)); addPath(line(0, 0, 16, 16)); addPath(line(100, 0, 84, 16)); addPath(line(0, 100, 16, 84)); addPath(line(100, 100, 84, 84))
        })
        "donut" -> Art(Path().apply { addOval(rf(0, 0, 100, 100), Path.Direction.CW); addOval(rf(25, 25, 75, 75), Path.Direction.CCW) }, evenOdd = true)
        "noSmoking" -> Art(
            Path().apply { addOval(rf(0, 0, 100, 100), Path.Direction.CW); addOval(rf(14, 14, 86, 86), Path.Direction.CCW) },
            detail = Path().apply { addPath(line(20.08, 29.98, 70.02, 79.92)); addPath(line(29.98, 20.08, 79.92, 70.02)) }, evenOdd = true
        )
        "blockArc" -> Art(Path().apply { arcTo(rf(0, 0, 100, 140), 180f, 180f, true); lineTo(75f, 70f); arcTo(rf(25, 25, 75, 115), 0f, -180f, false); close() })
        "foldedCorner" -> Art(poly(0, 0, 100, 0, 100, 65, 65, 100, 0, 100), detail = line(65, 100, 65, 65, 100, 65))
        "smileyFace" -> Art(oval(2, 2, 98, 98), detail = Path().apply {
            addOval(rf(30, 32, 41, 48), Path.Direction.CW); addOval(rf(59, 32, 70, 48), Path.Direction.CW); addArc(rf(25, 20, 75, 78), 30f, 120f)
        })
        "heart" -> Art(Path().apply {
            moveTo(50f, 30f); cubicTo(50f, 30f, 45f, 3f, 25f, 3f); cubicTo(5f, 3f, 0f, 22f, 0f, 33f); cubicTo(0f, 60f, 30f, 76f, 50f, 97f)
            cubicTo(70f, 76f, 100f, 60f, 100f, 33f); cubicTo(100f, 22f, 95f, 3f, 75f, 3f); cubicTo(55f, 3f, 50f, 30f, 50f, 30f); close()
        })
        "lightningBolt" -> Art(poly(40, 0, 15, 55, 42, 55, 30, 100, 85, 40, 55, 40, 75, 0))
        "sun" -> Art(Path().apply {
            addCircle(50f, 50f, 22f, Path.Direction.CW)
            for (k in 0 until 8) {
                val a = k * 45.0 * PI / 180.0
                val cx = cos(a).toFloat(); val sy = sin(a).toFloat()
                val bx = 50f + 32f * cx; val by = 50f + 32f * sy
                val tx = 50f + 49f * cx; val ty = 50f + 49f * sy
                moveTo(bx - sy * 6f, by + cx * 6f); lineTo(tx, ty); lineTo(bx + sy * 6f, by - cx * 6f); close()
            }
        })
        "moon" -> Art(Path().apply { moveTo(60f, 0f); arcTo(rf(10, 0, 110, 100), 270f, -180f, false); quadTo(35f, 50f, 60f, 0f); close() })
        "cloud" -> Art(cloud())
        "arc" -> Art(Path().apply { moveTo(10f, 10f); arcTo(rf(-70, 10, 90, 170), 270f, 90f, false) }, open = true)
        else -> null
    }

    // ───────────────────────── Basic shapes (2): brackets and braces
    private fun basic2(id: String): Art? = when (id) {
        "bracketPair" -> Art(Path().apply { addPath(brL(8f, 40f)); addPath(brR(60f, 92f)) }, open = true)
        "bracePair" -> Art(Path().apply { addPath(bcL(8f, 40f)); addPath(bcR(60f, 92f)) }, open = true)
        "leftBracket" -> Art(brL(30f, 70f), open = true)
        "rightBracket" -> Art(brR(30f, 70f), open = true)
        "leftBrace" -> Art(bcL(30f, 70f), open = true)
        "rightBrace" -> Art(bcR(30f, 70f), open = true)
        else -> null
    }

    // ───────────────────────── Block arrows (1)
    private val rightArrowP: Path by lazy { poly(0, 30, 60, 30, 60, 2, 100, 50, 60, 98, 60, 70, 0, 70) }
    private val leftRightP: Path by lazy { poly(0, 50, 25, 15, 25, 35, 75, 35, 75, 15, 100, 50, 75, 85, 75, 65, 25, 65, 25, 85) }

    private fun arrows(id: String): Art? = when (id) {
        "rightArrow" -> Art(rightArrowP)
        "leftArrow" -> Art(flipH(rightArrowP))
        "upArrow" -> Art(rot(rightArrowP, -90))
        "downArrow" -> Art(rot(rightArrowP, 90))
        "leftRightArrow" -> Art(leftRightP)
        "upDownArrow" -> Art(rot(leftRightP, 90))
        "quadArrow" -> Art(poly(
            50, 0, 70, 22, 58, 22, 58, 42, 78, 42, 78, 30, 100, 50, 78, 70, 78, 58, 58, 58, 58, 78, 70, 78,
            50, 100, 30, 78, 42, 78, 42, 58, 22, 58, 22, 70, 0, 50, 22, 30, 22, 42, 42, 42, 42, 22, 30, 22
        ))
        "leftRightUpArrow" -> Art(poly(50, 0, 70, 22, 58, 22, 58, 45, 78, 45, 78, 32, 100, 62, 78, 92, 78, 79, 22, 79, 22, 92, 0, 62, 22, 32, 22, 45, 42, 45, 42, 22, 30, 22))
        "bentArrow" -> Art(poly(0, 100, 0, 20, 70, 20, 70, 4, 100, 31, 70, 58, 70, 42, 22, 42, 22, 100))
        "uturnArrow" -> Art(Path().apply {
            moveTo(0f, 100f); lineTo(0f, 35f); arcTo(rf(0, 0, 70, 70), 180f, 180f, false)
            lineTo(70f, 50f); lineTo(85f, 50f); lineTo(60f, 82f); lineTo(35f, 50f); lineTo(50f, 50f); lineTo(50f, 35f)
            arcTo(rf(20, 20, 50, 50), 0f, -180f, false); lineTo(20f, 100f); close()
        })
        "leftUpArrow" -> Art(poly(0, 75, 25, 50, 25, 67, 67, 67, 67, 25, 50, 25, 75, 0, 100, 25, 83, 25, 83, 83, 25, 83, 25, 100))
        "bentUpArrow" -> Art(poly(0, 60, 55, 60, 55, 25, 40, 25, 70, 0, 100, 25, 85, 25, 85, 80, 0, 80))
        "curvedRightArrow" -> Art(curvedRight())
        "curvedLeftArrow" -> Art(flipH(curvedRight()))
        "curvedUpArrow" -> Art(rot(curvedRight(), -90))
        "curvedDownArrow" -> Art(flipV(rot(curvedRight(), -90)))
        "stripedRightArrow" -> Art(Path().apply {
            addPath(rect(0, 30, 8, 70)); addPath(rect(14, 30, 22, 70)); addPath(poly(30, 30, 62, 30, 62, 2, 100, 50, 62, 98, 62, 70, 30, 70))
        })
        "notchedRightArrow" -> Art(poly(0, 30, 62, 30, 62, 2, 100, 50, 62, 98, 62, 70, 0, 70, 18, 50))
        "homePlate" -> Art(poly(0, 10, 65, 10, 100, 50, 65, 90, 0, 90))
        "chevron" -> Art(poly(0, 10, 65, 10, 100, 50, 65, 90, 0, 90, 35, 50))
        else -> null
    }

    // ───────────────────────── Block arrows (2): callouts
    private val rightCalloutP: Path by lazy { poly(0, 20, 55, 20, 55, 35, 75, 35, 75, 12, 100, 50, 75, 88, 75, 65, 55, 65, 55, 80, 0, 80) }
    private fun arrows2(id: String): Art? = when (id) {
        "rightArrowCallout" -> Art(rightCalloutP, detail = line(55, 35, 55, 65))
        "leftArrowCallout" -> Art(flipH(rightCalloutP), detail = line(45, 35, 45, 65))
        "downArrowCallout" -> Art(rot(rightCalloutP, 90), detail = line(35, 55, 65, 55))
        "upArrowCallout" -> Art(rot(rightCalloutP, -90), detail = line(35, 45, 65, 45))
        "leftRightArrowCallout" -> Art(
            poly(0, 50, 20, 22, 20, 38, 30, 38, 30, 15, 70, 15, 70, 38, 80, 38, 80, 22, 100, 50, 80, 78, 80, 62, 70, 62, 70, 85, 30, 85, 30, 62, 20, 62, 20, 78),
            detail = Path().apply { addPath(line(30, 38, 30, 62)); addPath(line(70, 38, 70, 62)) }
        )
        "quadArrowCallout" -> Art(un(
            rect(28, 28, 72, 72),
            poly(50, 0, 64, 15, 56, 15, 56, 30, 44, 30, 44, 15, 36, 15),
            poly(50, 100, 64, 85, 56, 85, 56, 70, 44, 70, 44, 85, 36, 85),
            poly(0, 50, 15, 36, 15, 44, 30, 44, 30, 56, 15, 56, 15, 64),
            poly(100, 50, 85, 36, 85, 44, 70, 44, 70, 56, 85, 56, 85, 64)
        ))
        "circularArrow" -> Art(bandArrow({ t ->
            val a = (200.0 + 150.0 * t) * PI / 180.0
            PointF(50f + 34f * cos(a).toFloat(), 62f + 34f * sin(a).toFloat())
        }, 16f, 38f, 0.8f))
        else -> null
    }

    // ───────────────────────── Equation shapes
    private fun equation(id: String): Art? {
        val plus = poly(38, 10, 62, 10, 62, 38, 90, 38, 90, 62, 62, 62, 62, 90, 38, 90, 38, 62, 10, 62, 10, 38, 38, 38)
        return when (id) {
            "mathPlus" -> Art(plus)
            "mathMinus" -> Art(rect(10, 38, 90, 62))
            "mathMultiply" -> Art(rot(plus, 45))
            "mathDivide" -> Art(Path().apply { addPath(rect(10, 38, 90, 62)); addPath(oval(38, 6, 62, 30)); addPath(oval(38, 70, 62, 94)) })
            "mathEqual" -> Art(Path().apply { addPath(rect(10, 20, 90, 42)); addPath(rect(10, 58, 90, 80)) })
            "mathNotEqual" -> Art(un(rect(10, 20, 90, 42), rect(10, 58, 90, 80), poly(60, 4, 76, 12, 40, 96, 24, 88)))
            else -> null
        }
    }

    // ───────────────────────── Flowchart
    private fun flow(id: String): Art? = when (id) {
        "flowChartProcess" -> Art(rect(0, 0, 100, 100))
        "flowChartAlternateProcess" -> Art(rrect(0, 0, 100, 100, 20))
        "flowChartDecision" -> Art(poly(50, 0, 100, 50, 50, 100, 0, 50))
        "flowChartInputOutput" -> Art(poly(20, 0, 100, 0, 80, 100, 0, 100))
        "flowChartPredefinedProcess" -> Art(rect(0, 0, 100, 100), detail = Path().apply { addPath(line(12, 0, 12, 100)); addPath(line(88, 0, 88, 100)) })
        "flowChartInternalStorage" -> Art(rect(0, 0, 100, 100), detail = Path().apply { addPath(line(14, 0, 14, 100)); addPath(line(0, 20, 100, 20)) })
        "flowChartDocument" -> Art(docPath(0f, 0f, 100f, 100f))
        "flowChartMultidocument" -> Art(
            un(docPath(20f, 0f, 100f, 72f), docPath(10f, 12f, 90f, 84f), docPath(0f, 24f, 80f, 96f)),
            detail = Path().apply { addPath(docPath(0f, 24f, 80f, 96f)); addPath(docPath(10f, 12f, 90f, 84f)) }
        )
        "flowChartTerminator" -> Art(rrect(0, 0, 100, 100, 50))
        "flowChartPreparation" -> Art(poly(18, 0, 82, 0, 100, 50, 82, 100, 18, 100, 0, 50))
        "flowChartManualInput" -> Art(poly(0, 22, 100, 0, 100, 100, 0, 100))
        "flowChartManualOperation" -> Art(poly(0, 0, 100, 0, 80, 100, 20, 100))
        "flowChartConnector" -> Art(oval(4, 4, 96, 96))
        "flowChartOffpageConnector" -> Art(poly(0, 0, 100, 0, 100, 65, 50, 100, 0, 65))
        "flowChartPunchedCard" -> Art(poly(22, 0, 100, 0, 100, 100, 0, 100, 0, 24))
        "flowChartPunchedTape" -> Art(Path().apply {
            moveTo(0f, 12f); cubicTo(25f, -6f, 75f, 30f, 100f, 12f); lineTo(100f, 88f); cubicTo(75f, 106f, 25f, 70f, 0f, 88f); close()
        })
        "flowChartSummingJunction" -> Art(oval(4, 4, 96, 96), detail = Path().apply { addPath(line(20.3, 20.3, 79.7, 79.7)); addPath(line(79.7, 20.3, 20.3, 79.7)) })
        "flowChartOr" -> Art(oval(4, 4, 96, 96), detail = Path().apply { addPath(line(50, 4, 50, 96)); addPath(line(4, 50, 96, 50)) })
        "flowChartCollate" -> Art(poly(0, 0, 100, 0, 50, 50, 100, 100, 0, 100, 50, 50))
        "flowChartSort" -> Art(poly(50, 0, 100, 50, 50, 100, 0, 50), detail = line(0, 50, 100, 50))
        "flowChartExtract" -> Art(poly(50, 0, 100, 100, 0, 100))
        "flowChartMerge" -> Art(poly(0, 0, 100, 0, 50, 100))
        "flowChartOnlineStorage" -> Art(Path().apply {
            moveTo(15f, 0f); lineTo(100f, 0f); quadTo(82f, 50f, 100f, 100f); lineTo(15f, 100f); quadTo(0f, 50f, 15f, 0f); close()
        })
        "flowChartDelay" -> Art(Path().apply { moveTo(0f, 0f); lineTo(55f, 0f); arcTo(rf(10, 0, 100, 100), 270f, 180f, false); lineTo(0f, 100f); close() })
        "flowChartMagneticTape" -> Art(oval(2, 2, 90, 90), detail = line(46, 90, 100, 90), inner = false)
        "flowChartMagneticDisk" -> Art(
            Path().apply {
                moveTo(0f, 15f); lineTo(0f, 85f); arcTo(rf(0, 70, 100, 100), 180f, -180f, false); lineTo(100f, 15f)
                arcTo(rf(0, 0, 100, 30), 0f, -180f, false); close()
            },
            detail = Path().apply { moveTo(0f, 15f); arcTo(rf(0, 0, 100, 30), 180f, -180f, false) }
        )
        "flowChartMagneticDrum" -> Art(
            Path().apply {
                moveTo(15f, 0f); lineTo(85f, 0f); arcTo(rf(70, 0, 100, 100), 270f, 180f, false); lineTo(15f, 100f); arcTo(rf(0, 0, 30, 100), 90f, 180f, false); close()
            },
            detail = Path().apply { moveTo(85f, 0f); arcTo(rf(70, 0, 100, 100), 270f, -180f, false) }
        )
        "flowChartDisplay" -> Art(Path().apply {
            moveTo(0f, 50f); lineTo(22f, 0f); lineTo(75f, 0f); quadTo(100f, 0f, 100f, 50f); quadTo(100f, 100f, 75f, 100f); lineTo(22f, 100f); close()
        })
        else -> null
    }

    // ───────────────────────── Stars and banners
    private fun ribbonP(): Path = poly(0, 30, 20, 30, 20, 8, 80, 8, 80, 30, 100, 30, 88, 55, 100, 80, 80, 80, 80, 70, 20, 70, 20, 80, 0, 80, 12, 55)
    private fun ellipseRibbonP(): Path = Path().apply {
        moveTo(0f, 30f); lineTo(20f, 30f); lineTo(20f, 16f); quadTo(50f, 38f, 80f, 16f); lineTo(80f, 30f); lineTo(100f, 30f); lineTo(88f, 55f); lineTo(100f, 80f)
        lineTo(80f, 80f); lineTo(80f, 62f); quadTo(50f, 84f, 20f, 62f); lineTo(20f, 80f); lineTo(0f, 80f); lineTo(12f, 55f); close()
    }
    private fun scrollV(): Path = un(rrect(8, 0, 92, 18, 9), rrect(8, 82, 92, 100, 9), rect(16, 9, 84, 91))

    private fun stars(id: String): Art? = when (id) {
        "irregularSeal1" -> Art(burst(
            listOf(50f, 44f, 50f, 40f, 50f, 46f, 48f, 42f, 50f, 44f, 46f, 40f),
            listOf(24f, 28f, 22f, 30f, 26f, 24f, 30f, 22f, 28f, 26f, 24f, 30f)
        ))
        "irregularSeal2" -> Art(burst(
            listOf(50f, 46f, 50f, 44f, 50f, 48f, 46f, 50f, 42f, 50f, 46f, 48f, 44f, 50f),
            listOf(30f, 34f, 28f, 32f, 30f, 26f, 34f, 30f, 28f, 32f, 30f, 26f, 34f, 28f)
        ))
        "star4" -> Art(star(4, 50f, 15f))
        "star5" -> Art(star(5, 50f, 20f))
        "star6" -> Art(star(6, 50f, 26f))
        "star7" -> Art(star(7, 50f, 36f))
        "star8" -> Art(star(8, 50f, 38f))
        "star10" -> Art(star(10, 50f, 40f))
        "star12" -> Art(star(12, 50f, 42f))
        "star16" -> Art(star(16, 50f, 42f))
        "star24" -> Art(star(24, 50f, 44f))
        "star32" -> Art(star(32, 50f, 45f))
        "ribbon" -> Art(ribbonP(), detail = Path().apply { addPath(line(20, 30, 20, 70)); addPath(line(80, 30, 80, 70)) })
        "ribbon2" -> Art(flipV(ribbonP()), detail = Path().apply { addPath(line(20, 30, 20, 70)); addPath(line(80, 30, 80, 70)) })
        "ellipseRibbon" -> Art(ellipseRibbonP(), detail = Path().apply { addPath(line(20, 30, 20, 62)); addPath(line(80, 30, 80, 62)) })
        "ellipseRibbon2" -> Art(flipV(ellipseRibbonP()), detail = Path().apply { addPath(line(20, 38, 20, 70)); addPath(line(80, 38, 80, 70)) })
        "verticalScroll" -> Art(scrollV(), detail = Path().apply { addPath(line(16, 9, 16, 18)); addPath(line(84, 82, 84, 91)) })
        "horizontalScroll" -> Art(rot(scrollV(), 90), detail = Path().apply { addPath(line(82, 16, 91, 16)); addPath(line(9, 84, 18, 84)) })
        "wave" -> Art(Path().apply {
            moveTo(0f, 20f); cubicTo(25f, 0f, 75f, 40f, 100f, 20f); lineTo(100f, 80f); cubicTo(75f, 100f, 25f, 60f, 0f, 80f); close()
        })
        "doubleWave" -> Art(Path().apply {
            moveTo(0f, 20f); cubicTo(17f, 0f, 33f, 40f, 50f, 20f); cubicTo(67f, 0f, 83f, 40f, 100f, 20f); lineTo(100f, 80f)
            cubicTo(83f, 100f, 67f, 60f, 50f, 80f); cubicTo(33f, 100f, 17f, 60f, 0f, 80f); close()
        })
        else -> null
    }

    // ───────────────────────── Callouts
    private fun callouts(id: String): Art? {
        val box = rect(28, 0, 100, 62)
        return when (id) {
            "wedgeRectCallout" -> Art(poly(0, 0, 100, 0, 100, 74, 38, 74, 18, 100, 22, 74, 0, 74))
            "wedgeRoundRectCallout" -> Art(un(rrect(0, 0, 100, 74, 14), poly(18, 68, 16, 100, 46, 68)))
            "wedgeEllipseCallout" -> Art(un(oval(0, 0, 100, 74), poly(20, 62, 14, 100, 44, 68)))
            "cloudCallout" -> Art(Path().apply {
                addPath(tf(cloud()) { setScale(1f, 0.8f, 50f, 0f); postTranslate(0f, -14f) })
                addCircle(18f, 84f, 7f, Path.Direction.CW); addCircle(7f, 96f, 4f, Path.Direction.CW)
            })
            "borderCallout1" -> Art(box, detail = line(28, 31, 0, 96), inner = false)
            "borderCallout2" -> Art(box, detail = line(28, 31, 14, 31, 0, 96), inner = false)
            "borderCallout3" -> Art(box, detail = line(28, 31, 16, 31, 8, 62, 0, 96), inner = false)
            "accentCallout1" -> Art(box, detail = Path().apply { addPath(line(28, 0, 28, 62)); addPath(line(28, 31, 0, 96)) }, inner = false)
            "accentCallout2" -> Art(box, detail = Path().apply { addPath(line(28, 0, 28, 62)); addPath(line(28, 31, 14, 31, 0, 96)) }, inner = false)
            "accentCallout3" -> Art(box, detail = Path().apply { addPath(line(28, 0, 28, 62)); addPath(line(28, 31, 16, 31, 8, 62, 0, 96)) }, inner = false)
            "callout1" -> Art(line(28, 31, 0, 96), open = true, detail = rect(28, 0, 100, 62), dash = true, inner = false)
            "callout2" -> Art(line(28, 31, 14, 31, 0, 96), open = true, detail = rect(28, 0, 100, 62), dash = true, inner = false)
            "callout3" -> Art(line(28, 31, 16, 31, 8, 62, 0, 96), open = true, detail = rect(28, 0, 100, 62), dash = true, inner = false)
            "accentBorderCallout1" -> Art(box, detail = Path().apply { addPath(line(28, 0, 28, 62)); addPath(line(28, 31, 0, 96)) }, inner = false)
            "accentBorderCallout2" -> Art(box, detail = Path().apply { addPath(line(28, 0, 28, 62)); addPath(line(28, 31, 14, 31, 0, 96)) }, inner = false)
            "accentBorderCallout3" -> Art(box, detail = Path().apply { addPath(line(28, 0, 28, 62)); addPath(line(28, 31, 16, 31, 8, 62, 0, 96)) }, inner = false)
            else -> null
        }
    }
}
