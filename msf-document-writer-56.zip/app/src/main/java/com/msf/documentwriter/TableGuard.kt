package com.msf.documentwriter

import android.text.Editable
import android.text.InputFilter
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ParagraphStyle
import android.widget.EditText

/**
 * Keeps tables from being damaged while typing.
 *
 * A table lives in the text as |cell|cell| lines, so Enter, Backspace, Delete or a typed "|" inside a table used to tear the
 * lines apart. [TableFilter] lets only the text INSIDE a cell change: the bars and line ends of table rows can not be
 * deleted or typed over, Enter inside a cell moves to the same cell of the next row, and locked rows / columns can not be edited.
 * The table commands of the screen change the structure on purpose and run inside [TableGuard.free].
 */
object TableGuard {
    @JvmField var bypass = false

    inline fun <T> free(block: () -> T): T {
        val old = bypass
        bypass = true
        try { return block() } finally { bypass = old }
    }

    /** Removes the table drawing / layout spans from a copy of table text (they are rebuilt by the grid). */
    fun cleanSpans(sb: SpannableStringBuilder): SpannableStringBuilder {
        for (sp in sb.getSpans(0, sb.length, Any::class.java)) {
            if (sp is PipeSpan || sp is CellSpan || sp is SepSpan || sp is TableRowSpan || sp is TableStyleSpan ||
                sp is TableWidthSpan || sp is RowHeightSpan || sp is TableLockSpan
            ) sb.removeSpan(sp)
        }
        return sb
    }

    private fun pipeCount(s: String, a: Int, b: Int): Int {
        var n = 0
        for (i in a until b) if (s[i] == '|') n++
        return n
    }

    /** Makes every row of every table have as many cells as the widest row (a broken table is mended when it is opened). */
    fun repairAll(e: Editable) {
        val s = e.toString()
        if (s.indexOf('|') < 0) return
        val fixes = ArrayList<Pair<Int, String>>()
        var cur = ArrayList<IntArray>()
        fun flush() {
            if (cur.isEmpty()) return
            val counts = cur.map { pipeCount(s, it[0], it[1]) }
            val mx = counts.maxOrNull() ?: 0
            for ((i, ln) in cur.withIndex()) {
                val missing = mx - counts[i]
                if (missing > 0) fixes.add(Pair(ln[1], (if (ln[2] == 1) "---|" else "   |").repeat(missing)))
            }
            cur = ArrayList()
        }
        var ps = 0
        while (ps <= s.length) {
            val nl = s.indexOf('\n', ps)
            val pe = if (nl < 0) s.length else nl
            val line = s.substring(ps, pe)
            if (Tables.isRow(line)) cur.add(intArrayOf(ps, pe, if (Tables.isSeparator(line)) 1 else 0)) else flush()
            if (nl < 0) break
            ps = nl + 1
        }
        flush()
        for (f in fixes.asReversed()) e.insert(f.first, f.second)
    }
}

/** Locked rows / columns of one table (0-based, the |---| line is not a row). Covers the whole table like [TableWidthSpan]. */
class TableLockSpan(val rows: Set<Int>, val cols: Set<Int>) : ParagraphStyle

object TableLocks {
    class Lk(val rows: Set<Int>, val cols: Set<Int>) {
        val any: Boolean get() = rows.isNotEmpty() || cols.isNotEmpty()
    }

    val NONE = Lk(emptySet(), emptySet())

    fun at(t: CharSequence, a: Int, b: Int): Lk {
        if (t !is Spanned) return NONE
        val hi = b.coerceIn(0, t.length)
        val lo = a.coerceIn(0, hi)
        for (sp in t.getSpans(lo, maxOf(hi, lo), TableLockSpan::class.java)) {
            if (t.getSpanEnd(sp) > lo) return Lk(sp.rows, sp.cols)
        }
        return NONE
    }

    /** Locks of the table that contains [pos]. */
    fun get(e: Editable, pos: Int): Lk {
        val r = TableOps.tableRange(e, pos) ?: return NONE
        return at(e, r.first, r.second)
    }

    fun of(t: CharSequence, tb: TableBlock): Lk {
        val c0 = tb.rows.firstOrNull()?.firstOrNull()?.first ?: return NONE
        val c1 = tb.rows.lastOrNull()?.lastOrNull()?.second ?: c0
        var ps = c0.coerceIn(0, t.length)
        while (ps > 0 && t[ps - 1] != '\n') ps--
        return at(t, ps, c1)
    }

    fun set(e: Editable, pos: Int, rows: Set<Int>, cols: Set<Int>) {
        val r = TableOps.tableRange(e, pos) ?: return
        val a = r.first
        val b = r.second
        for (sp in e.getSpans(a, maxOf(b, a + 1).coerceAtMost(e.length), TableLockSpan::class.java)) e.removeSpan(sp)
        if (rows.isNotEmpty() || cols.isNotEmpty()) {
            val end = if (b < e.length) b + 1 else b
            if (end > a) e.setSpan(TableLockSpan(rows, cols), a, end, Spanned.SPAN_PARAGRAPH)
        }
    }
}

class TableFilter(private val et: EditText) : InputFilter {
    private var lastToast = 0L

    private fun blocked(msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastToast > 1500) { lastToast = now; toast(et.context, msg) }
    }

    private class L(val a: Int, val b: Int, val row: Boolean, val sep: Boolean)

    override fun filter(source: CharSequence, start: Int, end: Int, dest: Spanned, dstart: Int, dend: Int): CharSequence? {
        if (TableGuard.bypass) return null
        return try { guard(source, start, end, dest, dstart, dend) } catch (_: Throwable) { null }
    }

    private fun guard(source: CharSequence, start: Int, end: Int, dest: Spanned, dstart: Int, dend: Int): CharSequence? {
        if (dest !is Editable) return null
        // cheap test first: no bar on the lines that are touched = ordinary text
        var ls = dstart
        while (ls > 0 && dest[ls - 1] != '\n') ls--
        var le = dend
        while (le < dest.length && dest[le] != '\n') le++
        var hasBar = false
        for (i in ls until le) if (dest[i] == '|') { hasBar = true; break }
        if (!hasBar) return null

        val s = dest.toString()
        val lines = ArrayList<L>()
        var p = ls
        while (true) {
            val nl = s.indexOf('\n', p)
            val b = if (nl < 0) s.length else nl
            val t = s.substring(p, b)
            val r = Tables.isRow(t)
            lines.add(L(p, b, r, r && Tables.isSeparator(t)))
            if (b >= le) break
            p = b + 1
        }

        fun lineIdx(pos: Int): Int = lines.indexOfLast { it.a <= pos }.coerceAtLeast(0)
        fun pipesOf(ln: L): List<Int> {
            val out = ArrayList<Int>()
            for (i in ln.a until ln.b) if (s[i] == '|') out.add(i)
            return out
        }
        fun isRowLine(a: Int, b: Int): Boolean = b >= a && Tables.isRow(s.substring(a, b))
        fun prevIsRow(ln: L): Boolean {
            if (ln.a <= 0) return false
            var ps = ln.a - 1
            while (ps > 0 && s[ps - 1] != '\n') ps--
            return isRowLine(ps, ln.a - 1)
        }
        fun nextIsRow(ln: L): Boolean {
            if (ln.b >= s.length) return false
            val ns = ln.b + 1
            var ne = ns
            while (ne < s.length && s[ne] != '\n') ne++
            return isRowLine(ns, ne)
        }
        // (data row index, table locks) of a table row line
        fun rowInfo(ln: L): Pair<Int, TableLocks.Lk> {
            var a = ln.a
            var idx = 0
            while (a > 0) {
                var ps = a - 1
                while (ps > 0 && s[ps - 1] != '\n') ps--
                if (!isRowLine(ps, a - 1)) break
                if (!Tables.isSeparator(s.substring(ps, a - 1))) idx++
                a = ps
            }
            return Pair(idx, TableLocks.at(dest, a, a + 1))
        }
        fun lockedAt(ln: L, pos: Int): Boolean {
            if (!ln.row || ln.sep) return false
            val (idx, lk) = rowInfo(ln)
            if (!lk.any) return false
            if (lk.rows.contains(idx)) return true
            val pl = pipesOf(ln)
            val col = (pl.count { it < pos } - 1).coerceIn(0, maxOf(pl.size - 2, 0))
            return lk.cols.contains(col)
        }
        fun structural(pos: Int): Boolean {
            val i = lineIdx(pos)
            val ln = lines[i]
            if (pos == ln.b) {
                val nx = lines.getOrNull(i + 1)
                return ln.row || (nx != null && nx.row)
            }
            if (!ln.row) return false
            if (ln.sep) return true
            val pl = pipesOf(ln)
            if (pl.isEmpty()) return true
            return s[pos] == '|' || pos < pl.first() || pos > pl.last()
        }

        val oldLen = dend - dstart
        val prot = BooleanArray(oldLen)
        var anyProt = false
        var anyLocked = false
        for (k in 0 until oldLen) {
            val pos = dstart + k
            val st = structural(pos)
            val lk = !st && lockedAt(lines[lineIdx(pos)], pos)
            if (lk) anyLocked = true
            prot[k] = st || lk
            if (prot[k]) anyProt = true
        }

        val ins = source.subSequence(start, end)
        var sanitized: CharSequence = ins
        var dropIns = false
        var enter = false
        if (ins.isNotEmpty()) {
            if (anyProt) {
                dropIns = true
                if (anyLocked) blocked("یہ حصہ لاک ہے / This part is locked")
            } else {
                val ln = lines[lineIdx(dstart)]
                if (!ln.row) {
                    return null
                } else if (ln.sep) {
                    dropIns = true
                } else {
                    val pl = pipesOf(ln)
                    val isNl = ins.length == 1 && ins[0] == '\n'
                    val inside = pl.size >= 2 && dstart > pl.first() && dstart <= pl.last()
                    if (!inside) {
                        // before the first bar / after the last bar: only an Enter that leaves the table is allowed
                        val atTop = oldLen == 0 && isNl && dstart == ln.a && !prevIsRow(ln)
                        val atEnd = oldLen == 0 && isNl && dstart == ln.b && !nextIsRow(ln)
                        if (atTop || atEnd) return null
                        dropIns = true
                    } else if (lockedAt(ln, dstart)) {
                        dropIns = true
                        blocked("یہ خانہ لاک ہے / This cell is locked")
                    } else if (isNl) {
                        dropIns = true
                        enter = true
                    } else {
                        var changed = false
                        val sb = SpannableStringBuilder(ins)
                        var i = sb.length - 1
                        while (i >= 0) {
                            val ch = sb[i]
                            if (ch == '|' || ch == PAGE_BREAK) { sb.delete(i, i + 1); changed = true }
                            else if (ch == '\n' || ch == '\r') { sb.replace(i, i + 1, " "); changed = true }
                            i--
                        }
                        if (changed) sanitized = sb
                    }
                }
            }
        } else if (anyLocked && oldLen > 0) {
            blocked("یہ حصہ لاک ہے / This part is locked")
        }

        if (enter) {
            et.post {
                try {
                    val e2 = et.text
                    val pos = et.selectionStart.coerceIn(0, e2.length)
                    val inf = TableOps.info(e2, pos) ?: return@post
                    if (inf.row < inf.rows - 1) et.setSelection(TableOps.cellPos(e2, pos, inf.row + 1, inf.col).coerceIn(0, e2.length))
                } catch (_: Throwable) { }
            }
        }

        val untouched = !anyProt && !dropIns && sanitized === ins
        if (untouched) return null

        val out = SpannableStringBuilder()
        if (!anyProt && !dropIns) out.append(sanitized)
        for (k in 0 until oldLen) if (prot[k]) out.append(dest.subSequence(dstart + k, dstart + k + 1))
        return out
    }
}
