package com.msf.documentwriter

import android.graphics.Typeface
import android.text.Editable
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.AlignmentSpan
import android.text.style.BackgroundColorSpan
import android.text.style.CharacterStyle
import android.text.style.MetricAffectingSpan
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import android.widget.EditText
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.roundToInt

/** Superscript ([up] = true, like x²) or subscript (x₂): smaller text raised or lowered. Written to Word as w:vertAlign. */
class ScriptSpan(val up: Boolean) : MetricAffectingSpan() {
    override fun updateDrawState(tp: TextPaint) { shift(tp) }
    override fun updateMeasureState(tp: TextPaint) { shift(tp) }
    private fun shift(tp: TextPaint) {
        val a = tp.ascent()
        val d = (a / 2f).toInt()
        if (up) tp.baselineShift += d else tp.baselineShift -= d
        tp.textSize = tp.textSize * 0.65f
    }
}

/** Selection based formatting helpers for the editor's EditText. */
object Rich {
    fun range(et: EditText): Pair<Int, Int> {
        val str = et.text.toString()
        var s = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        var en = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        if (s == en) {
            s = str.lastIndexOf('\n', s - 1) + 1
            val nl = str.indexOf('\n', en)
            en = if (nl < 0) str.length else nl
        }
        return Pair(s, en)
    }

    private fun <T : Any> spans(e: Editable, s: Int, en: Int, cls: Class<T>): List<T> =
        e.getSpans(s, en, cls).filter { (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }

    private fun <T : Any> clear(e: Editable, s: Int, en: Int, cls: Class<T>, copy: (T) -> T, test: (T) -> Boolean = { true }) {
        for (sp in spans(e, s, en, cls)) {
            if (!test(sp)) continue
            val ss = e.getSpanStart(sp)
            val se = e.getSpanEnd(sp)
            val fl = e.getSpanFlags(sp)
            e.removeSpan(sp)
            if (ss < s) e.setSpan(copy(sp), ss, s, fl)
            if (se > en) e.setSpan(copy(sp), en, se, fl)
        }
    }

    private fun covered(e: Editable, s: Int, en: Int, list: List<Any>): Boolean {
        var pos = s
        val iv = list.map { Pair(maxOf(e.getSpanStart(it), s), minOf(e.getSpanEnd(it), en)) }.sortedBy { it.first }
        for ((a, b) in iv) {
            if (a > pos) return false
            if (b > pos) pos = b
            if (pos >= en) return true
        }
        return pos >= en
    }

    private fun toggleStyle(e: Editable, s: Int, en: Int, st: Int) {
        val has = covered(e, s, en, spans(e, s, en, StyleSpan::class.java).filter { it.style == st })
        clear(e, s, en, StyleSpan::class.java, { StyleSpan(it.style) }) { it.style == st }
        if (!has) e.setSpan(StyleSpan(st), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun bold(e: Editable, s: Int, en: Int) = toggleStyle(e, s, en, Typeface.BOLD)
    fun italic(e: Editable, s: Int, en: Int) = toggleStyle(e, s, en, Typeface.ITALIC)

    fun underline(e: Editable, s: Int, en: Int) {
        val has = covered(e, s, en, spans(e, s, en, UnderlineSpan::class.java))
        clear(e, s, en, UnderlineSpan::class.java, { UnderlineSpan() })
        if (!has) e.setSpan(UnderlineSpan(), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun strike(e: Editable, s: Int, en: Int) {
        val has = covered(e, s, en, spans(e, s, en, StrikethroughSpan::class.java))
        clear(e, s, en, StrikethroughSpan::class.java, { StrikethroughSpan() })
        if (!has) e.setSpan(StrikethroughSpan(), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    /** True when the whole range [s, en) is superscript ([up]) or subscript. */
    fun hasScript(e: Editable, s: Int, en: Int, up: Boolean): Boolean {
        val from = if (en > s) s else maxOf(s - 1, 0)
        val to = if (en > s) en else s
        if (to <= from) return false
        return covered(e, from, to, spans(e, from, to, ScriptSpan::class.java).filter { it.up == up })
    }

    /** Superscript / subscript toggle on the selection; the other kind is removed from it. */
    fun script(e: Editable, s: Int, en: Int, up: Boolean) {
        val has = covered(e, s, en, spans(e, s, en, ScriptSpan::class.java).filter { it.up == up })
        clear(e, s, en, ScriptSpan::class.java, { ScriptSpan(it.up) })
        if (!has) e.setSpan(ScriptSpan(up), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun pendingScript(e: Editable, pos: Int, up: Boolean) {
        val ex = pendingAt(e, pos, ScriptSpan::class.java)
        val same = ex.any { it.up == up }
        ex.forEach { e.removeSpan(it) }
        if (!same) e.setSpan(ScriptSpan(up), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun color(e: Editable, s: Int, en: Int, c: Int?) {
        clear(e, s, en, ForegroundColorSpan::class.java, { ForegroundColorSpan(it.foregroundColor) })
        if (c != null) e.setSpan(ForegroundColorSpan(c), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun highlight(e: Editable, s: Int, en: Int, c: Int?) {
        clear(e, s, en, BackgroundColorSpan::class.java, { BackgroundColorSpan(it.backgroundColor) })
        if (c != null) e.setSpan(BackgroundColorSpan(c), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun size(e: Editable, s: Int, en: Int, pt: Int) {
        clear(e, s, en, AbsoluteSizeSpan::class.java, { AbsoluteSizeSpan(it.size, it.dip) })
        e.setSpan(AbsoluteSizeSpan(pt, true), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    // ---- cursor without selection: formatting for the text typed next (zero-length spans that grow while typing) ----
    private fun <T : Any> pendingAt(e: Editable, pos: Int, cls: Class<T>): List<T> =
        e.getSpans(0, e.length, cls).filter { e.getSpanStart(it) == pos && e.getSpanEnd(it) == pos }

    private fun <T : Any> dropEmpty(e: Editable, cls: Class<T>) {
        for (sp in e.getSpans(0, e.length, cls)) if (e.getSpanStart(sp) == e.getSpanEnd(sp)) e.removeSpan(sp)
    }

    fun pendingStyle(e: Editable, pos: Int, st: Int) {
        val ex = pendingAt(e, pos, StyleSpan::class.java).filter { it.style == st }
        if (ex.isNotEmpty()) ex.forEach { e.removeSpan(it) }
        else e.setSpan(StyleSpan(st), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun pendingUnderline(e: Editable, pos: Int) {
        val ex = pendingAt(e, pos, UnderlineSpan::class.java)
        if (ex.isNotEmpty()) ex.forEach { e.removeSpan(it) }
        else e.setSpan(UnderlineSpan(), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun pendingStrike(e: Editable, pos: Int) {
        val ex = pendingAt(e, pos, StrikethroughSpan::class.java)
        if (ex.isNotEmpty()) ex.forEach { e.removeSpan(it) }
        else e.setSpan(StrikethroughSpan(), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun pendingColor(e: Editable, pos: Int, c: Int?) {
        dropEmpty(e, ForegroundColorSpan::class.java)
        if (c != null) e.setSpan(ForegroundColorSpan(c), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun pendingSize(e: Editable, pos: Int, pt: Int) {
        dropEmpty(e, AbsoluteSizeSpan::class.java)
        e.setSpan(AbsoluteSizeSpan(pt, true), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun pendingFont(e: Editable, pos: Int, family: String) {
        dropEmpty(e, TypefaceSpan::class.java)
        e.setSpan(FontSpan(family), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun font(e: Editable, s: Int, en: Int, family: String) {
        clear(e, s, en, TypefaceSpan::class.java, { FontSpan(it.family ?: "sans-serif") })
        e.setSpan(FontSpan(family), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun clearFormat(e: Editable, s: Int, en: Int) {
        clear(e, s, en, StyleSpan::class.java, { StyleSpan(it.style) })
        clear(e, s, en, UnderlineSpan::class.java, { UnderlineSpan() })
        clear(e, s, en, StrikethroughSpan::class.java, { StrikethroughSpan() })
        clear(e, s, en, ScriptSpan::class.java, { ScriptSpan(it.up) })
        clear(e, s, en, ForegroundColorSpan::class.java, { ForegroundColorSpan(it.foregroundColor) })
        clear(e, s, en, BackgroundColorSpan::class.java, { BackgroundColorSpan(it.backgroundColor) })
        clear(e, s, en, AbsoluteSizeSpan::class.java, { AbsoluteSizeSpan(it.size, it.dip) })
        clear(e, s, en, TypefaceSpan::class.java, { FontSpan(it.family ?: "sans-serif") })
    }

    /** Paragraph ranges (start, end-without-newline) touched by the selection/cursor. */
    fun paragraphs(et: EditText): List<Pair<Int, Int>> {
        val str = et.text.toString()
        val a = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val b = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        var ps = str.lastIndexOf('\n', a - 1) + 1
        val res = mutableListOf<Pair<Int, Int>>()
        while (true) {
            val nl = str.indexOf('\n', ps)
            val pe = if (nl < 0) str.length else nl
            res.add(Pair(ps, pe))
            if (nl < 0 || nl >= b) break
            ps = nl + 1
        }
        return res
    }

    /** mode: 0 left, 1 centre, 2 right (visual). */
    fun align(et: EditText, mode: Int) {
        val e = et.text
        for ((ps, pe) in paragraphs(et)) {
            val end = if (pe < e.length) pe + 1 else pe
            for (sp in e.getSpans(ps, end, AlignmentSpan.Standard::class.java)) e.removeSpan(sp)
            val lay = et.layout
            val dir = if (lay != null && e.isNotEmpty()) lay.getParagraphDirection(lay.getLineForOffset(minOf(ps, e.length))) else 1
            val ltr = dir == Layout.DIR_LEFT_TO_RIGHT
            val al = when (mode) {
                1 -> Layout.Alignment.ALIGN_CENTER
                2 -> if (ltr) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL
                else -> if (ltr) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_OPPOSITE
            }
            e.setSpan(AlignmentSpan.Standard(al), ps, end, Spanned.SPAN_PARAGRAPH)
        }
    }

    fun list(et: EditText, numbered: Boolean) {
        val e = et.text
        val ps = paragraphs(et)
        val bullet = Regex("^• ")
        val num = Regex("^\\d+\\. ")
        val rx = if (numbered) num else bullet
        val all = ps.all { (a, b) -> rx.containsMatchIn(e.subSequence(a, b)) }
        for (i in ps.indices.reversed()) {
            val (a, b) = ps[i]
            val line = e.subSequence(a, b).toString()
            val old = (bullet.find(line) ?: num.find(line))?.value
            if (all) {
                e.delete(a, a + (old?.length ?: 0))
            } else {
                if (old != null) e.delete(a, a + old.length)
                e.insert(a, if (numbered) "${i + 1}. " else "• ")
            }
        }
    }

    fun heading(et: EditText, level: Int) {
        val e = et.text
        for ((a, b) in paragraphs(et).reversed()) {
            if (b <= a) continue
            clear(e, a, b, AbsoluteSizeSpan::class.java, { AbsoluteSizeSpan(it.size, it.dip) })
            clear(e, a, b, StyleSpan::class.java, { StyleSpan(it.style) }) { it.style == Typeface.BOLD }
            if (level > 0) {
                e.setSpan(AbsoluteSizeSpan(if (level == 1) 28 else 22, true), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                e.setSpan(StyleSpan(Typeface.BOLD), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
    }
}

data class RichDoc(val text: SpannableStringBuilder, val size: Int, val rtl: Boolean, val justify: Boolean, val font: String?)

object RichDocx {
    private val DOT = RegexOption.DOT_MATCHES_ALL
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun unesc(s: String) =
        s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
    private fun rtlChar(ch: Char): Boolean {
        val d = Character.getDirectionality(ch)
        return d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
    }
    private fun hasRtl(s: String) = s.any { rtlChar(it) }
    private fun firstStrongRtl(s: String): Boolean {
        for (ch in s) {
            val d = Character.getDirectionality(ch)
            if (d == Character.DIRECTIONALITY_LEFT_TO_RIGHT) return false
            if (rtlChar(ch)) return true
        }
        return false
    }
    private fun hex(c: Int) = String.format("%06X", c and 0xFFFFFF)

    private fun paragraph(sp: Spanned, str: String, ps: Int, pe: Int, base: Int, docRtl: Boolean, justify: Boolean, font: String?, pbBefore: Boolean = false, boldAll: Boolean = false): String {
        val bidi = docRtl || firstStrongRtl(str.substring(ps, pe))
        val al = if (pe > ps) sp.getSpans(ps, pe, AlignmentSpan::class.java).firstOrNull()?.alignment else null
        val jc = when {
            al == Layout.Alignment.ALIGN_CENTER -> "<w:jc w:val=\"center\"/>"
            al == Layout.Alignment.ALIGN_OPPOSITE -> "<w:jc w:val=\"right\"/>"
            justify -> "<w:jc w:val=\"both\"/>"
            else -> ""
        }
        val ind = Para.find(sp, ps, ParaIndentSpan::class.java)
        val spc = Para.find(sp, ps, ParaSpaceSpan::class.java)
        var spAttr = ""
        if (spc != null) spAttr += " w:before=\"${(spc.beforePt * 20).roundToInt()}\" w:after=\"${(spc.afterPt * 20).roundToInt()}\""
        if (Doc.lineSpacing != 1f) spAttr += " w:line=\"${(240 * Doc.lineSpacing).roundToInt()}\" w:lineRule=\"auto\""
        val spXml = if (spAttr.isNotEmpty()) "<w:spacing$spAttr/>" else ""
        var indXml = ""
        if (ind != null) {
            val firstRel = ind.firstPt - ind.restPt
            val fl = if (firstRel >= 0f) " w:firstLine=\"${(firstRel * 20).roundToInt()}\"" else " w:hanging=\"${(-firstRel * 20).roundToInt()}\""
            indXml = "<w:ind w:left=\"${(ind.restPt * 20).roundToInt()}\"$fl/>"
        }
        val ppr = "<w:pPr>" + (if (pbBefore) "<w:pageBreakBefore/>" else "") + (if (bidi) "<w:bidi/>" else "") + spXml + indXml + jc + "</w:pPr>"
        if (pe <= ps) return "<w:p>$ppr</w:p>"
        val cuts = sortedSetOf(ps, pe)
        for (s in sp.getSpans(ps, pe, CharacterStyle::class.java)) {
            cuts.add(maxOf(ps, sp.getSpanStart(s)))
            cuts.add(minOf(pe, sp.getSpanEnd(s)))
        }
        val cl = cuts.toList()
        val runs = StringBuilder()
        for (i in 0 until cl.size - 1) {
            val a = cl[i]
            val b = cl[i + 1]
            if (b <= a) continue
            var bold = boldAll; var ital = false; var und = false; var strike = false; var vert = 0
            var color: Int? = null; var bg: Int? = null; var size = base; var fam = font
            for (s in sp.getSpans(a, b, CharacterStyle::class.java)) {
                if ((sp.getSpanFlags(s) and Spanned.SPAN_COMPOSING) != 0) continue
                when (s) {
                    is StyleSpan -> { if ((s.style and Typeface.BOLD) != 0) bold = true; if ((s.style and Typeface.ITALIC) != 0) ital = true }
                    is UnderlineSpan -> und = true
                    is StrikethroughSpan -> strike = true
                    is ScriptSpan -> vert = if (s.up) 1 else 2
                    is ForegroundColorSpan -> color = s.foregroundColor
                    is BackgroundColorSpan -> bg = s.backgroundColor
                    is AbsoluteSizeSpan -> size = s.size
                    is TypefaceSpan -> fam = s.family ?: fam
                    else -> {}
                }
            }
            val txt = str.substring(a, b)
            var rpr = ""
            if (fam != null) rpr += "<w:rFonts w:ascii=\"${esc(fam)}\" w:hAnsi=\"${esc(fam)}\" w:cs=\"${esc(fam)}\"/>"
            if (bold) rpr += "<w:b/><w:bCs/>"
            if (ital) rpr += "<w:i/><w:iCs/>"
            if (strike) rpr += "<w:strike/>"
            if (color != null) rpr += "<w:color w:val=\"${hex(color)}\"/>"
            rpr += "<w:sz w:val=\"${size * 2}\"/><w:szCs w:val=\"${size * 2}\"/>"
            if (und) rpr += "<w:u w:val=\"single\"/>"
            if (bg != null) rpr += "<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"${hex(bg)}\"/>"
            if (vert != 0) rpr += "<w:vertAlign w:val=\"${if (vert == 1) "superscript" else "subscript"}\"/>"
            if (bidi || hasRtl(txt)) rpr += "<w:rtl/>"
            val t = esc(txt).replace("\t", "</w:t><w:tab/><w:t xml:space=\"preserve\">").replace(PAGE_BREAK.toString(), "</w:t><w:br w:type=\"page\"/><w:t xml:space=\"preserve\">")
            runs.append("<w:r><w:rPr>$rpr</w:rPr><w:t xml:space=\"preserve\">$t</w:t></w:r>")
        }
        return "<w:p>$ppr$runs</w:p>"
    }

    private fun table(sp: Spanned, str: String, tb: TableBlock, base: Int, docRtl: Boolean, justify: Boolean, font: String?, textW: Int): String {
        val cols = tb.rows.maxOf { it.size }.coerceAtLeast(1)
        val cwl = TableWidths.twips(TableWidths.of(sp, tb, cols), cols, textW)
        val b = "w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"000000\""
        val sb = StringBuilder()
        sb.append("<w:tbl><w:tblPr>")
        if (docRtl) sb.append("<w:bidiVisual/>")
        sb.append("<w:tblW w:w=\"${cwl.sum()}\" w:type=\"dxa\"/>")
        sb.append("<w:tblBorders><w:top $b/><w:left $b/><w:bottom $b/><w:right $b/><w:insideH $b/><w:insideV $b/></w:tblBorders>")
        sb.append("<w:tblLayout w:type=\"fixed\"/>")
        sb.append("<w:tblCellMar><w:left w:w=\"100\" w:type=\"dxa\"/><w:right w:w=\"100\" w:type=\"dxa\"/></w:tblCellMar>")
        sb.append("<w:tblLook w:val=\"04A0\" w:firstRow=\"${if (tb.header) 1 else 0}\" w:lastRow=\"0\" w:firstColumn=\"0\" w:lastColumn=\"0\" w:noHBand=\"0\" w:noVBand=\"1\"/>")
        val tLk = TableLocks.of(sp, tb)
        if (tLk.any) sb.append("<w:tblDescription w:val=\"MSFLOCK;r=${tLk.rows.sorted().joinToString(",")};c=${tLk.cols.sorted().joinToString(",")}\"/>")
        sb.append("</w:tblPr><w:tblGrid>")
        for (i in 0 until cols) sb.append("<w:gridCol w:w=\"${cwl[i]}\"/>")
        sb.append("</w:tblGrid>")
        val tStyle = TableStyles.of(sp, tb)
        for ((ri, row) in tb.rows.withIndex()) {
            val head = tb.header && ri == 0
            sb.append("<w:tr>")
            val extraDp = RowHeights.of(sp, row)
            if (extraDp > 0.5f) sb.append("<w:trPr><w:trHeight w:val=\"${(base * 1.4f * 20f + 80f + extraDp * 15f).toInt()}\" w:hRule=\"atLeast\"/></w:trPr>")
            for (ci in 0 until cols) {
                val cell = row.getOrNull(ci)
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"${cwl[ci]}\" w:type=\"dxa\"/>")
                val fillHex = if (tStyle > 0) TableStyles.hex(TableStyles.fill(tStyle, ri)) else if (head) "E8EEF7" else null
                if (fillHex != null) sb.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"$fillHex\"/>")
                sb.append("</w:tcPr>")
                if (cell == null || cell.second <= cell.first) sb.append("<w:p/>")
                else sb.append(paragraph(sp, str, cell.first, cell.second, base, docRtl, justify, font, false, head))
                sb.append("</w:tc>")
            }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl>")
        return sb.toString()
    }

    fun write(
        f: File, t: CharSequence, base: Int, docRtl: Boolean, justify: Boolean, font: String?, paper: Int, land: Boolean,
        design: Int = 0, bg: ByteArray? = null, numbers: Boolean = false, mar: Mar? = null, border: Boolean = false, pn: PageNumCfg = PageNumCfg(),
        cols: Int = 1
    ) {
        val sp = SpannableStringBuilder(t)
        val str = sp.toString()
        val (w, h) = Paper.twips(paper, land)
        val spec = if (!land && bg != null) PageDesigns.spec(design) else null
        val marL = if (spec != null) (w * spec.mx).toInt() else (mar?.let { (it.l * 20f).toInt() } ?: 1440)
        val marR = if (spec != null) (w * spec.mx).toInt() else (mar?.let { (it.r * 20f).toInt() } ?: 1440)
        val marTop = if (spec != null) (h * spec.mt).toInt() else (mar?.let { (it.t * 20f).toInt() } ?: 1440)
        val marBottom = if (spec != null) (h * spec.mb).toInt() else (mar?.let { (it.b * 20f).toInt() } ?: 1440)
        val footerDist = if (spec != null) (marBottom - 480).coerceAtLeast(300) else 708

        val colSpace = 360
        val textColW = if (cols > 1) (w - marL - marR - (cols - 1) * colSpace) / cols else w - marL - marR
        val body = StringBuilder()
        var pbNext = false
        var lastWasTable = false
        for (blk in Tables.split(str, 0, str.length)) {
            if (blk is TableBlock) {
                if (pbNext) { body.append("<w:p><w:pPr><w:pageBreakBefore/></w:pPr></w:p>"); pbNext = false }
                body.append(table(sp, str, blk, base, docRtl, justify, font, textColW))
                lastWasTable = true
            } else if (blk is TextBlock) {
                var ps = blk.a
                while (true) {
                    val nl = str.indexOf('\n', ps)
                    val pe = if (nl < 0 || nl > blk.b) blk.b else nl
                    if (pe - ps == 1 && str[ps] == PAGE_BREAK) {
                        // a line that only holds the page-break marker: the next paragraph starts on a new page
                        pbNext = true
                    } else {
                        body.append(paragraph(sp, str, ps, pe, base, docRtl, justify, font, pbNext))
                        pbNext = false
                    }
                    if (pe >= blk.b) break
                    ps = pe + 1
                }
                lastWasTable = false
            }
        }
        if (lastWasTable || body.isEmpty()) body.append("<w:p/>")

        val pgBdr = if (border) "<w:pgBorders w:offsetFrom=\"page\">" + listOf("top","left","bottom","right").joinToString("") { "<w:$it w:val=\"single\" w:sz=\"6\" w:space=\"24\" w:color=\"000000\"/>" } + "</w:pgBorders>" else ""
        val pgMar = "<w:pgMar w:top=\"$marTop\" w:right=\"$marR\" w:bottom=\"$marBottom\" w:left=\"$marL\" w:header=\"708\" w:footer=\"$footerDist\" w:gutter=\"0\"/>"
        val ns = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
            "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
            "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
            "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\""
        val colsXml = if (cols > 1) "<w:cols w:num=\"$cols\" w:space=\"$colSpace\"/>" + (if (docRtl) "<w:bidi/>" else "") else ""
        val numInHeader = numbers && pn.loc == 0
        val numInFooter = numbers && pn.loc != 0
        val hasHeader = spec != null || numInHeader
        val hdrRef = if (hasHeader) "<w:headerReference w:type=\"default\" r:id=\"rId1\"/>" else ""
        val ftrRef = if (numInFooter) "<w:footerReference w:type=\"default\" r:id=\"rId2\"/>" else ""
        // "- 1 -" is written as a normal decimal number with a dash before and after it
        val dash = pn.fmt == PageNum.DASH || (border && pn.fmt == 0)
        val wFmt = if (pn.fmt == PageNum.DASH) "decimal" else PageNum.wordFmt[pn.fmt.coerceIn(0, PageNum.wordFmt.size - 1)]
        val pgNum = if (numbers) "<w:pgNumType w:fmt=\"$wFmt\" w:start=\"${pn.start}\"/>" else ""
        val jc = when (pn.align) { 0 -> "left"; 2 -> "right"; else -> "center" }
        val cached = if (dash) pn.start.toString() else PageNum.format(pn.start, pn.fmt)
        val numPara = "<w:p><w:pPr><w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/><w:jc w:val=\"$jc\"/></w:pPr>" +
            (if (dash) "<w:r><w:t xml:space=\"preserve\">- </w:t></w:r>" else "") +
            "<w:r><w:fldChar w:fldCharType=\"begin\"/></w:r>" +
            "<w:r><w:instrText xml:space=\"preserve\"> PAGE </w:instrText></w:r>" +
            "<w:r><w:fldChar w:fldCharType=\"separate\"/></w:r>" +
            "<w:r><w:t>$cached</w:t></w:r>" +
            "<w:r><w:fldChar w:fldCharType=\"end\"/></w:r>" +
            (if (dash) "<w:r><w:t xml:space=\"preserve\"> -</w:t></w:r>" else "") + "</w:p>"
        val doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document $ns><w:body>$body" +
            "<w:sectPr>$hdrRef$ftrRef<w:pgSz w:w=\"$w\" w:h=\"$h\"${if (land) " w:orient=\"landscape\"" else ""}/>$pgMar$pgBdr$pgNum$colsXml</w:sectPr></w:body></w:document>"
        val types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            (if (spec != null) "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" else "") +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            (if (hasHeader) "<Override PartName=\"/word/header1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml\"/>" else "") +
            (if (numInFooter) "<Override PartName=\"/word/footer1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml\"/>" else "") +
            "</Types>"
        val rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>"
        ZipOutputStream(FileOutputStream(f)).use { z ->
            fun put(name: String, text: String) { z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml", types)
            put("_rels/.rels", rels)
            put("word/document.xml", doc)
            if (hasHeader || numInFooter) {
                put("word/_rels/document.xml.rels",
                    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    (if (hasHeader) "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/header\" Target=\"header1.xml\"/>" else "") +
                    (if (numInFooter) "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer\" Target=\"footer1.xml\"/>" else "") +
                    "</Relationships>")
            }
            if (numInFooter) {
                put("word/footer1.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:ftr $ns>" + numPara + "</w:ftr>")
            }
            if (numInHeader && !(spec != null && bg != null)) {
                put("word/header1.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:hdr $ns>" + numPara + "</w:hdr>")
            }
            if (spec != null && bg != null) {
                val name = "page_design_${spec.id}.jpg"
                val emuW = w.toLong() * 635L
                val emuH = h.toLong() * 635L
                put("word/_rels/header1.xml.rels",
                    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/$name\"/></Relationships>")
                put("word/header1.xml",
                    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:hdr $ns>" +
                    "<w:p><w:pPr><w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/></w:pPr><w:r><w:drawing>" +
                    "<wp:anchor distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"0\" behindDoc=\"1\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\">" +
                    "<wp:simplePos x=\"0\" y=\"0\"/>" +
                    "<wp:positionH relativeFrom=\"page\"><wp:posOffset>0</wp:posOffset></wp:positionH>" +
                    "<wp:positionV relativeFrom=\"page\"><wp:posOffset>0</wp:posOffset></wp:positionV>" +
                    "<wp:extent cx=\"$emuW\" cy=\"$emuH\"/><wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/><wp:wrapNone/>" +
                    "<wp:docPr id=\"1\" name=\"PageDesign\"/><wp:cNvGraphicFramePr/>" +
                    "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:pic>" +
                    "<pic:nvPicPr><pic:cNvPr id=\"0\" name=\"$name\"/><pic:cNvPicPr/></pic:nvPicPr>" +
                    "<pic:blipFill><a:blip r:embed=\"rId1\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
                    "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$emuW\" cy=\"$emuH\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr>" +
                    "</pic:pic></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r></w:p>" + (if (numInHeader) numPara else "") + "</w:hdr>")
                z.putNextEntry(ZipEntry("word/media/$name")); z.write(bg); z.closeEntry()
            }
        }
    }

    /** Paper index + landscape flag of a .docx whose page size is one of ours, else null. */
    fun pageOf(f: File): Pair<Int, Boolean>? = try {
        java.util.zip.ZipFile(f).use { z ->
            val e = z.getEntry("word/document.xml") ?: return@use null
            val xml = z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
            val m = Regex("<w:pgSz [^>]*>").find(xml)?.value ?: return@use null
            val w = Regex("w:w=\"(\\d+)\"").find(m)?.groupValues?.get(1)?.toIntOrNull() ?: return@use null
            val h = Regex("w:h=\"(\\d+)\"").find(m)?.groupValues?.get(1)?.toIntOrNull() ?: return@use null
            Paper.fromTwips(w, h)
        }
    } catch (e: Throwable) { null }

    /** Column preset (1 Two, 2 Three) of a .docx that has 2 or 3 columns, else null. */
    fun colsOf(f: File): Int? = try {
        java.util.zip.ZipFile(f).use { z ->
            val e = z.getEntry("word/document.xml") ?: return@use null
            val xml = z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
            val m = Regex("<w:cols [^>]*>").find(xml)?.value ?: return@use null
            when (Regex("w:num=\"(\\d+)\"").find(m)?.groupValues?.get(1)?.toIntOrNull()) { 2 -> 1; 3 -> 2; else -> null }
        }
    } catch (e: Throwable) { null }

    /** True when a .docx written by this app has page numbers (a footer). */
    fun hasNumbers(f: File): Boolean = try {
        java.util.zip.ZipFile(f).use { z -> z.getEntry("word/footer1.xml") != null }
    } catch (e: Throwable) { false }

    /** Page-number settings of a .docx written by this app (null = no page numbers). */
    fun numbersOf(f: File): PageNumCfg? = try {
        java.util.zip.ZipFile(f).use { z ->
            fun text(name: String): String? = z.getEntry(name)?.let { e -> z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) } }
            val ftr = text("word/footer1.xml")
            val hdr = text("word/header1.xml")
            val inFooter = ftr != null && ftr.contains(" PAGE ")
            val inHeader = !inFooter && hdr != null && hdr.contains(" PAGE ")
            if (!inFooter && !inHeader) return@use null
            val part = (if (inFooter) ftr else hdr) ?: ""
            val align = when (Regex("<w:jc w:val=\"(\\w+)\"").find(part)?.groupValues?.get(1)) { "left", "start" -> 0; "right", "end" -> 2; else -> 1 }
            val doc = text("word/document.xml") ?: ""
            val pg = Regex("<w:pgNumType [^>]*>").find(doc)?.value ?: ""
            var fmt = PageNum.wordFmt.indexOf(Regex("w:fmt=\"(\\w+)\"").find(pg)?.groupValues?.get(1) ?: "decimal").coerceAtLeast(0)
            if (fmt == 0 && part.contains("> -</w:t>")) fmt = PageNum.DASH
            val start = Regex("w:start=\"(\\d+)\"").find(pg)?.groupValues?.get(1)?.toIntOrNull() ?: 1
            PageNumCfg(if (inFooter) 1 else 0, align, fmt, start.coerceAtLeast(1))
        }
    } catch (e: Throwable) { null }

    /** Margins (points) of a .docx when they differ from the classic 1 inch, else null. */
    fun marginsOf(f: File): Mar? = try {
        java.util.zip.ZipFile(f).use { z ->
            val e = z.getEntry("word/document.xml") ?: return@use null
            val xml = z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
            val m = Regex("<w:pgMar [^>]*>").find(xml)?.value ?: return@use null
            fun v(n: String): Float? = Regex("w:$n=\"(\\d+)\"").find(m)?.groupValues?.get(1)?.toFloatOrNull()?.div(20f)
            val mar = Mar(v("left") ?: return@use null, v("top") ?: return@use null, v("right") ?: return@use null, v("bottom") ?: return@use null)
            if (mar == Mar.all(72f)) null else mar
        }
    } catch (e: Throwable) { null }

    /** Page design stored in a .docx written by this app (0 when none). */
    fun designOf(f: File): Int = try {
        java.util.zip.ZipFile(f).use { z ->
            z.entries().asSequence().mapNotNull { Regex("word/media/page_design_(\\d+)\\.jpg").matchEntire(it.name)?.groupValues?.get(1)?.toIntOrNull() }.firstOrNull() ?: 0
        }
    } catch (e: Throwable) { 0 }

    private fun highlightColor(n: String): Int? = when (n.lowercase()) {
        "yellow" -> 0xFFFFFF00.toInt(); "green" -> 0xFF00FF00.toInt(); "cyan" -> 0xFF00FFFF.toInt()
        "magenta" -> 0xFFFF00FF.toInt(); "red" -> 0xFFFF0000.toInt(); "blue" -> 0xFF0000FF.toInt()
        "lightgray" -> 0xFFD3D3D3.toInt(); else -> null
    }

    fun parse(input: InputStream): RichDoc {
        val xml = Docx.zipTexts(input) { it == "word/document.xml" }["word/document.xml"] ?: ""
        val out = SpannableStringBuilder()
        var base = -1
        var anyRtl = false
        var justify = false
        var font: String? = null
        val token = Regex("<w:t(?: [^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br(?: [^>]*)?/>", DOT)
        fun addRuns(px: String) {
        for (r in Regex("<w:r[ >].*?</w:r>", DOT).findAll(px)) {
            val rx = r.value
            val rpr = Regex("<w:rPr>(.*?)</w:rPr>", DOT).find(rx)?.groupValues?.get(1) ?: ""
            val text = token.findAll(rx).joinToString("") {
                when {
                    it.value.startsWith("<w:tab") -> "\t"
                    it.value.startsWith("<w:br") -> if (it.value.contains("\"page\"")) PAGE_BREAK.toString() else "\n"
                    else -> unesc(it.groupValues[1])
                }
            }
            val rs = out.length
            out.append(text)
            val re = out.length
            if (re <= rs) continue
            val x = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            if (rpr.contains("<w:b/>") || Regex("<w:b w:val=\"(1|true|on)\"").containsMatchIn(rpr)) out.setSpan(StyleSpan(Typeface.BOLD), rs, re, x)
            if (rpr.contains("<w:i/>") || Regex("<w:i w:val=\"(1|true|on)\"").containsMatchIn(rpr)) out.setSpan(StyleSpan(Typeface.ITALIC), rs, re, x)
            if (rpr.contains("<w:u/>") || Regex("<w:u w:val=\"(?!none)\\w+\"").containsMatchIn(rpr)) out.setSpan(UnderlineSpan(), rs, re, x)
            if (rpr.contains("<w:strike/>")) out.setSpan(StrikethroughSpan(), rs, re, x)
            if (rpr.contains("w:vertAlign w:val=\"superscript\"")) out.setSpan(ScriptSpan(true), rs, re, x)
            else if (rpr.contains("w:vertAlign w:val=\"subscript\"")) out.setSpan(ScriptSpan(false), rs, re, x)
            Regex("<w:color w:val=\"([0-9A-Fa-f]{6})\"").find(rpr)?.let {
                out.setSpan(ForegroundColorSpan(0xFF000000.toInt() or it.groupValues[1].toInt(16)), rs, re, x)
            }
            val fill = Regex("<w:shd [^>]*w:fill=\"([0-9A-Fa-f]{6})\"").find(rpr)?.groupValues?.get(1)
            val hl = Regex("<w:highlight w:val=\"(\\w+)\"").find(rpr)?.groupValues?.get(1)
            if (fill != null) out.setSpan(BackgroundColorSpan(0xFF000000.toInt() or fill.toInt(16)), rs, re, x)
            else if (hl != null) highlightColor(hl)?.let { out.setSpan(BackgroundColorSpan(it), rs, re, x) }
            val sz = Regex("<w:sz w:val=\"(\\d+)\"").find(rpr)?.groupValues?.get(1)?.toIntOrNull()?.div(2)
            if (sz != null) {
                if (base < 0) base = sz
                if (sz != base) out.setSpan(AbsoluteSizeSpan(sz, true), rs, re, x)
            }
            val fam = Regex("<w:rFonts [^>]*?w:(?:ascii|cs)=\"([^\"]+)\"").find(rpr)?.groupValues?.get(1)
            if (fam != null) {
                if (font == null) font = fam
                else if (fam != font) out.setSpan(FontSpan(fam), rs, re, x)
            }
        }
        }
        val segs = Regex("<w:tbl>.*?</w:tbl>|<w:tbl [^>]*>.*?</w:tbl>|<w:p[ >].*?</w:p>|<w:p/>", DOT).findAll(xml).toList()
        for ((pi, sg) in segs.withIndex()) {
            val px = sg.value
            if (px.startsWith("<w:tbl")) {
                // a table becomes |cell|cell| lines (with a |---| line after a shaded header row)
                val rowsX = Regex("<w:tr[ >].*?</w:tr>", DOT).findAll(px).toList()
                val tStart = out.length
                val tLookHead = px.contains("w:firstRow=\"1\"")
                val tStyle = rowsX.firstOrNull()?.let { r0 ->
                    Regex("w:fill=\"([0-9A-Fa-f]{6})\"").find(r0.value)?.groupValues?.get(1)?.let { TableStyles.fromHex(it) }
                } ?: 0
                val rowStarts = ArrayList<Int>()
                for ((ri, rx) in rowsX.withIndex()) {
                    rowStarts.add(out.length)
                    out.append("|")
                    for (cx in Regex("<w:tc>.*?</w:tc>|<w:tc [^>]*>.*?</w:tc>", DOT).findAll(rx.value)) {
                        out.append(" ")
                        val cps = Regex("<w:p[ >].*?</w:p>|<w:p/>", DOT).findAll(cx.value).toList()
                        for ((k, cp) in cps.withIndex()) {
                            if (k > 0) out.append(" ")
                            if (cp.value.contains("<w:bidi")) anyRtl = true
                            addRuns(cp.value)
                        }
                        out.append(" |")
                    }
                    val last = pi == segs.size - 1 && ri == rowsX.size - 1
                    if (ri == 0 && (rx.value.contains("w:fill=\"E8EEF7\"") || tLookHead)) {
                        val n = Regex("<w:tc[ >]", DOT).findAll(rx.value).count().coerceAtLeast(1)
                        out.append("\n|").append("---|".repeat(n))
                    }
                    if (!last) out.append("\n")
                }
                if (out.length > tStart) {
                    val gw = Regex("<w:gridCol w:w=\"(\\d+)\"").findAll(px).map { it.groupValues[1].toFloat() }.toList()
                    val ncol = Regex("<w:tc[ >]", DOT).findAll(rowsX.firstOrNull()?.value ?: "").count()
                    if (gw.size == ncol && ncol > 1 && gw.sum() > 0f) {
                        val fr = TableWidths.normalize(gw.toFloatArray())
                        val eqW = 1f / ncol
                        if (fr.any { Math.abs(it - eqW) > 0.01f }) out.setSpan(TableWidthSpan(fr), tStart, out.length, Spanned.SPAN_PARAGRAPH)
                    }
                    Regex("<w:tblDescription w:val=\"MSFLOCK;r=([0-9,]*);c=([0-9,]*)\"").find(px)?.let { m ->
                        val lr = m.groupValues[1].split(',').mapNotNull { it.toIntOrNull() }.toSet()
                        val lc = m.groupValues[2].split(',').mapNotNull { it.toIntOrNull() }.toSet()
                        if (lr.isNotEmpty() || lc.isNotEmpty()) out.setSpan(TableLockSpan(lr, lc), tStart, out.length, Spanned.SPAN_PARAGRAPH)
                    }
                    for ((ri, rx) in rowsX.withIndex()) {
                        val hv = Regex("<w:trHeight w:val=\"(\\d+)\"").find(rx.value)?.groupValues?.get(1)?.toFloatOrNull() ?: continue
                        val extra = (hv - 400f) / 15f
                        if (extra < 1f) continue
                        val a = rowStarts[ri]
                        var b = out.toString().indexOf('\n', a)
                        b = if (b < 0) out.length else b + 1
                        if (b > a) out.setSpan(RowHeightSpan(extra, 2.75f), a, b, Spanned.SPAN_PARAGRAPH)
                    }
                }
                if (tStyle > 0 && out.length > tStart) {
                    val nl1 = out.toString().indexOf('\n', tStart)
                    val tEnd = if (nl1 < 0) out.length else nl1 + 1
                    out.setSpan(TableStyleSpan(tStyle), tStart, tEnd, Spanned.SPAN_PARAGRAPH)
                }
                continue
            }
            if (px.contains("<w:pageBreakBefore") && out.isNotEmpty()) out.append(PAGE_BREAK).append("\n")
            val ps = out.length
            if (px.contains("<w:bidi")) anyRtl = true
            val jc = Regex("<w:jc w:val=\"(\\w+)\"").find(px)?.groupValues?.get(1)
            addRuns(px)
            if (pi < segs.size - 1) out.append("\n")
            val al = when (jc) {
                "center" -> Layout.Alignment.ALIGN_CENTER
                "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
                else -> null
            }
            if (jc == "both") justify = true
            if (al != null) out.setSpan(AlignmentSpan.Standard(al), ps, out.length, Spanned.SPAN_PARAGRAPH)
            val pPr = Regex("<w:pPr>(.*?)</w:pPr>", DOT).find(px)?.groupValues?.get(1)?.replace(Regex("<w:rPr>.*?</w:rPr>", DOT), "") ?: ""
            fun attr(tag: String, name: String): Float? {
                val m = Regex("<w:$tag ([^>]*?)/?>").find(pPr) ?: return null
                return Regex("w:$name=\"(-?\\d+)\"").find(m.groupValues[1])?.groupValues?.get(1)?.toFloatOrNull()?.div(20f)
            }
            val iLeft = (attr("ind", "left") ?: attr("ind", "start") ?: 0f).coerceAtLeast(0f)
            val iFirst = (iLeft + (attr("ind", "firstLine") ?: 0f) - (attr("ind", "hanging") ?: 0f)).coerceAtLeast(0f)
            if (iLeft > 0f || iFirst > 0f) out.setSpan(ParaIndentSpan(iFirst, iLeft), ps, out.length, Spanned.SPAN_PARAGRAPH)
            val sBefore = (attr("spacing", "before") ?: 0f).coerceAtLeast(0f)
            val sAfter = (attr("spacing", "after") ?: 0f).coerceAtLeast(0f)
            if (sBefore > 0f || sAfter > 0f) out.setSpan(ParaSpaceSpan(sBefore, sAfter), ps, out.length, Spanned.SPAN_PARAGRAPH)
        }
        return RichDoc(out, if (base < 0) 11 else base, anyRtl, justify, font)
    }
}
