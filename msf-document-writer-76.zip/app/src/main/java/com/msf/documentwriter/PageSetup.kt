package com.msf.documentwriter

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

/** Page margins in points (left, top, right, bottom). A null [Mar] in [Doc] means the classic margins. */
data class Mar(val l: Float, val t: Float, val r: Float, val b: Float) {
    companion object { fun all(v: Float) = Mar(v, v, v, v) }
}

/** Page number settings: loc 0 = header, 1 = footer; align 0 left, 1 center, 2 right; fmt = index into [PageNum.names]; start = first number. */
data class PageNumCfg(val loc: Int = 1, val align: Int = 1, val fmt: Int = 0, val start: Int = 1)

/** Number formats of the Page Number dialog and the text drawn for every page. */
object PageNum {
    const val DASH = 17

    val names = listOf(
        "1, 2, 3", "I, II, III", "i, ii, iii", "A, B, C", "a, b, c", "1st, 2nd, 3rd", "One, Two, Three", "First, Second, Third",
        "ア, イ, ウ", "イ, ロ, ハ", "壱, 弐, 参", "①, ②, ③", "１, ２, ３", "甲, 乙, 丙", "子, 丑, 寅", "一, 二, 三", "壹, 貳, 叁", "- 1 -, - 2 -, - 3 -"
    )

    /** The matching w:numFmt of Word (used in w:pgNumType). */
    val wordFmt = listOf(
        "decimal", "upperRoman", "lowerRoman", "upperLetter", "lowerLetter", "ordinal", "cardinalText", "ordinalText",
        "aiueo", "iroha", "japaneseLegal", "decimalEnclosedCircle", "decimalFullWidth", "ideographTraditional", "ideographZodiac",
        "japaneseCounting", "ideographLegalTraditional", "decimal"
    )

    /** Text of page number [page] (1 = first page of the document). */
    fun label(page: Int, cfg: PageNumCfg, border: Boolean = false): String {
        val n = cfg.start + page - 1
        return if (border && cfg.fmt == 0) "- $n -" else format(n, cfg.fmt)
    }

    fun format(n: Int, f: Int): String {
        if (n < 1) return n.toString()
        return when (f) {
            1 -> roman(n, true)
            2 -> roman(n, false)
            3 -> letters(n, true)
            4 -> letters(n, false)
            5 -> ordinal(n)
            6 -> words(n, false)
            7 -> words(n, true)
            8 -> pick("アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン", n)
            9 -> pick("イロハニホヘトチリヌルヲワカヨタレソツネナラムウヰノオクヤマケフコエテアサキユメミシヱヒモセス", n)
            10 -> cjk(n, "零壱弐参四五六七八九", "拾百千")
            11 -> circled(n)
            12 -> n.toString().map { '０' + (it - '0') }.joinToString("")
            13 -> "甲乙丙丁戊己庚辛壬癸"[(n - 1) % 10].toString()
            14 -> "子丑寅卯辰巳午未申酉戌亥"[(n - 1) % 12].toString()
            15 -> cjk(n, "〇一二三四五六七八九", "十百千")
            16 -> cjk(n, "零壹貳叁肆伍陸柒捌玖", "拾佰仟")
            DASH -> "- $n -"
            else -> n.toString()
        }
    }

    private fun pick(s: String, n: Int): String = if (n in 1..s.length) s[n - 1].toString() else n.toString()

    private fun roman(n: Int, upper: Boolean): String {
        if (n >= 4000) return n.toString()
        val v = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
        val s = arrayOf("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")
        var x = n
        val sb = StringBuilder()
        for (i in v.indices) while (x >= v[i]) { sb.append(s[i]); x -= v[i] }
        return if (upper) sb.toString() else sb.toString().lowercase()
    }

    /** A..Z, AA..ZZ, AAA... (the way Word numbers with letters). */
    private fun letters(n: Int, upper: Boolean): String {
        val base = if (upper) 'A'.code else 'a'.code
        val ch = (base + (n - 1) % 26).toChar()
        return ch.toString().repeat((n - 1) / 26 + 1)
    }

    private fun ordinal(n: Int): String {
        val s = when {
            n % 100 in 11..13 -> "th"
            n % 10 == 1 -> "st"
            n % 10 == 2 -> "nd"
            n % 10 == 3 -> "rd"
            else -> "th"
        }
        return "$n$s"
    }

    private val ones = arrayOf(
        "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve",
        "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"
    )
    private val tens = arrayOf("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")

    private fun cardinal(n: Int): String = when {
        n < 20 -> ones[n]
        n < 100 -> tens[n / 10] + (if (n % 10 != 0) "-" + ones[n % 10] else "")
        n < 1000 -> ones[n / 100] + " hundred" + (if (n % 100 != 0) " " + cardinal(n % 100) else "")
        n < 10000 -> ones[n / 1000] + " thousand" + (if (n % 1000 != 0) " " + cardinal(n % 1000) else "")
        else -> n.toString()
    }

    private fun words(n: Int, ord: Boolean): String {
        val c = cardinal(n)
        if (c[0].isDigit()) return c
        var s = c
        if (ord) {
            val cut = maxOf(s.lastIndexOf(' '), s.lastIndexOf('-')) + 1
            val head = s.substring(0, cut)
            val last = s.substring(cut)
            val o = when (last) {
                "one" -> "first"; "two" -> "second"; "three" -> "third"; "five" -> "fifth"
                "eight" -> "eighth"; "nine" -> "ninth"; "twelve" -> "twelfth"
                else -> if (last.endsWith("y")) last.dropLast(1) + "ieth" else last + "th"
            }
            s = head + o
        }
        return s.replaceFirstChar { it.uppercase() }
    }

    private fun circled(n: Int): String = when (n) {
        in 1..20 -> (0x2460 + n - 1).toChar().toString()
        in 21..35 -> (0x3251 + n - 21).toChar().toString()
        in 36..50 -> (0x32B1 + n - 36).toChar().toString()
        else -> n.toString()
    }

    /** East-Asian numerals up to 9999: [d] = the ten digits (0..9), [u] = ten / hundred / thousand. */
    private fun cjk(n: Int, d: String, u: String): String {
        if (n >= 10000) return n.toString()
        if (n < 10) return d[n].toString()
        val sb = StringBuilder()
        var zero = false
        fun put(v: Int, unit: Char?) {
            if (v == 0) { if (sb.isNotEmpty()) zero = true; return }
            if (zero) { sb.append(d[0]); zero = false }
            val skipOne = unit != null && unit == u[0] && v == 1 && n in 10..19
            if (!skipOne) sb.append(d[v])
            if (unit != null) sb.append(unit)
        }
        put(n / 1000, u[2])
        put(n / 100 % 10, u[1])
        put(n / 10 % 10, u[0])
        put(n % 10, null)
        return sb.toString()
    }
}

// ───────────────────────── shared dark UI pieces

val PsScheme = darkColorScheme(
    primary = Color(0xFF4A7BE8),
    surface = Color(0xFF383838),
    surfaceTint = Color(0xFF383838),
    onSurface = Color.White,
    background = Color.Black
)
private val PsLine = Color(0xFF8A8A8A)
private val PsAccent = Color(0xFF4A7BE8)
private val PsGrey = Color(0xFF8E8E8E)
private val PsHandle = Color(0xFF6CB4EE)

@Composable
private fun PsTriangle(modifier: Modifier = Modifier.size(width = 13.dp, height = 7.dp)) {
    Canvas(modifier) {
        val p = Path()
        p.moveTo(0f, 0f)
        p.lineTo(size.width, 0f)
        p.lineTo(size.width / 2f, size.height)
        p.close()
        drawPath(p, Color.White)
    }
}

/** Underlined field with a small white arrow; tapping opens a dark pop-up list laid over the field (like the mock-up). */
@Composable
private fun PsDropdown(value: String, items: List<String>, centered: Boolean, modifier: Modifier = Modifier, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    var wPx by remember { mutableIntStateOf(0) }
    val dens = LocalDensity.current
    Box(modifier.onSizeChanged { wPx = it.width }) {
        Row(
            Modifier.fillMaxWidth().height(48.dp).clickable { open = true }.padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                value, color = Color.White, fontSize = 17.sp, maxLines = 1,
                textAlign = if (centered) TextAlign.Center else TextAlign.Start,
                modifier = Modifier.weight(1f)
            )
            PsTriangle()
            Spacer(Modifier.width(2.dp))
        }
        Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(1.dp).background(if (open) PsAccent else PsLine))
        DropdownMenu(
            expanded = open,
            onDismissRequest = { open = false },
            modifier = Modifier.width(with(dens) { wPx.toDp() }),
            offset = DpOffset(0.dp, (-48).dp)
        ) {
            items.forEachIndexed { i, s ->
                DropdownMenuItem(
                    text = { Text(s, color = Color.White, fontSize = 17.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
                    onClick = { open = false; onPick(i) }
                )
            }
        }
    }
}

// ───────────────────────── Page Number dialog

@Composable
fun PageNumberDialog(cfg: PageNumCfg, onOk: (PageNumCfg) -> Unit, onCancel: () -> Unit) {
    var loc by remember { mutableIntStateOf(cfg.loc.coerceIn(0, 1)) }
    var align by remember { mutableIntStateOf(cfg.align.coerceIn(0, 2)) }
    var fmt by remember { mutableIntStateOf(cfg.fmt.coerceIn(0, PageNum.names.size - 1)) }
    var start by remember { mutableStateOf(cfg.start.toString()) }
    val locNames = listOf("Header", "Footer")
    val alignNames = listOf("Left", "Center", "Right")
    fun startNow(): Int = start.toIntOrNull()?.coerceIn(1, 99999) ?: 1

    MaterialTheme(colorScheme = PsScheme) {
        Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(
                color = Color(0xFF212121), shape = RoundedCornerShape(2.dp),
                modifier = Modifier.padding(horizontal = 30.dp).fillMaxWidth()
            ) {
                Column(Modifier.padding(start = 21.dp, end = 21.dp, top = 22.dp, bottom = 10.dp)) {
                    Text("Page Number", color = Color.White, fontSize = 21.sp)
                    Spacer(Modifier.height(14.dp))
                    PsFormRow("Location:") { PsDropdown(locNames[loc], locNames, false) { loc = it } }
                    PsFormRow("Alignment:") { PsDropdown(alignNames[align], alignNames, false) { align = it } }
                    PsFormRow("Number\nFormat:") { PsDropdown(PageNum.names[fmt], PageNum.names, false) { fmt = it } }
                    PsFormRow("Start\nNumber:") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.width(92.dp)) {
                                BasicTextField(
                                    value = start,
                                    onValueChange = { v -> start = v.filter { it.isDigit() }.take(5) },
                                    singleLine = true,
                                    textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
                                    cursorBrush = SolidColor(Color.White),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 8.dp, bottom = 8.dp)
                                )
                                Box(Modifier.fillMaxWidth().height(2.dp).background(PsAccent))
                            }
                            Spacer(Modifier.weight(1f))
                            PsStepper(plus = false) { start = (startNow() - 1).coerceAtLeast(1).toString() }
                            PsStepper(plus = true) { start = (startNow() + 1).coerceAtMost(99999).toString() }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Cancel", color = Color.White, fontSize = 20.sp,
                            modifier = Modifier.clickable { onCancel() }.padding(end = 18.dp, top = 10.dp, bottom = 10.dp)
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            "OK", color = Color.White, fontSize = 20.sp,
                            modifier = Modifier.clickable { onOk(PageNumCfg(loc, align, fmt, startNow())) }.padding(start = 18.dp, end = 4.dp, top = 10.dp, bottom = 10.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PsFormRow(label: String, field: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 17.sp, lineHeight = 22.sp, modifier = Modifier.width(84.dp))
        Box(Modifier.weight(1f)) { field() }
    }
}

/** A thin "−" or "+" sign button. */
@Composable
private fun PsStepper(plus: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(width = 52.dp, height = 44.dp).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(24.dp)) {
            val w = 2.dp.toPx()
            drawLine(Color(0xFFD0D0D0), Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), w)
            if (plus) drawLine(Color(0xFFD0D0D0), Offset(size.width / 2f, 0f), Offset(size.width / 2f, size.height), w)
        }
    }
}

// ───────────────────────── Page Setup screen

private fun fmtOne(v: Float): String = String.format(Locale.US, "%.1f", v)

/**
 * Full-screen "Page Setup": page size, orientation, unit (cm / inch) and a page sketch whose four margins are changed
 * with the blue arrows (tap = 0.1 step, drag = free). Every change is applied at once.
 */
@Composable
fun PageSetupScreen(paper: Int, land: Boolean, mar: Mar, onPaper: (Int, Boolean) -> Unit, onMar: (Mar?) -> Unit, onBack: () -> Unit, onPageNumber: () -> Unit = {}) {
    val ctx = LocalContext.current
    var showHeader by remember { mutableStateOf(false) }
    var showPresets by remember { mutableStateOf(false) }
    var headerShown by remember { mutableStateOf(Doc.headerText) }
    val dens = LocalDensity.current
    var unit by remember { mutableIntStateOf(Prefs.int(ctx, "marunit", 1).coerceIn(0, 1)) }   // 0 = cm, 1 = inch
    val unitPt = if (unit == 1) 72f else 72f / 2.54f
    val unitName = if (unit == 1) "in" else "cm"
    val sizeNames = Paper.setupOrder.map { Paper.get(it).name }
    val pt = Paper.pt(paper, land)
    val pwPt = pt.first.toFloat()
    val phPt = pt.second.toFloat()
    val curMar by rememberUpdatedState(mar)
    val minContent = 72f

    fun snap(v: Float): Float = (v / unitPt * 10f).roundToInt() / 10f * unitPt
    fun setEdge(edge: Int, v0: Float) {
        val m = curMar
        when (edge) {
            0 -> onMar(m.copy(l = v0.coerceIn(0f, (pwPt - minContent - m.r).coerceAtLeast(0f))))
            1 -> onMar(m.copy(t = v0.coerceIn(0f, (phPt - minContent - m.b).coerceAtLeast(0f))))
            2 -> onMar(m.copy(r = v0.coerceIn(0f, (pwPt - minContent - m.l).coerceAtLeast(0f))))
            else -> onMar(m.copy(b = v0.coerceIn(0f, (phPt - minContent - m.t).coerceAtLeast(0f))))
        }
    }
    fun edgeVal(edge: Int): Float = when (edge) { 0 -> curMar.l; 1 -> curMar.t; 2 -> curMar.r; else -> curMar.b }
    /** Applies a Word-style margin preset; the sides are shrunk together if the paper is too small for them. */
    fun applyPreset(p: MarPreset) {
        var l = p.l * 72f
        var r = p.r * 72f
        var t = p.t * 72f
        var b = p.b * 72f
        val roomW = (pwPt - minContent).coerceAtLeast(0f)
        val roomH = (phPt - minContent).coerceAtLeast(0f)
        if (l + r > roomW && l + r > 0f) { val k = roomW / (l + r); l *= k; r *= k }
        if (t + b > roomH && t + b > 0f) { val k = roomH / (t + b); t *= k; b *= k }
        onMar(Mar(l, t, r, b))
    }

    BackHandler { onBack() }
    MaterialTheme(colorScheme = PsScheme) {
        Column(
            Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { detectTapGestures { } }
        ) {
            // top bar
            Row(Modifier.fillMaxWidth().height(56.dp).background(Color(0xFF111111)), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clickable { onBack() }, contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(width = 12.dp, height = 20.dp)) {
                        val w = 2.dp.toPx()
                        drawLine(Color(0xFFD0D0D0), Offset(size.width, 0f), Offset(0f, size.height / 2f), w)
                        drawLine(Color(0xFFD0D0D0), Offset(0f, size.height / 2f), Offset(size.width, size.height), w)
                    }
                }
                Text("Page Setup", color = Color.White, fontSize = 19.sp)
            }
            Column(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 13.dp)) {
                Spacer(Modifier.height(6.dp))
                PsSetupRow("Page Size:") {
                    PsDropdown(Paper.get(paper).name, sizeNames, true) { i -> onPaper(Paper.setupOrder[i], land) }
                }
                Spacer(Modifier.height(12.dp))
                PsSetupRow("Orientation:") {
                    PsDropdown(if (land) "Landscape" else "Portrait", listOf("Portrait", "Landscape"), true) { i -> onPaper(paper, i == 1) }
                }
                Spacer(Modifier.height(12.dp))
                PsSetupRow("Header:") {
                    Row(
                        Modifier.fillMaxWidth().height(48.dp).clickable { showHeader = true }.padding(horizontal = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            headerShown.ifBlank { "None  (tap to add)  /  ہیڈر لکھیں" }, color = if (headerShown.isBlank()) PsGrey else Color.White,
                            fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f)
                        )
                        Text("Edit", color = PsHandle, fontSize = 15.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                PsSetupRow("Margins:") {
                    Box(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().height(48.dp).clickable { showPresets = true }.padding(horizontal = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(presetOf(mar)?.name ?: "Custom Margins", color = Color.White, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f))
                            PsTriangle()
                            Spacer(Modifier.width(2.dp))
                        }
                        Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(1.dp).background(PsLine))
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF2A2A2A)))
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Page Margins:", color = PsGrey, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    PsDropdown(if (unit == 1) "inch" else "cm", listOf("cm", "inch"), true, Modifier.width(122.dp)) { i ->
                        unit = i
                        Prefs.setInt(ctx, "marunit", i)
                    }
                }
                Spacer(Modifier.height(8.dp))
                BoxWithConstraints(
                    Modifier.fillMaxWidth().weight(1f).background(Color(0xFF161616)).border(1.dp, Color(0xFF2A2A2A))
                ) {
                    val padPx = with(dens) { 24.dp.toPx() }
                    val labelH = with(dens) { 30.dp.toPx() }
                    val labelW = with(dens) { 36.dp.toPx() }
                    val availW = with(dens) { maxWidth.toPx() } - 2 * padPx - labelW
                    val availH = with(dens) { maxHeight.toPx() } - 2 * padPx - labelH
                    val scale = (min(availW / pwPt, availH / phPt)).coerceAtLeast(0.05f)   // pixels per point
                    val pagePxW = pwPt * scale
                    val pagePxH = phPt * scale
                    val contPxW = pagePxW + 2 * padPx
                    val contPxH = pagePxH + 2 * padPx
                    val hs = with(dens) { 44.dp.toPx() }
                    val m = mar

                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(with(dens) { contPxW.toDp() }, with(dens) { contPxH.toDp() })) {
                                // the paper
                                Box(
                                    Modifier.offset { IntOffset(padPx.roundToInt(), padPx.roundToInt()) }
                                        .size(with(dens) { pagePxW.toDp() }, with(dens) { pagePxH.toDp() })
                                        .background(Color.White)
                                )
                                // the text area (inside the margins)
                                val ix = padPx + m.l * scale
                                val iy = padPx + m.t * scale
                                val iw = (pwPt - m.l - m.r) * scale
                                val ih = (phPt - m.t - m.b) * scale
                                Box(
                                    Modifier.offset { IntOffset(ix.roundToInt(), iy.roundToInt()) }
                                        .size(with(dens) { iw.toDp() }, with(dens) { ih.toDp() })
                                        .background(Color(0xFFE8F0F8)).border(1.dp, Color(0xFF7DB2E8)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "Top " + fmtOne(m.t / unitPt) + "   Bottom " + fmtOne(m.b / unitPt) + "\nLeft " + fmtOne(m.l / unitPt) + "   Right " + fmtOne(m.r / unitPt) + "  ($unitName)",
                                        color = Color(0xFF5B7FA6), fontSize = 11.sp, lineHeight = 16.sp, textAlign = TextAlign.Center
                                    )
                                }
                                val step = 0.1f * unitPt
                                // top
                                EdgeHandle(
                                    vertical = true,
                                    modifier = Modifier.offset { IntOffset((padPx + pagePxW / 2f - hs / 2f).roundToInt(), (iy - hs / 2f).roundToInt()) }.size(with(dens) { hs.toDp() }),
                                    onTap = { d -> setEdge(1, snap(edgeVal(1)) + d * step) },
                                    key = 1, startOf = { edgeVal(1) }, sign = 1f, scale = scale, snapTo = { snap(it) }, setTo = { setEdge(1, it) }
                                )
                                // bottom
                                EdgeHandle(
                                    vertical = true,
                                    modifier = Modifier.offset { IntOffset((padPx + pagePxW / 2f - hs / 2f).roundToInt(), (iy + ih - hs / 2f).roundToInt()) }.size(with(dens) { hs.toDp() }),
                                    onTap = { d -> setEdge(3, snap(edgeVal(3)) - d * step) },
                                    key = 3, startOf = { edgeVal(3) }, sign = -1f, scale = scale, snapTo = { snap(it) }, setTo = { setEdge(3, it) }
                                )
                                // left
                                EdgeHandle(
                                    vertical = false,
                                    modifier = Modifier.offset { IntOffset((ix - hs / 2f).roundToInt(), (padPx + pagePxH / 2f - hs / 2f).roundToInt()) }.size(with(dens) { hs.toDp() }),
                                    onTap = { d -> setEdge(0, snap(edgeVal(0)) + d * step) },
                                    key = 0, startOf = { edgeVal(0) }, sign = 1f, scale = scale, snapTo = { snap(it) }, setTo = { setEdge(0, it) }
                                )
                                // right
                                EdgeHandle(
                                    vertical = false,
                                    modifier = Modifier.offset { IntOffset((ix + iw - hs / 2f).roundToInt(), (padPx + pagePxH / 2f - hs / 2f).roundToInt()) }.size(with(dens) { hs.toDp() }),
                                    onTap = { d -> setEdge(2, snap(edgeVal(2)) - d * step) },
                                    key = 2, startOf = { edgeVal(2) }, sign = -1f, scale = scale, snapTo = { snap(it) }, setTo = { setEdge(2, it) }
                                )
                            }
                            // page height (right side)
                            Box(Modifier.width(36.dp).height(with(dens) { contPxH.toDp() }), contentAlignment = Alignment.Center) {
                                Text(
                                    fmtOne(phPt / unitPt) + " " + unitName, color = Color(0xFFBDBDBD), fontSize = 14.sp, maxLines = 1,
                                    textAlign = TextAlign.Center, modifier = Modifier.requiredWidth(90.dp).rotate(90f)
                                )
                            }
                        }
                        // page width (below)
                        Text(
                            fmtOne(pwPt / unitPt) + " " + unitName, color = Color(0xFFBDBDBD), fontSize = 14.sp,
                            modifier = Modifier.height(30.dp).padding(top = 4.dp)
                        )
                    }
                    Text(
                        "Default", color = PsHandle, fontSize = 14.sp,
                        modifier = Modifier.align(Alignment.TopStart).clickable { onMar(null) }.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
                Spacer(Modifier.height(6.dp))
            }
        }
        if (showPresets) MarginPresetsDialog(
            cur = mar, unit = unit,
            onPick = { p -> showPresets = false; applyPreset(p) },
            onClose = { showPresets = false }
        )
        if (showHeader) HeaderDialog(
            onPageNumber = { showHeader = false; onPageNumber() },
            onDone = { showHeader = false; headerShown = Doc.headerText },
            onCancel = { showHeader = false }
        )
    }
}

@Composable
private fun PsSetupRow(label: String, field: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = PsGrey, fontSize = 15.sp, modifier = Modifier.width(72.dp))
        Box(Modifier.weight(1f)) { field() }
    }
}

/**
 * The pair of small blue arrows on one edge of the text area. Tap an arrow = move the edge one step (the arrow's direction);
 * drag = move it freely. [sign] is +1 when dragging down/right makes the margin bigger, -1 when it makes it smaller.
 */
@Composable
private fun EdgeHandle(
    vertical: Boolean, modifier: Modifier, onTap: (Int) -> Unit,
    key: Int, startOf: () -> Float, sign: Float, scale: Float, snapTo: (Float) -> Float, setTo: (Float) -> Unit
) {
    val tap by rememberUpdatedState(onTap)
    val startVal by rememberUpdatedState(startOf)
    val sc by rememberUpdatedState(scale)
    val snapper by rememberUpdatedState(snapTo)
    val setter by rememberUpdatedState(setTo)
    Box(
        modifier
            .pointerInput(key, vertical) {
                detectTapGestures { o ->
                    val half = if (vertical) size.height / 2f else size.width / 2f
                    val p = if (vertical) o.y else o.x
                    tap(if (p < half) -1 else 1)
                }
            }
            .pointerInput(key, vertical) {
                var acc = 0f
                var base = 0f
                detectDragGestures(
                    onDragStart = { acc = 0f; base = startVal() },
                    onDrag = { change, d ->
                        change.consume()
                        acc += if (vertical) d.y else d.x
                        setter(snapper(base + sign * acc / sc))
                    }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val a = 5.dp.toPx()
            val n = 4.dp.toPx()
            val f = 10.dp.toPx()
            val p1 = Path()
            val p2 = Path()
            if (vertical) {
                p1.moveTo(cx - a, cy - n); p1.lineTo(cx + a, cy - n); p1.lineTo(cx, cy - f); p1.close()
                p2.moveTo(cx - a, cy + n); p2.lineTo(cx + a, cy + n); p2.lineTo(cx, cy + f); p2.close()
            } else {
                p1.moveTo(cx - n, cy - a); p1.lineTo(cx - n, cy + a); p1.lineTo(cx - f, cy); p1.close()
                p2.moveTo(cx + n, cy - a); p2.lineTo(cx + n, cy + a); p2.lineTo(cx + f, cy); p2.close()
            }
            drawPath(p1, PsHandle)
            drawPath(p2, PsHandle)
        }
    }
}


// ───────────────────────── Margin presets (Word: Page Layout -> Margins)

/** A Word margin preset; all values in inches. For Mirrored, [l] = Inside and [r] = Outside. */
private class MarPreset(val name: String, val t: Float, val b: Float, val l: Float, val r: Float, val mirrored: Boolean = false)

private val MarPresets = listOf(
    MarPreset("Normal", 1f, 1f, 1f, 1f),
    MarPreset("Narrow", 0.5f, 0.5f, 0.5f, 0.5f),
    MarPreset("Moderate", 1f, 1f, 0.75f, 0.75f),
    MarPreset("Wide", 1f, 1f, 2f, 2f),
    MarPreset("Mirrored", 1f, 1f, 1.25f, 1f, true),
    MarPreset("Office 2003 Default", 1f, 1f, 1.25f, 1.25f)
)

/** The preset that matches the current margins (within half a point), or null = custom margins. */
private fun presetOf(m: Mar): MarPreset? = MarPresets.firstOrNull {
    abs(m.l - it.l * 72f) < 0.6f && abs(m.r - it.r * 72f) < 0.6f && abs(m.t - it.t * 72f) < 0.6f && abs(m.b - it.b * 72f) < 0.6f
}

/** Small page picture: white paper with the text area (inside the margins) in blue. */
@Composable
private fun MarIcon(p: MarPreset, modifier: Modifier) {
    Canvas(modifier) {
        drawRect(Color.White)
        drawRect(
            Color(0xFF9DB9E8),
            topLeft = Offset(size.width * p.l / 8.5f, size.height * p.t / 11f),
            size = androidx.compose.ui.geometry.Size(
                size.width * (1f - (p.l + p.r) / 8.5f).coerceAtLeast(0.05f),
                size.height * (1f - (p.t + p.b) / 11f).coerceAtLeast(0.05f)
            )
        )
    }
}

/** The "Margins" list like Word: Normal, Narrow, Moderate, Wide, Mirrored, Office 2003 Default and Custom Margins. */
@Composable
private fun MarginPresetsDialog(cur: Mar, unit: Int, onPick: (MarPreset) -> Unit, onClose: () -> Unit) {
    val k = if (unit == 1) 1f else 2.54f
    val un = if (unit == 1) "\"" else " cm"
    fun f(v: Float): String = String.format(Locale.US, "%.2f", v * k).trimEnd('0').trimEnd('.') + un
    val sel = presetOf(cur)
    MaterialTheme(colorScheme = PsScheme) {
        Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(
                color = Color(0xFF212121), shape = RoundedCornerShape(2.dp),
                modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth()
            ) {
                Column(Modifier.padding(top = 18.dp, bottom = 8.dp)) {
                    Text("Margins  /  حاشیہ", color = Color.White, fontSize = 21.sp, modifier = Modifier.padding(horizontal = 20.dp))
                    Spacer(Modifier.height(8.dp))
                    Column(Modifier.heightIn(max = 440.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                        for (p in MarPresets) {
                            Row(
                                Modifier.fillMaxWidth()
                                    .background(if (sel === p) Color(0xFF2E3B55) else Color.Transparent)
                                    .clickable { onPick(p) }
                                    .padding(horizontal = 20.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                MarIcon(p, Modifier.size(width = 34.dp, height = 44.dp))
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Row(Modifier.fillMaxWidth()) {
                                        Text("Top: " + f(p.t), color = Color(0xFFD0D0D0), fontSize = 14.sp, modifier = Modifier.weight(1f))
                                        Text("Bottom: " + f(p.b), color = Color(0xFFD0D0D0), fontSize = 14.sp, modifier = Modifier.weight(1f))
                                    }
                                    Row(Modifier.fillMaxWidth()) {
                                        Text((if (p.mirrored) "Inside: " else "Left: ") + f(p.l), color = Color(0xFFD0D0D0), fontSize = 14.sp, modifier = Modifier.weight(1f))
                                        Text((if (p.mirrored) "Outside: " else "Right: ") + f(p.r), color = Color(0xFFD0D0D0), fontSize = 14.sp, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                        // Custom Margins: the current margins are not one of the presets; use the blue arrows on the page sketch
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (sel == null) Color(0xFF2E3B55) else Color.Transparent)
                                .clickable { onClose() }
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(width = 34.dp, height = 44.dp).background(Color.White), contentAlignment = Alignment.Center) {
                                Text("★", color = Color(0xFFE57373), fontSize = 16.sp)
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Custom Margins…", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text("Use the blue arrows on the page below", color = Color(0xFFB0B0B0), fontSize = 13.sp)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.weight(1f))
                        Text("Cancel", color = Color.White, fontSize = 20.sp, modifier = Modifier.clickable { onClose() }.padding(vertical = 12.dp))
                    }
                }
            }
        }
    }
}

// ───────────────────────── Header dialog (text, size, colour, alignment, line, distance from the top)

private val HeaderColors = listOf(0xFF666666.toInt(), 0xFF000000.toInt(), 0xFF8E1B4A.toInt(), 0xFF1F4E9E.toInt(), 0xFF1B6E3A.toInt(), 0xFFC62828.toInt())

@Composable
fun HeaderDialog(onPageNumber: () -> Unit, onDone: () -> Unit, onCancel: () -> Unit) {
    var text by remember { mutableStateOf(Doc.headerText) }
    var size by remember { mutableIntStateOf(Doc.headerSize.toInt().coerceIn(8, 24)) }
    var color by remember { mutableIntStateOf(Doc.headerColor) }
    var align by remember { mutableIntStateOf(Doc.headerAlign + 1) }
    var line by remember { mutableIntStateOf(if (Doc.headerLine) 0 else 1) }
    var dist by remember { mutableStateOf(Doc.headerDist) }
    var font by remember { mutableStateOf(Doc.headerFont) }
    val fonts = remember { Fonts.all() }
    val alignNames = listOf("Auto", "Left", "Center", "Right")
    val lineNames = listOf("Show line", "No line")

    MaterialTheme(colorScheme = PsScheme) {
        Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(
                color = Color(0xFF212121), shape = RoundedCornerShape(2.dp),
                modifier = Modifier.padding(horizontal = 24.dp).fillMaxWidth()
            ) {
                Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(start = 21.dp, end = 21.dp, top = 20.dp, bottom = 8.dp)) {
                    Text("Header  /  ہیڈر", color = Color.White, fontSize = 21.sp)
                    Spacer(Modifier.height(10.dp))
                    Column(Modifier.fillMaxWidth()) {
                        BasicTextField(
                            value = text,
                            onValueChange = { text = it.replace("\n", " ").take(200) },
                            singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 19.sp),
                            cursorBrush = SolidColor(Color.White),
                            modifier = Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, bottom = 8.dp),
                            decorationBox = { inner ->
                                if (text.isEmpty()) Text("Header text  /  ہیڈر کا متن", color = PsGrey, fontSize = 17.sp)
                                inner()
                            }
                        )
                        Box(Modifier.fillMaxWidth().height(2.dp).background(PsAccent))
                    }
                    Spacer(Modifier.height(6.dp))
                    PsFormRow("Size:") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("$size pt", color = Color.White, fontSize = 18.sp, modifier = Modifier.width(70.dp))
                            Spacer(Modifier.weight(1f))
                            PsStepper(plus = false) { size = (size - 1).coerceAtLeast(8) }
                            PsStepper(plus = true) { size = (size + 1).coerceAtMost(24) }
                        }
                    }
                    PsFormRow("Font:") {
                        PsDropdown(
                            fonts.firstOrNull { it.second == font }?.first ?: (font ?: "Default"),
                            fonts.map { it.first }, false
                        ) { i -> font = if (i == 0) null else fonts[i].second }
                    }
                    PsFormRow("Colour:") {
                        Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                            for (c in HeaderColors) {
                                Box(
                                    Modifier.size(32.dp).background(Color(c), RoundedCornerShape(16.dp))
                                        .border(if (c == color) 3.dp else 1.dp, if (c == color) Color.White else Color(0xFF555555), RoundedCornerShape(16.dp))
                                        .clickable { color = c }
                                )
                            }
                        }
                    }
                    PsFormRow("Align:") { PsDropdown(alignNames[align.coerceIn(0, 3)], alignNames, false) { align = it } }
                    PsFormRow("Line:") { PsDropdown(lineNames[line], lineNames, false) { line = it } }
                    PsFormRow("From\ntop:") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmtOne(dist / 28.346f) + " cm", color = Color.White, fontSize = 18.sp, modifier = Modifier.width(90.dp))
                            Spacer(Modifier.weight(1f))
                            PsStepper(plus = false) { dist = (dist - 2.8346f).coerceAtLeast(0f) }
                            PsStepper(plus = true) { dist = (dist + 2.8346f).coerceAtMost(150f) }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Page number…  /  صفحہ نمبر", color = PsHandle, fontSize = 16.sp,
                            modifier = Modifier.clickable {
                                saveHeader(text, size, color, align - 1, line == 0, dist, font)
                                onPageNumber()
                            }.padding(vertical = 10.dp)
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            "Remove  /  ہٹائیں", color = Color(0xFFEF9A9A), fontSize = 16.sp,
                            modifier = Modifier.clickable { text = "" }.padding(vertical = 10.dp)
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Cancel", color = Color.White, fontSize = 20.sp,
                            modifier = Modifier.clickable { onCancel() }.padding(end = 18.dp, top = 10.dp, bottom = 10.dp)
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            "OK", color = Color.White, fontSize = 20.sp,
                            modifier = Modifier.clickable {
                                saveHeader(text, size, color, align - 1, line == 0, dist, font)
                                onDone()
                            }.padding(start = 18.dp, end = 4.dp, top = 10.dp, bottom = 10.dp)
                        )
                    }
                }
            }
        }
    }
}

/** Writes the header settings into the open document (used by the editor, PDF and Word export). */
private fun saveHeader(text: String, size: Int, color: Int, align: Int, line: Boolean, dist: Float, font: String?) {
    Doc.headerText = text.trim()
    Doc.headerSize = size.toFloat()
    Doc.headerColor = color
    Doc.headerAlign = align.coerceIn(-1, 2)
    Doc.headerLine = line
    Doc.headerDist = dist
    Doc.headerFont = font
    Doc.dirty = true
}
