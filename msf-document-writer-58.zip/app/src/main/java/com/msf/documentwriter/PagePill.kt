package com.msf.documentwriter

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Page counter pill ("9 / 233") shown at the bottom of the page view, like WPS Office. */
object PagePill {
    var cur by mutableIntStateOf(1)
    var total by mutableIntStateOf(1)
    fun set(c: Int, t: Int) { if (c != cur) cur = c; if (t != total) total = t }
}

@Composable
fun PagePillView(modifier: Modifier) {
    if (PagePill.total < 2) return
    Box(
        modifier.padding(bottom = 18.dp)
            .background(Color(0xCC3A3A3A), RoundedCornerShape(8.dp))
            .padding(horizontal = 14.dp, vertical = 5.dp)
    ) { Text("${PagePill.cur} / ${PagePill.total}", color = Color.White, fontSize = 15.sp) }
}
