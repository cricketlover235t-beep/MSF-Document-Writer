package com.msf.documentwriter

import android.content.Context
import android.net.Uri
import android.print.PrintAttributes
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("msf", Context.MODE_PRIVATE)
    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun name(c: Context) = str(c, "name", "Muhammad Sohaib")
    fun email(c: Context) = str(c, "email", "sohaib@email.com")
    fun theme(c: Context) = int(c, "theme", 0)
    fun urdu(c: Context) = bool(c, "urdu", true)
    fun fontLevel(c: Context) = int(c, "fl", 1)
    fun fontSize(c: Context): Int = intArrayOf(13, 16, 20, 24)[fontLevel(c).coerceIn(0, 3)]
    fun autoSave(c: Context) = bool(c, "autosave", true)
    fun showExt(c: Context) = bool(c, "showext", true)
    fun defFormat(c: Context) = int(c, "defformat", 0) // 0 docx 1 pdf 2 txt
    fun paper(c: Context) = int(c, "paper", 0)         // 0 A4 1 Letter 2 Legal
    fun landscape(c: Context) = bool(c, "landscape", false)
    fun quality(c: Context) = int(c, "quality", 1)     // 0 draft 1 normal 2 high
    fun appLock(c: Context) = bool(c, "applock", false)
    fun fingerprint(c: Context) = bool(c, "fingerprint", false)
    fun viewed(c: Context) = int(c, "viewed", 0)
    fun clearAll(c: Context) { sp(c).edit().clear().apply() }

    fun items(c: Context, k: String): Set<String> = sp(c).getStringSet(k, emptySet())?.toSet() ?: emptySet()
    fun add(c: Context, k: String, v: String) { sp(c).edit().putStringSet(k, items(c, k) + v).apply() }
    fun toggle(c: Context, k: String, v: String) {
        val s = items(c, k)
        sp(c).edit().putStringSet(k, if (v in s) s - v else s + v).apply()
    }

    fun printAttrs(c: Context): PrintAttributes {
        var size = Paper.media(paper(c))
        if (landscape(c)) size = size.asLandscape()
        val dpi = when (quality(c)) { 0 -> 150; 2 -> 600; else -> 300 }
        return PrintAttributes.Builder().setMediaSize(size)
            .setResolution(PrintAttributes.Resolution("msf", "MSF", dpi, dpi))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build()
    }
}

object Data {
    fun backup(c: Context, u: Uri): Int {
        var n = 0
        c.contentResolver.openOutputStream(u)?.use { os ->
            ZipOutputStream(os).use { z ->
                Store.list(c, true).forEach { f ->
                    z.putNextEntry(ZipEntry(f.name))
                    f.inputStream().use { it.copyTo(z) }
                    z.closeEntry(); n++
                }
            }
        }
        return n
    }

    fun restore(c: Context, u: Uri): Int {
        var n = 0
        c.contentResolver.openInputStream(u)?.use { ins ->
            ZipInputStream(ins).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val nm = e.name.substringAfterLast('/')
                    if (!e.isDirectory && kindOf(nm) != null) {
                        val out = Store.uniqueFile(c, nm.substringBeforeLast('.'), nm.substringAfterLast('.').lowercase())
                        FileOutputStream(out).use { z.copyTo(it) }
                        n++
                    }
                    e = z.nextEntry
                }
            }
        }
        return n
    }

    fun cacheSize(c: Context): Long = c.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    fun clearCache(c: Context) { c.cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
}
