package com.msf.documentwriter

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TabsBg = Color(0xFF16181B)
private val TabsRed = Color(0xFFF4511E)

@Composable
private fun TabItemRow(icon: ImageVector, tile: Color, label: String, current: Boolean, plain: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(84.dp).clickable { onClick() }, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(6.dp).height(40.dp).background(if (current) TabsRed else Color.Transparent))
        Spacer(Modifier.width(22.dp))
        if (plain) {
            Icon(icon, null, tint = TabsRed, modifier = Modifier.size(34.dp))
        } else {
            Box(Modifier.size(40.dp).background(tile, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp))
            }
        }
        Spacer(Modifier.width(36.dp))
        Text(label, color = Color.White, fontSize = 21.sp, maxLines = 1)
    }
}

/** "File Tabs" drop-down at the top of the editor: the open document, Home and Create new (like the mock-up). */
@Composable
fun FileTabsOverlay(docName: String, onDismiss: () -> Unit, onHome: () -> Unit, onNew: () -> Unit, onTools: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0x66000000)).clickable { onDismiss() }) {
        Column(Modifier.fillMaxWidth().background(TabsBg).clickable(enabled = false) { }) {
            Text("File Tabs", color = Color.White, fontSize = 28.sp, modifier = Modifier.padding(start = 28.dp, top = 34.dp, bottom = 22.dp))
            TabItemRow(Icons.Filled.Description, Color(0xFF3B7BF2), docName, true) { onDismiss() }
            TabItemRow(Icons.Filled.Home, Color(0xFFF4511E), "Home", false) { onDismiss(); onHome() }
            TabItemRow(Icons.Filled.Add, Color.Transparent, "Create new", false, true) { onDismiss(); onNew() }
            TabItemRow(Icons.Filled.Build, Color(0xFF5C6BC0), "Tools / ٹولز", false) { onDismiss(); onTools() }
            Spacer(Modifier.height(8.dp))
        }
    }
}
