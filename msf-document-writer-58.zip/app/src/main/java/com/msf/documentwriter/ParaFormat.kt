package com.msf.documentwriter

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.Layout
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.AbsoluteSizeSpan
import android.text.style.UnderlineSpan
import android.text.style.LeadingMarginSpan
import android.text.style.LineHeightSpan
import android.text.style.ParagraphStyle
import android.text.style.StyleSpan
import android.text.style.UpdateLayout
import android.view.inputmethod.BaseInputConnection
import android.widget.EditText
import kotlin.math.roundToInt

/** Pixels per document point: 1 in PDF / Word output, the page scale while the editor is on screen. */
object ParaScale {
    @Volatile var px = 1f
}

/** Left indent (in points) of a paragraph: [firstPt] for its first line, [restPt] for the other lines. */
class ParaIndentSpan(val firstPt: Float, val restPt: Float) : LeadingMarginSpan, UpdateLayout {
    override fun getLeadingMargin(first: Boolean): Int = ((if (first) firstPt else restPt) * ParaScale.px).roundToInt()
    override fun drawLeadingMargin(
        c: Canvas, p: Paint, x: Int, dir: Int, top: Int, baseline: Int, bottom: Int,
        text: CharSequence, start: Int, end: Int, first: Boolean, layout: Layout
    ) {
    }
}

/** Space (points) before and after a paragraph. */
class ParaSpaceSpan(val beforePt: Float, val afterPt: Float) : LineHeightSpan, UpdateLayout {
    override fun chooseHeight(text: CharSequence, start: Int, end: Int, spanstartv: Int, lineHeight: Int, fm: Paint.FontMetricsInt) {
        if (text !is Spanned) return
        // the layout multiplies the line height by 1.25 * line spacing afterwards, so ask for less here
        val k = ParaScale.px / (1.25f * Doc.lineSpacing)
        if (beforePt > 0f && text.getSpanStart(this) == start) {
            val e = (beforePt * k).roundToInt()
            fm.ascent -= e
            fm.top -= e
        }
        if (afterPt > 0f && end >= text.getSpanEnd(this)) {
            val e = (afterPt * k).roundToInt()
            fm.descent += e
            fm.bottom += e
        }
    }
}

/** Marks a numbered paragraph that starts a new list (restart = true) or continues the earlier one (restart = false). */
class ListMarkSpan(val restart: Boolean) : ParagraphStyle

/** Remembers which of the extra styles (Heading 4-9, Emphasis, Strong, ...) a paragraph got from the Style list. */
class StyleMarkSpan(val id: Int) : ParagraphStyle

/** What the Aa sheet shows for the paragraph under the cursor. */
class ParaState(
    val style: Int = 0,
    val listKind: Int = 0,
    val level: Int = 0,
    val left: Float = 0f,
    val firstRel: Float = 0f,
    val before: Float = 0f,
    val after: Float = 0f,
    val canDec: Boolean = false,
    val numbered: Boolean = false
)

data class TypoCfg(val quotes: Boolean = false, val dashes: Boolean = false, val ellipsis: Boolean = false, val urdu: Boolean = false) {
    fun any() = quotes || dashes || ellipsis || urdu
    fun save(c: Context) {
        Prefs.setBool(c, "ty_q", quotes); Prefs.setBool(c, "ty_d", dashes)
        Prefs.setBool(c, "ty_e", ellipsis); Prefs.setBool(c, "ty_u", urdu)
    }
    companion object {
        fun load(c: Context) = TypoCfg(Prefs.bool(c, "ty_q", false), Prefs.bool(c, "ty_d", false), Prefs.bool(c, "ty_e", false), Prefs.bool(c, "ty_u", false))
    }
}

object Para {
    const val LEVEL = 36f
    const val HANG = 18f

    fun endOf(t: CharSequence, pe: Int): Int = if (pe < t.length) pe + 1 else pe

    /** Start and end (without the newline) of the paragraph that holds [pos]. */
    fun bounds(t: CharSequence, pos: Int): Pair<Int, Int> {
        val p = pos.coerceIn(0, t.length)
        var s = p
        while (s > 0 && t[s - 1] != '\n') s--
        var e = p
        while (e < t.length && t[e] != '\n') e++
        return Pair(s, e)
    }

    /** All paragraphs touched by the range [a, b]. */
    fun paragraphs(t: CharSequence, a: Int, b: Int): List<Pair<Int, Int>> {
        val res = ArrayList<Pair<Int, Int>>()
        val lim = if (b > a) b - 1 else b
        var ps = bounds(t, a).first
        while (true) {
            var pe = ps
            while (pe < t.length && t[pe] != '\n') pe++
            res.add(Pair(ps, pe))
            if (pe >= t.length || pe >= lim) break
            ps = pe + 1
        }
        return res
    }

    fun inPara(e: Spanned, sp: Any, ps: Int): Boolean {
        val s = e.getSpanStart(sp)
        val en = e.getSpanEnd(sp)
        return s <= ps && (en > ps || (s == ps && en == ps))
    }

    fun <T : Any> find(e: Spanned, ps: Int, cls: Class<T>): T? = e.getSpans(ps, ps, cls).firstOrNull { inPara(e, it, ps) }

    private fun <T : Any> drop(e: Editable, ps: Int, cls: Class<T>) {
        for (sp in e.getSpans(ps, ps, cls)) if (inPara(e, sp, ps)) e.removeSpan(sp)
    }

    fun setIndent(e: Editable, ps: Int, pe: Int, first: Float, rest: Float) {
        drop(e, ps, ParaIndentSpan::class.java)
        if (first != 0f || rest != 0f) e.setSpan(ParaIndentSpan(first, rest), ps, endOf(e, pe), Spanned.SPAN_PARAGRAPH)
    }

    fun setSpace(e: Editable, ps: Int, pe: Int, before: Float, after: Float) {
        drop(e, ps, ParaSpaceSpan::class.java)
        if (before > 0f || after > 0f) e.setSpan(ParaSpaceSpan(before, after), ps, endOf(e, pe), Spanned.SPAN_PARAGRAPH)
    }

    fun levelOf(e: Spanned, ps: Int): Int {
        val i = find(e, ps, ParaIndentSpan::class.java) ?: return 0
        return (i.firstPt / LEVEL).roundToInt().coerceIn(0, 8)
    }

    /** Indent, spacing, list and style of the paragraph at [pos]. */
    fun stateAt(e: Editable, pos: Int, base: Int): ParaState {
        val (ps, pe) = bounds(e, pos)
        val ind = find(e, ps, ParaIndentSpan::class.java)
        val spc = find(e, ps, ParaSpaceSpan::class.java)
        val mk = ListFmt.parse(e.subSequence(ps, pe).toString())
        val kind = if (mk == null) 0 else if (mk.numbered) 200 + mk.cands[0] else 100 + mk.cands[0]
        val first = ind?.firstPt ?: 0f
        val rest = ind?.restPt ?: 0f
        return ParaState(
            style = StyleFmt.styleOf(e, ps, pe, base), listKind = kind, level = levelOf(e, ps),
            left = rest, firstRel = first - rest, before = spc?.beforePt ?: 0f, after = spc?.afterPt ?: 0f,
            canDec = first > 0f || rest > 0f, numbered = mk != null && mk.numbered
        )
    }
}

/** Heading styles: 0 Normal, 1-3 Heading 1-3, 4 Title, 5 Subtitle, 6 Quote. */
object StyleFmt {
    fun size(id: Int, base: Int): Int = when (id) {
        1 -> (base * 1.75f).roundToInt()
        2 -> (base * 1.375f).roundToInt()
        3 -> (base * 1.125f).roundToInt()
        4 -> (base * 2.1f).roundToInt()
        5 -> (base * 1.25f).roundToInt()
        else -> base
    }

    private fun spacing(id: Int): Pair<Float, Float> = when (id) {
        1 -> Pair(12f, 6f)
        2 -> Pair(10f, 4f)
        3 -> Pair(8f, 4f)
        4 -> Pair(0f, 12f)
        5 -> Pair(0f, 6f)
        else -> Pair(0f, 0f)
    }

    private fun spanAt(e: Editable, ps: Int, pe: Int): (Any) -> Boolean = { sp ->
        val s = e.getSpanStart(sp)
        val en = e.getSpanEnd(sp)
        if (pe > ps) s <= ps && en > ps else s == ps && en == ps
    }

    fun styleOf(e: Editable, ps: Int, pe: Int, base: Int): Int {
        Para.find(e, ps, StyleMarkSpan::class.java)?.let { return it.id }
        val at = spanAt(e, ps, pe)
        val to = if (pe > ps) ps + 1 else ps
        val sz = e.getSpans(ps, to, AbsoluteSizeSpan::class.java).filter(at).lastOrNull()?.size
        val bold = e.getSpans(ps, to, StyleSpan::class.java).filter(at).any { (it.style and Typeface.BOLD) != 0 }
        if (sz != null) {
            if (bold) {
                for (id in intArrayOf(4, 1, 2, 3)) if (sz == size(id, base)) return id
            } else if (sz == size(5, base)) return 5
        }
        val ind = Para.find(e, ps, ParaIndentSpan::class.java)
        if (ind != null && ind.firstPt == Para.LEVEL && ind.restPt == Para.LEVEL &&
            e.getSpans(ps, to, StyleSpan::class.java).filter(at).any { (it.style and Typeface.ITALIC) != 0 }
        ) return 6
        return 0
    }

    private fun stripSize(e: Editable, s: Int, en: Int) {
        for (sp in e.getSpans(s, en, AbsoluteSizeSpan::class.java)) {
            val fl = e.getSpanFlags(sp)
            if ((fl and Spanned.SPAN_COMPOSING) != 0) continue
            val ss = e.getSpanStart(sp)
            val se = e.getSpanEnd(sp)
            e.removeSpan(sp)
            if (ss < s) e.setSpan(AbsoluteSizeSpan(sp.size, sp.dip), ss, s, fl)
            if (se > en) e.setSpan(AbsoluteSizeSpan(sp.size, sp.dip), en, se, fl)
        }
    }

    private fun setStyleSpan(e: Editable, s: Int, en: Int, st: Int, on: Boolean) {
        for (sp in e.getSpans(s, en, StyleSpan::class.java)) {
            if (sp.style != st) continue
            val fl = e.getSpanFlags(sp)
            if ((fl and Spanned.SPAN_COMPOSING) != 0) continue
            val ss = e.getSpanStart(sp)
            val se = e.getSpanEnd(sp)
            e.removeSpan(sp)
            if (ss < s) e.setSpan(StyleSpan(st), ss, s, fl)
            if (se > en) e.setSpan(StyleSpan(st), en, se, fl)
        }
        if (on && en > s) e.setSpan(StyleSpan(st), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun pending(e: Editable, pos: Int, sz: Int, bold: Boolean) {
        for (sp in e.getSpans(0, e.length, AbsoluteSizeSpan::class.java)) if (e.getSpanStart(sp) == e.getSpanEnd(sp)) e.removeSpan(sp)
        e.setSpan(AbsoluteSizeSpan(sz, true), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
        for (sp in e.getSpans(pos, pos, StyleSpan::class.java)) {
            if (e.getSpanStart(sp) == pos && e.getSpanEnd(sp) == pos && sp.style == Typeface.BOLD) e.removeSpan(sp)
        }
        if (bold) e.setSpan(StyleSpan(Typeface.BOLD), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun apply(e: Editable, a: Int, b: Int, id: Int, base: Int) {
        val sz = size(id, base)
        val bold = id in 1..4
        val (before, after) = spacing(id)
        for ((s, en) in Para.paragraphs(e, a, b)) {
            val prev = styleOf(e, s, en, base)
            if (en > s) {
                stripSize(e, s, en)
                setStyleSpan(e, s, en, Typeface.BOLD, false)
                if (prev == 6 && id != 6) setStyleSpan(e, s, en, Typeface.ITALIC, false)
                if (id != 0) e.setSpan(AbsoluteSizeSpan(sz, true), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (bold) setStyleSpan(e, s, en, Typeface.BOLD, true)
                if (id == 6) setStyleSpan(e, s, en, Typeface.ITALIC, true)
            } else {
                pending(e, s, sz, bold)
            }
            if (id == 6) {
                Para.setIndent(e, s, en, Para.LEVEL, Para.LEVEL)
                Para.setSpace(e, s, en, 0f, 0f)
            } else {
                if (prev == 6) Para.setIndent(e, s, en, 0f, 0f)
                if (id != 0 || prev in 1..5) Para.setSpace(e, s, en, before, after)
            }
        }
    }

    // ---- extra styles of the Style list: ids 10-15 = Heading 4-9, 20 Emphasis, 21 Intense Emphasis, 22 Subtle Emphasis,
    //      23 Strong, 24 Intense Quote, 25 Subtle Reference, 26 Intense Reference, 27 Book Title, 28 List Paragraph ----
    private class Ext(
        val mul: Float, val bold: Boolean, val italic: Boolean, val color: Int?, val under: Boolean,
        val before: Float, val after: Float, val indent: Float
    )

    private fun ext(id: Int): Ext? = when (id) {
        10 -> Ext(1.05f, true, false, 0xFF2F5496.toInt(), false, 6f, 2f, 0f)
        11 -> Ext(1.0f, true, false, 0xFF2F5496.toInt(), false, 4f, 2f, 0f)
        12 -> Ext(1.0f, true, false, 0xFF1F3763.toInt(), false, 4f, 2f, 0f)
        13 -> Ext(1.0f, true, true, 0xFF1F3763.toInt(), false, 4f, 2f, 0f)
        14 -> Ext(0.95f, false, true, 0xFF272727.toInt(), false, 4f, 2f, 0f)
        15 -> Ext(0.95f, false, false, 0xFF272727.toInt(), false, 4f, 2f, 0f)
        20 -> Ext(1f, false, true, null, false, 0f, 0f, 0f)
        21 -> Ext(1f, true, true, 0xFF4472C4.toInt(), false, 0f, 0f, 0f)
        22 -> Ext(1f, false, true, 0xFF595959.toInt(), false, 0f, 0f, 0f)
        23 -> Ext(1f, true, false, null, false, 0f, 0f, 0f)
        24 -> Ext(1f, true, true, 0xFF4472C4.toInt(), false, 12f, 12f, Para.LEVEL)
        25 -> Ext(1f, false, false, 0xFF595959.toInt(), false, 0f, 0f, 0f)
        26 -> Ext(1f, true, false, 0xFF4472C4.toInt(), true, 0f, 0f, 0f)
        27 -> Ext(1f, true, true, null, false, 0f, 0f, 0f)
        28 -> Ext(1f, false, false, null, false, 0f, 0f, Para.LEVEL)
        else -> null
    }

    private fun stripUnder(e: Editable, s: Int, en: Int) {
        for (sp in e.getSpans(s, en, UnderlineSpan::class.java)) {
            val fl = e.getSpanFlags(sp)
            if ((fl and Spanned.SPAN_COMPOSING) != 0) continue
            val ss = e.getSpanStart(sp)
            val se = e.getSpanEnd(sp)
            e.removeSpan(sp)
            if (ss < s) e.setSpan(UnderlineSpan(), ss, s, fl)
            if (se > en) e.setSpan(UnderlineSpan(), en, se, fl)
        }
    }

    private fun stripColor(e: Editable, s: Int, en: Int) {
        for (sp in e.getSpans(s, en, android.text.style.ForegroundColorSpan::class.java)) {
            val fl = e.getSpanFlags(sp)
            if ((fl and Spanned.SPAN_COMPOSING) != 0) continue
            val ss = e.getSpanStart(sp)
            val se = e.getSpanEnd(sp)
            e.removeSpan(sp)
            if (ss < s) e.setSpan(android.text.style.ForegroundColorSpan(sp.foregroundColor), ss, s, fl)
            if (se > en) e.setSpan(android.text.style.ForegroundColorSpan(sp.foregroundColor), en, se, fl)
        }
    }

    /** Removes what an earlier extra style added to the paragraph, so styles replace each other like in Word. */
    private fun clearExt(e: Editable, s: Int, en: Int) {
        val mk = Para.find(e, s, StyleMarkSpan::class.java) ?: return
        val old = ext(mk.id)
        e.removeSpan(mk)
        if (old == null) return
        if (en > s) {
            if (old.color != null) stripColor(e, s, en)
            if (old.under) stripUnder(e, s, en)
            if (old.italic) setStyleSpan(e, s, en, Typeface.ITALIC, false)
        }
        if (old.indent > 0f) Para.setIndent(e, s, en, 0f, 0f)
    }

    /** Applies any style of the Style list (0-6 as before, 10 and up = the extra ones). */
    fun applyAny(e: Editable, a: Int, b: Int, id: Int, base: Int) {
        for ((s, en) in Para.paragraphs(e, a, b)) clearExt(e, s, en)
        val x = ext(id)
        if (x == null) { apply(e, a, b, id, base); return }
        apply(e, a, b, 0, base)
        for ((s, en) in Para.paragraphs(e, a, b)) {
            if (en > s) {
                if (x.mul != 1f) {
                    stripSize(e, s, en)
                    e.setSpan(AbsoluteSizeSpan((base * x.mul).roundToInt().coerceAtLeast(6), true), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                if (x.bold) setStyleSpan(e, s, en, Typeface.BOLD, true)
                if (x.italic) setStyleSpan(e, s, en, Typeface.ITALIC, true)
                if (x.color != null) e.setSpan(android.text.style.ForegroundColorSpan(x.color), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (x.under) e.setSpan(UnderlineSpan(), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else {
                if (x.mul != 1f) Rich.pendingSize(e, s, (base * x.mul).roundToInt().coerceAtLeast(6))
                if (x.bold) Rich.pendingStyle(e, s, Typeface.BOLD)
                if (x.italic) Rich.pendingStyle(e, s, Typeface.ITALIC)
                if (x.color != null) Rich.pendingColor(e, s, x.color)
                if (x.under) Rich.pendingUnderline(e, s)
            }
            if (x.indent > 0f) Para.setIndent(e, s, en, x.indent, x.indent)
            if (x.before > 0f || x.after > 0f) Para.setSpace(e, s, en, x.before, x.after)
            e.setSpan(StyleMarkSpan(id), s, Para.endOf(e, en), Spanned.SPAN_PARAGRAPH)
        }
    }
}

/** Bullets and numbering are written as text at the start of the paragraph ("• " or "1. "), so they survive in every file type. */
object ListFmt {
    val BULLETS = listOf("\u2022", "\u25E6", "\u25AA", "\u2013", "\u27A4", "\u2713", "\u2605")
    const val N_DEC = 0
    const val N_DECP = 1
    const val N_PAREN = 2
    const val N_ALPHA = 3
    const val N_ALPHA_U = 4
    const val N_ROMAN = 5
    const val N_ROMAN_U = 6
    const val N_URDU = 7
    const val N_MULTI = 8

    /** A recognised list marker at the start of a paragraph. [cands] = bullet index, or the possible numbering styles. */
    class Mk(val numbered: Boolean, val cands: List<Int>, val prefix: String) {
        val len: Int get() = prefix.length
    }

    private val rxMulti = Regex("^(\\d+(?:\\.\\d+)+)\\. ")
    private val rxDec = Regex("^(\\d+)([.)]) ")
    private val rxParen = Regex("^\\((\\d+)\\) ")
    private val rxUrdu = Regex("^([\u06F0-\u06F9]+)\u06D4 ")
    private val rxAlphaL = Regex("^([a-z])\\. ")
    private val rxAlphaU = Regex("^([A-Z])\\. ")
    private val rxRomanL = Regex("^([ivxlcdm]{2,4})\\. ")
    private val rxRomanU = Regex("^([IVXLCDM]{2,4})\\. ")

    private val ROMAN_VALS = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
    private val ROMAN_STR = arrayOf("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")

    fun roman(n: Int): String {
        var x = n
        val sb = StringBuilder()
        for (i in ROMAN_VALS.indices) {
            while (x >= ROMAN_VALS[i]) { sb.append(ROMAN_STR[i]); x -= ROMAN_VALS[i] }
        }
        return sb.toString()
    }

    private fun fromRoman(t: String): Int {
        var total = 0
        for (i in t.indices) {
            val v = when (t[i]) { 'I' -> 1; 'V' -> 5; 'X' -> 10; 'L' -> 50; 'C' -> 100; 'D' -> 500; else -> 1000 }
            val nx = if (i + 1 < t.length) when (t[i + 1]) { 'I' -> 1; 'V' -> 5; 'X' -> 10; 'L' -> 50; 'C' -> 100; 'D' -> 500; else -> 1000 } else 0
            total += if (v < nx) -v else v
        }
        return total
    }

    private fun validRoman(t: String): Boolean {
        val n = fromRoman(t.uppercase())
        return n in 1..50 && roman(n) == t.uppercase()
    }

    fun alpha(n: Int): String {
        var x = n
        val sb = StringBuilder()
        while (x > 0) {
            x--
            sb.insert(0, ('a' + x % 26))
            x /= 26
        }
        return sb.toString()
    }

    private fun urdu(n: Int): String = n.toString().map { '\u06F0' + (it - '0') }.joinToString("")

    fun label(style: Int, n: Int, path: List<Int> = emptyList()): String = when (style) {
        N_DEC -> "$n. "
        N_DECP -> "$n) "
        N_PAREN -> "($n) "
        N_ALPHA -> alpha(n) + ". "
        N_ALPHA_U -> alpha(n).uppercase() + ". "
        N_ROMAN -> roman(n).lowercase() + ". "
        N_ROMAN_U -> roman(n) + ". "
        N_URDU -> urdu(n) + "\u06D4 "
        else -> if (path.isEmpty()) "$n. " else path.joinToString(".") + ". "
    }

    fun parse(s: String): Mk? {
        if (s.length >= 2 && s[1] == ' ') {
            val i = BULLETS.indexOf(s[0].toString())
            if (i >= 0) return Mk(false, listOf(i), s.substring(0, 2))
        }
        rxMulti.find(s)?.let { return Mk(true, listOf(N_MULTI), it.value) }
        rxDec.find(s)?.let { return Mk(true, listOf(if (it.groupValues[2] == ".") N_DEC else N_DECP), it.value) }
        rxParen.find(s)?.let { return Mk(true, listOf(N_PAREN), it.value) }
        rxUrdu.find(s)?.let { return Mk(true, listOf(N_URDU), it.value) }
        rxAlphaL.find(s)?.let {
            val ch = it.groupValues[1]
            return Mk(true, if (validRoman(ch)) listOf(N_ALPHA, N_ROMAN) else listOf(N_ALPHA), it.value)
        }
        rxAlphaU.find(s)?.let {
            val ch = it.groupValues[1]
            return Mk(true, if (validRoman(ch)) listOf(N_ALPHA_U, N_ROMAN_U) else listOf(N_ALPHA_U), it.value)
        }
        rxRomanL.find(s)?.let { if (validRoman(it.groupValues[1])) return Mk(true, listOf(N_ROMAN), it.value) }
        rxRomanU.find(s)?.let { if (validRoman(it.groupValues[1])) return Mk(true, listOf(N_ROMAN_U), it.value) }
        return null
    }

    /** Replace the first [oldLen] characters of the paragraph at [ps] by [lab] without touching the paragraph start. */
    private fun swapPrefix(e: Editable, ps: Int, oldLen: Int, lab: String) {
        e.insert(ps + 1, lab)
        val after = ps + 1 + lab.length
        e.delete(after, after + oldLen - 1)
        e.delete(ps, ps + 1)
    }

    private fun text(e: Editable, s: Int, en: Int): String = e.subSequence(s, en).toString()

    private fun hang(e: Editable, ps: Int) {
        val (s, pe) = Para.bounds(e, ps)
        val lv = Para.levelOf(e, s)
        Para.setIndent(e, s, pe, lv * Para.LEVEL, lv * Para.LEVEL + Para.HANG)
    }

    private fun unhang(e: Editable, ps: Int) {
        val (s, pe) = Para.bounds(e, ps)
        val ind = Para.find(e, s, ParaIndentSpan::class.java) ?: return
        if (ind.restPt > ind.firstPt) Para.setIndent(e, s, pe, ind.firstPt, ind.firstPt)
    }

    fun setBullet(e: Editable, a: Int, b: Int, idx: Int) {
        val ps = Para.paragraphs(e, a, b)
        val all = ps.all { (s, en) -> val m = parse(text(e, s, en)); m != null && !m.numbered && m.cands[0] == idx }
        for ((s, en) in ps.reversed()) {
            val m = parse(text(e, s, en))
            if (all) {
                if (m != null) { e.delete(s, s + m.len); unhang(e, s) }
            } else {
                val lab = BULLETS[idx] + " "
                if (m == null) e.insert(s, lab)
                else if (m.numbered || m.cands[0] != idx) swapPrefix(e, s, m.len, lab)
                hang(e, s)
            }
        }
        renumber(e)
    }

    fun setNumbered(e: Editable, a: Int, b: Int, style: Int) {
        val ps = Para.paragraphs(e, a, b)
        val all = ps.all { (s, en) -> val m = parse(text(e, s, en)); m != null && m.numbered && style in m.cands }
        for ((s, en) in ps.reversed()) {
            val m = parse(text(e, s, en))
            if (all) {
                if (m != null) { e.delete(s, s + m.len); unhang(e, s) }
            } else {
                val lv = Para.levelOf(e, s)
                val lab = label(style, 1, if (style == N_MULTI && lv > 0) List(lv + 1) { 1 } else emptyList())
                if (m == null) e.insert(s, lab) else swapPrefix(e, s, m.len, lab)
                hang(e, s)
            }
        }
        renumber(e)
    }

    fun clearList(e: Editable, a: Int, b: Int) {
        for ((s, en) in Para.paragraphs(e, a, b).reversed()) {
            val m = parse(text(e, s, en)) ?: continue
            e.delete(s, s + m.len)
            unhang(e, s)
        }
        renumber(e)
    }

    /** Increase / decrease the list level of list paragraphs, or the indent of ordinary paragraphs. */
    fun changeLevel(e: Editable, a: Int, b: Int, delta: Int) {
        for ((s, en) in Para.paragraphs(e, a, b).reversed()) {
            val m = parse(text(e, s, en))
            val ind = Para.find(e, s, ParaIndentSpan::class.java)
            if (m != null) {
                val nl = (Para.levelOf(e, s) + delta).coerceIn(0, 8)
                Para.setIndent(e, s, en, nl * Para.LEVEL, nl * Para.LEVEL + Para.HANG)
                if (!m.numbered && m.cands[0] in 0..2) {
                    val sym = BULLETS[nl % 3] + " "
                    if (m.prefix != sym) swapPrefix(e, s, m.len, sym)
                }
            } else {
                val first = ((ind?.firstPt ?: 0f) + delta * Para.LEVEL).coerceAtLeast(0f)
                val rest = ((ind?.restPt ?: 0f) + delta * Para.LEVEL).coerceAtLeast(0f)
                Para.setIndent(e, s, en, first, rest)
            }
        }
        renumber(e)
    }

    /** Restart (true) or continue (false) the numbering at the numbered paragraphs in [a, b]. Returns false when none is numbered. */
    fun mark(e: Editable, a: Int, b: Int, restart: Boolean): Boolean {
        var done = false
        for ((s, en) in Para.paragraphs(e, a, b)) {
            val m = parse(text(e, s, en))
            if (m == null || !m.numbered) continue
            for (sp in e.getSpans(s, s, ListMarkSpan::class.java)) if (Para.inPara(e, sp, s)) e.removeSpan(sp)
            e.setSpan(ListMarkSpan(restart), s, Para.endOf(e, en), Spanned.SPAN_PARAGRAPH)
            done = true
        }
        if (done) renumber(e)
        return done
    }

    private fun pickStyle(m: Mk, n: Int, prev: Int): Int {
        if (m.cands.size == 1) return m.cands[0]
        for (c in m.cands) if (label(c, n) == m.prefix) return c
        return if (prev in m.cands) prev else m.cands[0]
    }

    /** Re-count all numbered paragraphs so that the numbers follow each other. */
    fun renumber(e: Editable) {
        val s = e.toString()
        val edits = ArrayList<Triple<Int, Int, String>>()
        val cnt = IntArray(10)
        val prevStyle = IntArray(10) { -1 }
        var saved: IntArray? = null
        var ps = 0
        while (true) {
            val nl = s.indexOf('\n', ps)
            val pe = if (nl < 0) s.length else nl
            val m = parse(s.substring(ps, pe))
            if (m == null) {
                if (cnt.any { it != 0 }) {
                    saved = cnt.copyOf()
                    cnt.fill(0)
                    prevStyle.fill(-1)
                }
            } else if (m.numbered) {
                val lv = Para.levelOf(e, ps)
                val mark = Para.find(e, ps, ListMarkSpan::class.java)
                if (mark != null && mark.restart) {
                    cnt[lv] = 0
                } else if (mark != null && cnt.all { it == 0 }) {
                    val sv = saved
                    if (sv != null) sv.copyInto(cnt)
                }
                cnt[lv] = cnt[lv] + 1
                for (k in lv + 1 until cnt.size) { cnt[k] = 0; prevStyle[k] = -1 }
                val n = cnt[lv]
                val st = pickStyle(m, n, prevStyle[lv])
                prevStyle[lv] = st
                val path = if (st == N_MULTI && lv > 0) (0..lv).map { maxOf(cnt[it], 1) } else emptyList()
                val lab = label(st, n, path)
                if (lab != m.prefix) edits.add(Triple(ps, m.len, lab))
            }
            if (nl < 0) break
            ps = nl + 1
        }
        for ((p, old, lab) in edits.reversed()) swapPrefix(e, p, old, lab)
    }
}

/** Smart quotes, dashes, ellipsis and Urdu punctuation. */
object Typo {
    fun isArabic(c: Char): Boolean =
        c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' || c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    private fun opens(prev: Char): Boolean = prev == '\n' || prev.isWhitespace() || "([{\u2013\u2014\u201C\u2018".indexOf(prev) >= 0

    private fun urduMark(c: Char): String? = when (c) { '?' -> "\u061F"; ',' -> "\u060C"; ';' -> "\u061B"; else -> null }

    private fun arabicBefore(s: CharSequence, p: Int, ps: Int): Boolean {
        var i = p - 1
        while (i >= ps && s[i] == ' ') i--
        return i >= ps && isArabic(s[i])
    }

    /** Fix the text in [a0, b0] (the whole text when nothing is selected). Returns the number of changes. */
    fun fix(e: Editable, a0: Int, b0: Int, cfg: TypoCfg): Int {
        val a = if (a0 == b0) 0 else a0
        val b = if (a0 == b0) e.length else b0
        val s = e.toString()
        val edits = ArrayList<Triple<Int, Int, String>>()
        for ((ps, pe) in Para.paragraphs(e, a, b)) {
            if (pe > ps && s[ps] == '|') continue
            var i = maxOf(ps, a)
            val end = minOf(pe, b)
            while (i < end) {
                val c = s[i]
                val prev = if (i > ps) s[i - 1] else '\n'
                if (cfg.dashes && s.startsWith("---", i)) { edits.add(Triple(i, i + 3, "\u2014")); i += 3; continue }
                if (cfg.dashes && s.startsWith("--", i)) { edits.add(Triple(i, i + 2, "\u2013")); i += 2; continue }
                if (cfg.ellipsis && s.startsWith("...", i)) { edits.add(Triple(i, i + 3, "\u2026")); i += 3; continue }
                if (cfg.quotes && c == '"') edits.add(Triple(i, i + 1, if (opens(prev)) "\u201C" else "\u201D"))
                else if (cfg.quotes && c == '\'') edits.add(Triple(i, i + 1, if (opens(prev)) "\u2018" else "\u2019"))
                else if (cfg.urdu) {
                    val m = urduMark(c)
                    if (m != null && arabicBefore(s, i, ps)) edits.add(Triple(i, i + 1, m))
                }
                i++
            }
        }
        for ((f, t, str) in edits.reversed()) e.replace(f, t, str)
        return edits.size
    }
}

/** Live helpers while typing: continue / end lists on Enter (Auto Numbering) and smart typography. */
class EditHelper(private val et: EditText, private val autoNum: () -> Boolean, private val typo: () -> TypoCfg) : TextWatcher {
    private var busy = false
    private var cStart = 0
    private var cCount = 0
    private var cBefore = 0
    private var nlAt = -1

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        if (busy) return
        cStart = start; cCount = count; cBefore = before
        nlAt = if (before == 0 && count == 1 && s != null && start < s.length && s[start] == '\n') start else -1
    }

    override fun afterTextChanged(e: Editable?) {
        if (busy || e == null) return
        busy = true
        try {
            if (nlAt >= 0) {
                if (autoNum()) onEnter(e, nlAt)
            } else if (cCount == 1 && cBefore == 0) {
                smart(e, cStart)
            } else if (cBefore > 0 && cCount == 0 && autoNum()) {
                ListFmt.renumber(e)
            }
        } catch (_: Throwable) {
        } finally {
            busy = false
            nlAt = -1
            cCount = 0
            cBefore = 0
        }
    }

    private fun onEnter(e: Editable, nl: Int) {
        var ps = nl
        while (ps > 0 && e[ps - 1] != '\n') ps--
        val line = e.subSequence(ps, nl).toString()
        val mk = ListFmt.parse(line) ?: return
        if (line.length <= mk.len) {
            // Enter on an empty list item ends the list
            e.delete(ps, nl + 1)
            val (s2, pe2) = Para.bounds(e, ps)
            Para.setIndent(e, s2, pe2, 0f, 0f)
            ListFmt.renumber(e)
            et.setSelection(s2.coerceIn(0, e.length))
        } else {
            val nps = nl + 1
            val ind = Para.find(e, ps, ParaIndentSpan::class.java)
            e.insert(nps, mk.prefix)
            if (ind != null) {
                val (s2, pe2) = Para.bounds(e, nps)
                Para.setIndent(e, s2, pe2, ind.firstPt, ind.restPt)
            }
            ListFmt.renumber(e)
            val (s3, pe3) = Para.bounds(e, nps)
            val m3 = ListFmt.parse(e.subSequence(s3, pe3).toString())
            et.setSelection((s3 + (m3?.len ?: mk.len)).coerceIn(0, e.length))
        }
    }

    private fun smart(e: Editable, p: Int) {
        val cfg = typo()
        if (!cfg.any() || p < 0 || p >= e.length) return
        val cs = BaseInputConnection.getComposingSpanStart(e)
        val ce = BaseInputConnection.getComposingSpanEnd(e)
        if (cs >= 0 && p >= cs && p < ce) return
        val (ps, _) = Para.bounds(e, p)
        if (e[ps] == '|') return
        val c = e[p]
        val prev = if (p > ps) e[p - 1] else '\n'
        fun rep(from: Int, to: Int, str: String) {
            e.replace(from, to, str)
            et.setSelection((from + str.length).coerceIn(0, e.length))
        }
        val open = prev == '\n' || prev.isWhitespace() || "([{\u2013\u2014\u201C\u2018".indexOf(prev) >= 0
        when {
            cfg.quotes && c == '"' -> rep(p, p + 1, if (open) "\u201C" else "\u201D")
            cfg.quotes && c == '\'' -> rep(p, p + 1, if (open) "\u2018" else "\u2019")
            cfg.dashes && c == '-' && p > ps && prev == '-' -> rep(p - 1, p + 1, "\u2013")
            cfg.dashes && c == '-' && p > ps && prev == '\u2013' -> rep(p - 1, p + 1, "\u2014")
            cfg.ellipsis && c == '.' && p - 2 >= ps && e[p - 1] == '.' && e[p - 2] == '.' -> rep(p - 2, p + 1, "\u2026")
            cfg.urdu && (c == '?' || c == ',' || c == ';') -> {
                var i = p - 1
                while (i >= ps && e[i] == ' ') i--
                if (i >= ps && Typo.isArabic(e[i])) {
                    val m = when (c) { '?' -> "\u061F"; ',' -> "\u060C"; else -> "\u061B" }
                    rep(p, p + 1, m)
                }
            }
        }
    }
}
