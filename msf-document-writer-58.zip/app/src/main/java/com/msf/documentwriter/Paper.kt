package com.msf.documentwriter

import android.print.PrintAttributes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Page sizes. Index 0..2 are kept identical to the old A4 / Letter / Legal numbering. */
object Paper {
    class Size(val name: String, val mm: String, val wPt: Int, val hPt: Int, val wTw: Int, val hTw: Int)

    val all: List<Size> = listOf(
        Size("A4", "210 × 297 mm", 595, 842, 11906, 16838),
        Size("Letter", "8.5 × 11 in", 612, 792, 12240, 15840),
        Size("Legal", "8.5 × 14 in", 612, 1008, 12240, 20160),
        Size("A3", "297 × 420 mm", 842, 1191, 16838, 23811),
        Size("A5", "148 × 210 mm", 420, 595, 8391, 11906),
        Size("A6", "105 × 148 mm", 298, 420, 5953, 8391),
        Size("B5", "176 × 250 mm", 499, 709, 9978, 14173),
        Size("Tabloid", "11 × 17 in", 792, 1224, 15840, 24480),
        Size("B4", "250 × 353 mm", 709, 1001, 14173, 20012),
        Size("Ledger", "17 × 11 in", 1224, 792, 24480, 15840),
        Size("Statement", "5.5 × 8.5 in", 396, 612, 7920, 12240),
        Size("Executive", "7.25 × 10.5 in", 522, 756, 10440, 15120),
        Size("Folio", "8.5 × 13 in", 612, 936, 12240, 18720),
        Size("Quarto", "215 × 275 mm", 609, 780, 12189, 15591)
    )

    /** Order of the Page Size list in Page Setup (indexes into [all]). */
    val setupOrder: List<Int> = listOf(3, 0, 4, 8, 6, 1, 7, 9, 2, 10, 11, 12, 13)

    /** Names for dropdown lists, e.g. "A4 (210 × 297 mm)". */
    val names: List<String> = all.map { it.name + " (" + it.mm + ")" }

    fun get(i: Int): Size = all[i.coerceIn(0, all.size - 1)]

    /** Page width / height in points for the PDF canvas. */
    fun pt(i: Int, land: Boolean): Pair<Int, Int> {
        val s = get(i)
        return if (land) Pair(s.hPt, s.wPt) else Pair(s.wPt, s.hPt)
    }

    /** Page width / height in twips for Word files. */
    fun twips(i: Int, land: Boolean): Pair<Int, Int> {
        val s = get(i)
        return if (land) Pair(s.hTw, s.wTw) else Pair(s.wTw, s.hTw)
    }

    fun media(i: Int): PrintAttributes.MediaSize = when (i) {
        1 -> PrintAttributes.MediaSize.NA_LETTER
        2 -> PrintAttributes.MediaSize.NA_LEGAL
        3 -> PrintAttributes.MediaSize.ISO_A3
        4 -> PrintAttributes.MediaSize.ISO_A5
        5 -> PrintAttributes.MediaSize.ISO_A6
        6 -> PrintAttributes.MediaSize.ISO_B5
        7 -> PrintAttributes.MediaSize.NA_TABLOID
        8 -> PrintAttributes.MediaSize("msf_b4", "B4", 9843, 13898)
        9 -> PrintAttributes.MediaSize("msf_ledger", "Ledger", 17000, 11000)
        10 -> PrintAttributes.MediaSize("msf_statement", "Statement", 5500, 8500)
        11 -> PrintAttributes.MediaSize("msf_executive", "Executive", 7250, 10500)
        12 -> PrintAttributes.MediaSize("msf_folio", "Folio", 8500, 13000)
        13 -> PrintAttributes.MediaSize("msf_quarto", "Quarto", 8465, 10827)
        else -> PrintAttributes.MediaSize.ISO_A4
    }

    /** Finds the paper index (and orientation) of a Word page size given in twips, or null when it is not one of ours. */
    fun fromTwips(w: Int, h: Int): Pair<Int, Boolean>? {
        val land = w > h
        val pw = if (land) h else w
        val ph = if (land) w else h
        for ((i, s) in all.withIndex()) {
            if (kotlin.math.abs(s.wTw - pw) <= 60 && kotlin.math.abs(s.hTw - ph) <= 60) return Pair(i, land)
        }
        return null
    }
}

/** Page size + orientation picker, shared by the editors. */
@Composable
fun PageSizeDialog(paper: Int, land: Boolean, onApply: (Int, Boolean) -> Unit, onDismiss: () -> Unit) {
    var p by remember { mutableIntStateOf(paper) }
    var l by remember { mutableStateOf(land) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Page Size / پیج سائز") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Paper.all.forEachIndexed { i, s ->
                    Row(
                        Modifier.fillMaxWidth().clickable { p = i }.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = p == i, onClick = { p = i })
                        Text(s.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.padding(horizontal = 6.dp))
                        Text(s.mm, fontSize = 12.sp, color = Color.Gray)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Orientation / رخ", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!l) Button(onClick = { l = false }, shape = RoundedCornerShape(10.dp)) { Text("Portrait / عمودی") }
                    else OutlinedButton(onClick = { l = false }, shape = RoundedCornerShape(10.dp)) { Text("Portrait / عمودی") }
                    if (l) Button(onClick = { l = true }, shape = RoundedCornerShape(10.dp)) { Text("Landscape / افقی") }
                    else OutlinedButton(onClick = { l = true }, shape = RoundedCornerShape(10.dp)) { Text("Landscape / افقی") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onApply(p, l) }) { Text("Apply / لاگو کریں") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
