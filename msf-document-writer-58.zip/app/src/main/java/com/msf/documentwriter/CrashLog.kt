package com.msf.documentwriter

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import java.io.File

/** Saves the text of a crash, so the next start of the app can show it (to be copied and sent to the developer). */
object CrashLog {
    private fun file(c: Context) = File(c.applicationContext.filesDir, "last_crash.txt")

    fun install(c: Context) {
        val app = c.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = java.io.StringWriter()
                e.printStackTrace(java.io.PrintWriter(sw))
                file(app).writeText("v1.0.44  " + java.util.Date() + "\nthread: " + t.name + "\n\n" + sw.toString().take(6000))
            } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    fun read(c: Context): String? = try { file(c).takeIf { it.exists() }?.readText() } catch (_: Throwable) { null }
    fun clear(c: Context) { try { file(c).delete() } catch (_: Throwable) {} }
}

@Composable
fun CrashDialog() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(CrashLog.read(ctx)) }
    val t = text ?: return
    AlertDialog(
        onDismissRequest = { CrashLog.clear(ctx); text = null },
        title = { Text("App closed last time / ایپ پچھلی بار بند ہوئی") },
        text = {
            Text(
                "براہ کرم Copy دبا کر یہ متن ڈویلپر کو بھیج دیں تاکہ مسئلہ ٹھیک ہو سکے۔\nPlease press Copy and send this text.\n\n" + t.take(1800),
                fontSize = 11.sp, modifier = androidx.compose.ui.Modifier.verticalScroll(rememberScrollState())
            )
        },
        confirmButton = {
            TextButton(onClick = {
                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("crash", t))
                toast(ctx, "کاپی ہو گیا / Copied")
            }) { Text("Copy / کاپی") }
        },
        dismissButton = {
            Row2(
                { try { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Share")) } catch (_: Throwable) {} },
                { CrashLog.clear(ctx); text = null }
            )
        }
    )
}

@Composable
private fun Row2(share: () -> Unit, close: () -> Unit) {
    androidx.compose.foundation.layout.Row {
        TextButton(onClick = share) { Text("Share") }
        TextButton(onClick = close) { Text("Close") }
    }
}
