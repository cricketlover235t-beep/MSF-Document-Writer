package com.msf.documentwriter

import android.text.Editable
import android.text.Spanned
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.CharacterStyle
import android.text.style.ParagraphStyle

/**
 * Marks text that was turned into capitals. [orig] is the text as it was before (so the change can be undone),
 * [sizes] (small caps only) the font size of every character before the change.
 */
class CapsMark(val kind: Int, val orig: String, val sizes: IntArray? = null) : CharacterStyle() {
    override fun updateDrawState(tp: TextPaint) {}
}

/** "All Caps" and "Small Caps" of the Aa sheet. Both are real toggles on the selected text. */
object Caps {
    const val ALL = 1
    const val SMALL = 2
    private const val X = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE

    /** 0 = none, 1 = All Caps, 2 = Small Caps around [from, to). */
    fun kindAt(e: Spanned, from: Int, to: Int): Int {
        val m = e.getSpans(from, to, CapsMark::class.java).lastOrNull() ?: return 0
        return m.kind
    }

    private fun upper(s: String): String = String(CharArray(s.length) { Character.toUpperCase(s[it]) })
    private fun lower(s: String): String = String(CharArray(s.length) { Character.toLowerCase(s[it]) })

    private class Sp(val o: Any, val a: Int, val b: Int, val f: Int)

    /** Replaces [s, en) by a text of the same length and keeps every span exactly as it was. */
    private fun replaceSame(e: Editable, s: Int, en: Int, repl: String) {
        if (repl.length != en - s) return
        if (e.subSequence(s, en).toString() == repl) return
        val saved = ArrayList<Sp>()
        for (o in e.getSpans(s, en, Any::class.java)) {
            if (o !is CharacterStyle && o !is ParagraphStyle) continue
            val f = e.getSpanFlags(o)
            if ((f and Spanned.SPAN_COMPOSING) != 0) continue
            saved.add(Sp(o, e.getSpanStart(o), e.getSpanEnd(o), f))
        }
        e.replace(s, en, repl)
        for (x in saved) e.setSpan(x.o, x.a, x.b, x.f)
    }

    private fun sizeAt(e: Editable, pos: Int): Int {
        val sp = e.getSpans(pos, pos + 1, AbsoluteSizeSpan::class.java)
            .lastOrNull { e.getSpanStart(it) <= pos && e.getSpanEnd(it) > pos }
        return sp?.size ?: Doc.baseSize
    }

    private fun covered(e: Editable, s: Int, en: Int, marks: List<CapsMark>): Boolean {
        if (en <= s) return false
        val seen = BooleanArray(en - s)
        for (m in marks) {
            val a = maxOf(e.getSpanStart(m), s)
            val b = minOf(e.getSpanEnd(m), en)
            for (i in a until b) seen[i - s] = true
        }
        return seen.all { it }
    }

    fun toggleAll(e: Editable, s: Int, en: Int) {
        if (en <= s) return
        val marks = e.getSpans(s, en, CapsMark::class.java).filter { it.kind == ALL }
        if (covered(e, s, en, marks)) { undo(e, s, en, ALL); return }
        undo(e, s, en, SMALL)
        val src = e.subSequence(s, en).toString()
        replaceSame(e, s, en, upper(src))
        e.setSpan(CapsMark(ALL, src), s, en, X)
    }

    fun toggleSmall(e: Editable, s: Int, en: Int) {
        if (en <= s) return
        val marks = e.getSpans(s, en, CapsMark::class.java).filter { it.kind == SMALL }
        if (covered(e, s, en, marks)) { undo(e, s, en, SMALL); return }
        undo(e, s, en, ALL)
        val src = e.subSequence(s, en).toString()
        val sizes = IntArray(src.length) { sizeAt(e, s + it) }
        replaceSame(e, s, en, upper(src))
        var i = 0
        while (i < src.length) {
            if (Character.isLowerCase(src[i])) {
                var j = i
                while (j < src.length && Character.isLowerCase(src[j]) && sizes[j] == sizes[i]) j++
                Rich.size(e, s + i, s + j, maxOf(6, Math.round(sizes[i] * 0.8f)))
                i = j
            } else i++
        }
        e.setSpan(CapsMark(SMALL, src, sizes), s, en, X)
    }

    private fun restoreSmall(e: Editable, a: Int, b: Int, part: String, sizes: IntArray?) {
        replaceSame(e, a, b, part)
        var i = 0
        while (i < part.length) {
            if (Character.isLowerCase(part[i])) {
                var j = i
                val sz = sizes?.getOrNull(i)
                while (j < part.length && Character.isLowerCase(part[j]) && sizes?.getOrNull(j) == sz) j++
                val size = sz ?: Math.round(sizeAt(e, a + i) / 0.8f)
                Rich.size(e, a + i, a + j, size)
                i = j
            } else i++
        }
    }

    private fun undo(e: Editable, s: Int, en: Int, kind: Int) {
        for (m in e.getSpans(s, en, CapsMark::class.java).filter { it.kind == kind }) {
            val ms = e.getSpanStart(m)
            val me = e.getSpanEnd(m)
            val a = maxOf(ms, s)
            val b = minOf(me, en)
            if (b <= a) continue
            val intact = m.orig.length == me - ms
            e.removeSpan(m)
            if (intact) {
                val part = m.orig.substring(a - ms, b - ms)
                if (kind == SMALL) restoreSmall(e, a, b, part, m.sizes?.copyOfRange(a - ms, b - ms))
                else replaceSame(e, a, b, part)
                if (ms < a) e.setSpan(CapsMark(kind, m.orig.substring(0, a - ms), m.sizes?.copyOfRange(0, a - ms)), ms, a, X)
                if (b < me) e.setSpan(CapsMark(kind, m.orig.substring(b - ms), m.sizes?.copyOfRange(b - ms, me - ms)), b, me, X)
            } else {
                val low = lower(e.subSequence(a, b).toString())
                if (kind == SMALL) restoreSmall(e, a, b, low, null) else replaceSame(e, a, b, low)
            }
        }
    }
}
