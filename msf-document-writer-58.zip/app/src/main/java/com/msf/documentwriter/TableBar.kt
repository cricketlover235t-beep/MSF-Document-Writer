package com.msf.documentwriter

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private val TwBar = Color(0xFF1B1B1B)
private val TwAcc = Color(0xFF1E88E5)
private val TwGrey = Color(0xFF8A8A8A)
private val TwChip = Color(0xFF2A2A2A)

/** Column name like in a spreadsheet: A, B, C ... Z, AA, AB ... */
fun tableColName(i: Int): String {
    var n = i
    val sb = StringBuilder()
    do {
        sb.insert(0, ('A' + (n % 26)))
        n = n / 26 - 1
    } while (n >= 0)
    return sb.toString()
}

@Composable
private fun TwPlus(onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).border(1.5.dp, Color(0xFF9A9A9A), CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(16.dp)) {
            val w = 2.dp.toPx()
            drawLine(TwAcc, Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), w)
            drawLine(TwAcc, Offset(size.width / 2f, 0f), Offset(size.width / 2f, size.height), w)
        }
    }
}

@Composable
private fun TwMove(onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).border(1.5.dp, Color(0xFF9A9A9A), CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(20.dp)) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val r = size.width / 2f
            val t = 4.dp.toPx()
            fun arrow(dx: Float, dy: Float) {
                val p = Path()
                val tx = cx + dx * r
                val ty = cy + dy * r
                if (dx != 0f) {
                    p.moveTo(tx, ty); p.lineTo(tx - dx * t, ty - t); p.lineTo(tx - dx * t, ty + t)
                } else {
                    p.moveTo(tx, ty); p.lineTo(tx - t, ty - dy * t); p.lineTo(tx + t, ty - dy * t)
                }
                p.close()
                drawPath(p, TwAcc)
            }
            arrow(1f, 0f); arrow(-1f, 0f); arrow(0f, 1f); arrow(0f, -1f)
        }
    }
}

@Composable
private fun TwChipBox(label: String, on: Boolean, w: Int, onClick: () -> Unit) {
    Box(
        Modifier.width(w.dp).height(32.dp).background(TwChip, RoundedCornerShape(6.dp))
            .border(if (on) 2.dp else 1.dp, if (on) TwAcc else Color(0xFF666666), RoundedCornerShape(6.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (on) TwAcc else Color.White, fontSize = 16.sp) }
}

/**
 * Table handles shown while the cursor is inside a table: column letters (A B C …) and row numbers (1 2 3 …)
 * to jump to a cell, "+" to add a column / row, and the menu (Select, Select All, Table Properties …).
 */
@Composable
fun TableBar(
    info: TblInfo,
    onCol: (Int) -> Unit, onRow: (Int) -> Unit,
    onAddCol: () -> Unit, onAddRow: () -> Unit,
    onSelect: () -> Unit, onSelectAll: () -> Unit, onProps: () -> Unit,
    onRowAbove: () -> Unit, onColLeft: () -> Unit,
    onDelRow: () -> Unit, onDelCol: () -> Unit, onDelTable: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menu by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = PsScheme) {
        Column(modifier.fillMaxWidth().background(TwBar).padding(horizontal = 10.dp, vertical = 6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box {
                    TwMove { menu = true }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Select", color = Color(0xFFE0E0E0)) }, onClick = { menu = false; onSelect() })
                        DropdownMenuItem(text = { Text("Select All", color = Color(0xFFE0E0E0)) }, onClick = { menu = false; onSelectAll() })
                        DropdownMenuItem(text = { Text("Table Properties", color = Color(0xFFE0E0E0)) }, onClick = { menu = false; onProps() })
                        DropdownMenuItem(text = { Text("Row above / اوپر قطار", color = Color(0xFFE0E0E0)) }, onClick = { menu = false; onRowAbove() })
                        DropdownMenuItem(text = { Text("Column left / بائیں کالم", color = Color(0xFFE0E0E0)) }, onClick = { menu = false; onColLeft() })
                        DropdownMenuItem(text = { Text("Delete row / قطار مٹائیں", color = Color(0xFFE0E0E0)) }, onClick = { menu = false; onDelRow() })
                        DropdownMenuItem(text = { Text("Delete column / کالم مٹائیں", color = Color(0xFFE0E0E0)) }, onClick = { menu = false; onDelCol() })
                        DropdownMenuItem(text = { Text("Delete table / ٹیبل مٹائیں", color = Color(0xFFFF8A80)) }, onClick = { menu = false; onDelTable() })
                    }
                }
                Spacer(Modifier.width(8.dp))
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    for (c in 0 until info.cols) TwChipBox(tableColName(c), c == info.col, 52) { onCol(c) }
                }
                Spacer(Modifier.width(8.dp))
                TwPlus { onAddCol() }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(34.dp), contentAlignment = Alignment.Center) {
                    Text("↕", color = TwGrey, fontSize = 18.sp)
                }
                Spacer(Modifier.width(8.dp))
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    for (r in 0 until info.rows) TwChipBox("${r + 1}", r == info.row, 44) { onRow(r) }
                }
                Spacer(Modifier.width(8.dp))
                TwPlus { onAddRow() }
            }
        }
    }
}

/** "Table Properties": header row and colour style of the table under the cursor. */
@Composable
fun TablePropsDialog(
    info: TblInfo,
    onHeader: (Boolean) -> Unit, onStyle: (Int) -> Unit, onClose: () -> Unit
) {
    var header by remember { mutableStateOf(info.header) }
    var style by remember { mutableIntStateOf(info.style) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        MaterialTheme(colorScheme = PsScheme) {
            Column(Modifier.fillMaxSize().background(Color.Black)) {
                Row(Modifier.fillMaxWidth().height(56.dp).background(TwBar), verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.width(20.dp))
                    Text("Table Properties", color = Color.White, fontSize = 19.sp, modifier = Modifier.weight(1f))
                    Text("OK", color = Color(0xFFE6E6E6), fontSize = 18.sp, modifier = Modifier.clickable { onClose() }.padding(horizontal = 20.dp, vertical = 14.dp))
                }
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp)) {
                    Text("${info.rows} × ${info.cols}   (rows / columns)", color = TwGrey, fontSize = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF222222)))
                    Row(Modifier.fillMaxWidth().height(56.dp).clickable { header = !header; onHeader(header) }, verticalAlignment = Alignment.CenterVertically) {
                        Text("Header row  /  پہلی قطار عنوان", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        Switch(
                            checked = header, onCheckedChange = { header = it; onHeader(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White, checkedTrackColor = TwAcc,
                                uncheckedThumbColor = Color.White, uncheckedTrackColor = Color(0xFF555555), uncheckedBorderColor = Color(0xFF555555)
                            )
                        )
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF222222)))
                    Spacer(Modifier.height(12.dp))
                    Text("Table Style", color = TwGrey, fontSize = 16.sp)
                    Spacer(Modifier.height(12.dp))
                    (0 until 8).chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(36.dp)) {
                            pair.forEach { i ->
                                val on = style == i
                                Box(
                                    Modifier.weight(1f).aspectRatio(1.65f)
                                        .border(if (on) 3.dp else 1.dp, if (on) TwAcc else Color.Transparent, RoundedCornerShape(2.dp))
                                        .clickable { style = i; onStyle(i) }.padding(3.dp)
                                ) {
                                    TableDraw(4, 5, i, Modifier.fillMaxSize(), if (i == 0) Color(0xFF222222) else Color(0xFF444444))
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}
