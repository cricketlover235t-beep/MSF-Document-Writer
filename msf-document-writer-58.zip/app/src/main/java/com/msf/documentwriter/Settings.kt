@file:OptIn(ExperimentalMaterial3Api::class)

package com.msf.documentwriter

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import java.io.File
import java.io.FileOutputStream

fun loadAvatar(c: android.content.Context): ImageBitmap? {
    val f = File(c.filesDir, "avatar.jpg")
    return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() else null
}

@Composable
private fun Section(title: String, icon: ImageVector, tint: Color, bg: Color, content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFD5E0F2))
    ) {
        Column {
            Row(Modifier.fillMaxWidth().background(bg).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = tint)
                Spacer(Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color(0xFF0A2A66))
            }
            content()
        }
    }
}

@Composable
private fun SRow(
    icon: ImageVector, color: Color, title: String, sub: String, value: String? = null,
    trailing: (@Composable () -> Unit)? = null, onClick: (() -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(36.dp).clip(CircleShape).background(color.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(sub, fontSize = 12.sp, color = Color.Gray)
        }
        if (value != null) { Text(value, fontSize = 13.sp, color = Color(0xFF334155)); Spacer(Modifier.width(4.dp)) }
        if (trailing != null) trailing() else if (onClick != null) Icon(Icons.Filled.ChevronRight, null, tint = Color(0xFF334155))
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFEAF0FA)))
}

@Composable
fun ChoiceDialog(title: String, options: List<String>, current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column {
                options.forEachIndexed { i, o ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(i); onDismiss() }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = i == current, onClick = { onPick(i); onDismiss() })
                        Text(o)
                    }
                }
            }
        },
        confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SettingsScreen(nav: NavController) {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf("") }
    var avatar by remember { mutableStateOf(loadAvatar(ctx)) }
    var name by remember { mutableStateOf(Prefs.name(ctx)) }
    var email by remember { mutableStateOf(Prefs.email(ctx)) }
    var theme by remember { mutableIntStateOf(Prefs.theme(ctx)) }
    var urdu by remember { mutableStateOf(Prefs.urdu(ctx)) }
    var fl by remember { mutableIntStateOf(Prefs.fontLevel(ctx)) }
    var auto by remember { mutableStateOf(Prefs.autoSave(ctx)) }
    var ext by remember { mutableStateOf(Prefs.showExt(ctx)) }
    var fmt by remember { mutableIntStateOf(Prefs.defFormat(ctx)) }
    var paper by remember { mutableIntStateOf(Prefs.paper(ctx)) }
    var land by remember { mutableStateOf(Prefs.landscape(ctx)) }
    var qual by remember { mutableIntStateOf(Prefs.quality(ctx)) }
    var cache by remember { mutableStateOf(Data.cacheSize(ctx)) }
    var editName by remember { mutableStateOf("") }
    var editMail by remember { mutableStateOf("") }
    val version = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0.0" } catch (_: Exception) { "1.0.0" } }

    val avatarPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            decodeBitmap(ctx, u, 512)?.let { bm ->
                FileOutputStream(File(ctx.filesDir, "avatar.jpg")).use { bm.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                avatar = loadAvatar(ctx)
            }
        }
    }
    val backupL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { u ->
        if (u != null) toast(ctx, try { "${Data.backup(ctx, u)} فائلیں بیک اپ ہوئیں / files backed up" } catch (_: Exception) { "Backup failed" })
    }
    val restoreL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) toast(ctx, try { "${Data.restore(ctx, u)} فائلیں بحال ہوئیں / files restored" } catch (_: Exception) { "Restore failed" })
    }

    var saveWhere by remember { mutableStateOf(PublicSave.where(ctx)) }
    val treeL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                PublicSave.setTree(ctx, u)
                saveWhere = PublicSave.where(ctx)
                toast(ctx, "فولڈر منتخب ہو گیا / Folder selected\n📁 $saveWhere")
            } catch (_: Exception) { toast(ctx, "یہ فولڈر استعمال نہیں ہو سکا / Could not use this folder") }
        }
    }

    val fontNames = listOf("Small", "Normal", "Large", "Extra Large")
    val paperNames = listOf("A4 (210 × 297 mm)", "Letter (8.5 × 11 in)", "Legal (8.5 × 14 in)")
    val fmtNames = listOf("DOCX", "PDF", "TXT")
    val qualNames = listOf("Draft", "Normal", "High")

    Scaffold(
        containerColor = Bg,
        topBar = { AppHeader("آسان طریقے سے اپنی دستاویزات بنائیں", onBack = { nav.popBackStack() }, onHome = { goHome(nav) }) },
        bottomBar = {
            MainBar(nav, 4)
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // profile
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(onClick = { nav.navigate("profile") }, modifier = Modifier.weight(1.5f), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFDCEBFF))) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(68.dp).clickable { avatarPick.launch("image/*") }) {
                            Box(Modifier.fillMaxSize().clip(CircleShape).background(Blue), contentAlignment = Alignment.Center) {
                                if (avatar != null) Image(avatar!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                else Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(44.dp))
                            }
                            Box(Modifier.align(Alignment.BottomEnd).size(24.dp).clip(CircleShape).background(Blue), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.PhotoCamera, null, tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(name, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, maxLines = 1)
                            Text(email, fontSize = 12.sp, maxLines = 1)
                            Button(
                                onClick = { editName = name; editMail = email; dlg = "profile" }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Blue), modifier = Modifier.height(30.dp)
                            ) { Icon(Icons.Filled.Edit, null, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text("Edit Profile", fontSize = 12.sp) }
                        }
                    }
                }
                Card(Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFDCEBFF))) {
                    Column(Modifier.padding(10.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Star, null, tint = Blue, modifier = Modifier.size(34.dp))
                        Text("MSF Document Writer", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Version $version", fontSize = 11.sp)
                    }
                }
            }
            Section("App Settings", Icons.Filled.Settings, Blue, Color(0xFFE3EEFF)) {
                SRow(Icons.Filled.Language, Color(0xFF1E88E5), "Language", if (urdu) "Urdu (اردو)" else "English", if (urdu) "اردو" else "English") { dlg = "lang" }
                SRow(Icons.Filled.Palette, Color(0xFF7C4DFF), "Theme", "Choose your app theme", Themes[theme].first) { dlg = "theme" }
                SRow(Icons.Filled.FormatSize, Color(0xFF1E5CD6), "Font Size", "Adjust text size for better reading", fontNames[fl]) { dlg = "font" }
                SRow(Icons.Filled.ToggleOn, Color(0xFF16A34A), "Auto Save", "Automatically save your work", trailing = {
                    Switch(checked = auto, onCheckedChange = { auto = it; Prefs.setBool(ctx, "autosave", it) })
                })
                SRow(Icons.Filled.Description, Color(0xFF1E5CD6), "Show File Extension", "Display file extensions (e.g. .docx, .pdf)", trailing = {
                    Switch(checked = ext, onCheckedChange = { ext = it; Prefs.setBool(ctx, "showext", it) })
                })
            }
            Section("Save Location / محفوظ کرنے کی جگہ", Icons.Filled.Folder, Color(0xFFF59E0B), Color(0xFFFFF1D6)) {
                SRow(Icons.Filled.Folder, Color(0xFFF59E0B), "Save Folder", saveWhere) {
                    treeL.launch(null)
                }
                SRow(Icons.Filled.Info, Color(0xFFF59E0B), "فائل مینیجر میں کہاں؟", "ہر فائل اس فولڈر میں بھی محفوظ ہوتی ہے۔ فولڈر بدلنے کے لیے اوپر ٹیپ کریں (موبائل اسٹوریج یا SD کارڈ)")
                if (PublicSave.treeUri(ctx) != null) {
                    SRow(Icons.Filled.Delete, Color(0xFFF59E0B), "Reset to default", "Documents/MSF Document Writer") {
                        PublicSave.setTree(ctx, null); saveWhere = PublicSave.where(ctx)
                    }
                }
            }
            Section("Document Settings", Icons.Filled.Description, Blue, Color(0xFFE3EEFF)) {
                SRow(Icons.Filled.NoteAdd, Color(0xFF1E5CD6), "Default File Format", "Select default format for new documents", fmtNames[fmt]) { dlg = "fmt" }
                SRow(Icons.Filled.AspectRatio, Color(0xFF1E88E5), "Default Paper Size", "Set default paper size for new documents", paperNames[paper].substringBefore(" (")) { dlg = "paper" }
                SRow(Icons.Filled.ScreenRotation, Color(0xFF1E88E5), "Default Orientation", "Set default page orientation", if (land) "Landscape" else "Portrait") { dlg = "orient" }
                SRow(Icons.Filled.Print, Color(0xFF1E5CD6), "Print Quality", "Choose print quality for better output", qualNames[qual]) { dlg = "qual" }
            }
            Section("Data & Privacy", Icons.Filled.Security, Color(0xFF16A34A), Color(0xFFDFF7E8)) {
                SRow(Icons.Filled.CloudUpload, Color(0xFF16A34A), "Backup Documents", "Save your documents to cloud or local storage") { backupL.launch("MSF_Backup_${stamp()}.zip") }
                SRow(Icons.Filled.CloudDownload, Color(0xFF16A34A), "Restore Documents", "Restore your backed up documents") {
                    restoreL.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
                }
                SRow(Icons.Filled.Delete, Color(0xFF16A34A), "Clear Cache", "Free up storage space", fmtSize(cache)) { dlg = "cache" }
                SRow(Icons.Filled.Shield, Color(0xFF16A34A), "Privacy Policy", "Read our privacy policy") { nav.navigate("privacy") }
                SRow(Icons.Filled.Article, Color(0xFF16A34A), "Terms & Conditions", "Read terms and conditions") { nav.navigate("terms") }
            }
            Section("About", Icons.Filled.Info, Color(0xFF3B3BDB), Color(0xFFE6E9FB)) {
                SRow(Icons.Filled.Info, Color(0xFF1E5CD6), "App Version", "Check current version", version) { nav.navigate("about") }
                SRow(Icons.Filled.HelpOutline, Color(0xFF1E5CD6), "Help & Support", "Get help and contact us") {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$SUPPORT_EMAIL")).putExtra(Intent.EXTRA_SUBJECT, "MSF Document Writer - Support"))
                    } catch (_: Exception) { toast(ctx, "No email app found") }
                }
                SRow(Icons.Filled.Star, Color(0xFF1E5CD6), "Rate Us", "Support us with your valuable feedback") {
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${ctx.packageName}"))) }
                    catch (_: Exception) {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${ctx.packageName}"))) }
                        catch (_: Exception) { toast(ctx, "Cannot open store") }
                    }
                }
                SRow(Icons.Filled.Share, Color(0xFF1E5CD6), "Share App", "Share with your friends and family") {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, "MSF Document Writer: https://play.google.com/store/apps/details?id=${ctx.packageName}")
                    ctx.startActivity(Intent.createChooser(i, "Share App"))
                }
            }
            Button(
                onClick = { dlg = "logout" }, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
            ) { Icon(Icons.Filled.Logout, null); Spacer(Modifier.width(8.dp)); Text("Log Out", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(8.dp))
        }
    }

    when (dlg) {
        "lang" -> ChoiceDialog("Language / زبان", listOf("اردو + English", "English only"), if (urdu) 0 else 1, {
            urdu = it == 0; Prefs.setBool(ctx, "urdu", urdu); AppState.urdu = urdu
        }) { dlg = "" }
        "theme" -> ChoiceDialog("Theme / تھیم", Themes.map { it.first }, theme, {
            theme = it; Prefs.setInt(ctx, "theme", it); AppState.accent = Color(Themes[it].second)
        }) { dlg = "" }
        "font" -> ChoiceDialog("Font Size / فونٹ سائز", fontNames, fl, { fl = it; Prefs.setInt(ctx, "fl", it) }) { dlg = "" }
        "fmt" -> ChoiceDialog("Default File Format", fmtNames, fmt, { fmt = it; Prefs.setInt(ctx, "defformat", it) }) { dlg = "" }
        "paper" -> ChoiceDialog("Default Paper Size", paperNames, paper, { paper = it; Prefs.setInt(ctx, "paper", it) }) { dlg = "" }
        "orient" -> ChoiceDialog("Default Orientation", listOf("Portrait", "Landscape"), if (land) 1 else 0, {
            land = it == 1; Prefs.setBool(ctx, "landscape", land)
        }) { dlg = "" }
        "qual" -> ChoiceDialog("Print Quality", qualNames, qual, { qual = it; Prefs.setInt(ctx, "quality", it) }) { dlg = "" }
        "cache" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Clear Cache") }, text = { Text("${fmtSize(cache)} عارضی فائلیں حذف ہوں گی۔ / Temporary files will be deleted.") },
            confirmButton = { TextButton(onClick = { Data.clearCache(ctx); cache = Data.cacheSize(ctx); dlg = ""; toast(ctx, "Cache cleared") }) { Text("Clear") } },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
        )
        "profile" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Edit Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = editName, onValueChange = { editName = it }, singleLine = true, label = { Text("Name / نام") })
                    OutlinedTextField(value = editMail, onValueChange = { editMail = it }, singleLine = true, label = { Text("Email") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    name = editName.trim().ifEmpty { "User" }; email = editMail.trim()
                    Prefs.setStr(ctx, "name", name); Prefs.setStr(ctx, "email", email); dlg = ""
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
        )
        "logout" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Log Out") },
            text = { Text("پروفائل کی معلومات صاف ہو جائیں گی (دستاویزات محفوظ رہیں گی)۔ / Profile info will be cleared (documents are kept).") },
            confirmButton = {
                TextButton(onClick = {
                    Prefs.setStr(ctx, "name", "Guest"); Prefs.setStr(ctx, "email", ""); File(ctx.filesDir, "avatar.jpg").delete()
                    name = "Guest"; email = ""; avatar = null; dlg = ""
                    goHome(nav)
                }) { Text("Log Out", color = Color(0xFFD32F2F)) }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
        )
    }
}

const val SUPPORT_EMAIL = "support@example.com" // TODO: put your real support email here
