package com.msf.documentwriter

import android.text.Editable
import android.text.Spanned

/** Where the cursor is inside a table: size, current row / column (0-based), header flag and colour style. */
data class TblInfo(val rows: Int, val cols: Int, val row: Int, val col: Int, val header: Boolean, val style: Int)

/**
 * Table editing on the |cell|cell| text lines used by the editor.
 * All functions take the editor text and a cursor position inside the table.
 */
object TableOps {
    private fun lineStart(s: String, p: Int): Int = s.lastIndexOf('\n', p - 1) + 1
    private fun lineEnd(s: String, p: Int): Int {
        val n = s.indexOf('\n', p)
        return if (n < 0) s.length else n
    }

    private class Lines(val starts: List<Int>, val ends: List<Int>)

    private fun lines(s: String, pos: Int): Lines? {
        val p = pos.coerceIn(0, s.length)
        val ls0 = lineStart(s, p)
        if (!Tables.isRow(s.substring(ls0, lineEnd(s, ls0)))) return null
        var first = ls0
        while (first > 0) {
            val ps = lineStart(s, first - 1)
            if (Tables.isRow(s.substring(ps, first - 1))) first = ps else break
        }
        val starts = ArrayList<Int>()
        val ends = ArrayList<Int>()
        var cur = first
        while (cur <= s.length) {
            val e = lineEnd(s, cur)
            if (!Tables.isRow(s.substring(cur, e))) break
            starts.add(cur); ends.add(e)
            if (e >= s.length) break
            cur = e + 1
        }
        if (starts.isEmpty()) return null
        return Lines(starts, ends)
    }

    private fun pipes(s: String, a: Int, b: Int): List<Int> {
        val out = ArrayList<Int>()
        for (i in a until b) if (s[i] == '|') out.add(i)
        return out
    }

    private fun isSep(s: String, ls: Lines, i: Int): Boolean = Tables.isSeparator(s.substring(ls.starts[i], ls.ends[i]))

    /** Indexes (into the table lines) of the real rows, i.e. without the |---| header line. */
    private fun dataLines(s: String, ls: Lines): List<Int> = ls.starts.indices.filter { !isSep(s, ls, it) }

    private fun hasHeader(s: String, ls: Lines): Boolean = ls.starts.size > 1 && isSep(s, ls, 1)

    private fun template(cols: Int) = "|" + "   |".repeat(cols)
    private fun separator(cols: Int) = "|" + "---|".repeat(cols)

    fun info(e: Editable, pos: Int): TblInfo? {
        val s = e.toString()
        val ls = lines(s, pos) ?: return null
        val data = dataLines(s, ls)
        if (data.isEmpty()) return null
        val p = pos.coerceIn(0, s.length)
        var li = ls.starts.indexOfLast { it <= p }
        if (li < 0) li = 0
        var row = data.indexOf(li)
        if (row < 0) row = 0
        val pl = pipes(s, ls.starts[li], ls.ends[li])
        val cols = (pipes(s, ls.starts[data[0]], ls.ends[data[0]]).size - 1).coerceAtLeast(1)
        var col = pl.count { it < p } - 1
        col = col.coerceIn(0, cols - 1)
        return TblInfo(data.size, cols, row, col, hasHeader(s, ls), TableStyles.at(e, ls.starts[0]))
    }

    /** Puts the colour style on the first line of the table that contains [pos]. */
    fun setStyle(e: Editable, pos: Int, style: Int) {
        val s = e.toString()
        val ls = lines(s, pos) ?: return
        val a = ls.starts[0]
        val b = ls.ends[ls.ends.size - 1]
        for (sp in e.getSpans(a, b, TableStyleSpan::class.java)) e.removeSpan(sp)
        if (style > 0) {
            val end = ls.ends[0]
            val spEnd = if (end < s.length) end + 1 else end
            if (spEnd > a) e.setSpan(TableStyleSpan(style), a, spEnd, Spanned.SPAN_PARAGRAPH)
        }
    }

    /** Stored column fractions of the table that contains [pos], or null. */
    fun widths(e: Editable, pos: Int): FloatArray? {
        val s = e.toString()
        val ls = lines(s, pos) ?: return null
        val cols = (pipes(s, ls.starts[0], ls.ends[0]).size - 1).coerceAtLeast(1)
        return TableWidths.at(e, ls.starts[0], ls.ends[ls.ends.size - 1], cols)
    }

    /** Stores column fractions for the table that contains [pos]; null = equal columns again. */
    fun setWidths(e: Editable, pos: Int, fr: FloatArray?) {
        val s = e.toString()
        val ls = lines(s, pos) ?: return
        val a = ls.starts[0]
        val b = ls.ends[ls.ends.size - 1]
        for (sp in e.getSpans(a, b, TableWidthSpan::class.java)) e.removeSpan(sp)
        if (fr != null) {
            val end = if (b < s.length) b + 1 else b
            if (end > a) e.setSpan(TableWidthSpan(fr), a, end, Spanned.SPAN_PARAGRAPH)
        }
    }

    /** Extra height (dp) of table row [row]. */
    fun rowExtra(e: Editable, pos: Int, row: Int): Float {
        val s = e.toString()
        val ls = lines(s, pos) ?: return 0f
        val data = dataLines(s, ls)
        val li = data.getOrNull(row) ?: return 0f
        return RowHeights.at(e, ls.starts[li])
    }

    fun setRowExtra(e: Editable, pos: Int, row: Int, dp: Float, density: Float) {
        val s = e.toString()
        val ls = lines(s, pos) ?: return
        val data = dataLines(s, ls)
        val li = data.getOrNull(row) ?: return
        val a = ls.starts[li]
        val b = ls.ends[li]
        for (sp in e.getSpans(a, b, RowHeightSpan::class.java)) e.removeSpan(sp)
        if (dp > 0.5f) {
            val end = if (b < s.length) b + 1 else b
            if (end > a) e.setSpan(RowHeightSpan(dp, density), a, end, Spanned.SPAN_PARAGRAPH)
        }
    }

    /** Cursor position inside cell (row, col) of the table that contains [pos]. */
    fun cellPos(e: Editable, pos: Int, row: Int, col: Int): Int {
        val r = cellRange(e, pos, row, col) ?: return pos
        return r.second
    }

    /** Text range of a cell; an empty cell gives the whole space between its two bars. */
    fun cellRange(e: Editable, pos: Int, row: Int, col: Int): Pair<Int, Int>? {
        val s = e.toString()
        val ls = lines(s, pos) ?: return null
        val data = dataLines(s, ls)
        val li = data.getOrNull(row.coerceIn(0, data.size - 1)) ?: return null
        val pl = pipes(s, ls.starts[li], ls.ends[li])
        if (pl.size < 2) return null
        val c = col.coerceIn(0, pl.size - 2)
        var a = pl[c] + 1
        var b = pl[c + 1]
        val fa = a
        val fb = b
        while (a < b && s[a] == ' ') a++
        while (b > a && s[b - 1] == ' ') b--
        return if (b > a) Pair(a, b) else Pair(fa, fb)
    }

    /** Range of the whole table. */
    fun tableRange(e: Editable, pos: Int): Pair<Int, Int>? {
        val s = e.toString()
        val ls = lines(s, pos) ?: return null
        return Pair(ls.starts[0], ls.ends[ls.ends.size - 1])
    }

    private fun restyle(e: Editable, style: Int, pos: Int) {
        val p = pos.coerceIn(0, e.length)
        setStyle(e, p, style)
    }

    /** Adds an empty row below (or above) the current row. Returns the cursor position of the new row. */
    fun addRow(e: Editable, pos: Int, below: Boolean): Int {
        val inf = info(e, pos) ?: return pos
        val s = e.toString()
        val ls = lines(s, pos) ?: return pos
        val data = dataLines(s, ls)
        val li = data[inf.row]
        val tpl = template(inf.cols)
        val lk0 = TableLocks.get(e, pos)
        val newIdx = if (below) inf.row + 1 else inf.row
        val at: Int
        if (below) {
            var last = li
            if (inf.row == 0 && inf.header) last = li + 1
            at = ls.ends[last]
            e.insert(at, "\n" + tpl)
        } else {
            at = ls.starts[li]
            e.insert(at, tpl + "\n")
        }
        val first = ls.starts[0]
        restyle(e, inf.style, first)
        if (lk0.any) TableLocks.set(e, first, lk0.rows.map { if (it >= newIdx) it + 1 else it }.toSet(), lk0.cols)
        val np = if (below) at + 1 else at
        return (np + 2).coerceIn(0, e.length)
    }

    /** Adds an empty column to the right (or left) of the current column. */
    fun addCol(e: Editable, pos: Int, right: Boolean): Int {
        val inf = info(e, pos) ?: return pos
        val lk0 = TableLocks.get(e, pos)
        setWidths(e, pos, null)
        val s = e.toString()
        val ls = lines(s, pos) ?: return pos
        for (i in ls.starts.indices.reversed()) {
            val pl = pipes(s, ls.starts[i], ls.ends[i])
            if (pl.size < 2) continue
            val idx = minOf(inf.col + (if (right) 1 else 0), pl.size - 1)
            val txt = if (Tables.isSeparator(s.substring(ls.starts[i], ls.ends[i]))) "---|" else "   |"
            e.insert(pl[idx] + 1, txt)
        }
        restyle(e, inf.style, ls.starts[0])
        if (lk0.any) {
            val newCol = if (right) inf.col + 1 else inf.col
            TableLocks.set(e, ls.starts[0], lk0.rows, lk0.cols.map { if (it >= newCol) it + 1 else it }.toSet())
        }
        return cellPos(e, ls.starts[0], inf.row, if (right) inf.col + 1 else inf.col)
    }

    /** Deletes the current row; false when it is the only row. */
    fun deleteRow(e: Editable, pos: Int): Boolean {
        val inf = info(e, pos) ?: return false
        if (inf.rows <= 1) return false
        val lk0 = TableLocks.get(e, pos)
        if (lk0.rows.contains(inf.row)) return false
        val s = e.toString()
        val ls = lines(s, pos) ?: return false
        val data = dataLines(s, ls)
        val first = data[inf.row]
        val last = if (inf.row == 0 && inf.header) first + 1 else first
        var a = ls.starts[first]
        var b = ls.ends[last]
        if (b < s.length) b += 1 else if (a > 0) a -= 1
        val tableStart = ls.starts[0]
        e.delete(a, b)
        restyle(e, inf.style, minOf(tableStart, e.length))
        if (lk0.any) {
            val rs = lk0.rows.filter { it != inf.row }.map { if (it > inf.row) it - 1 else it }.toSet()
            TableLocks.set(e, minOf(tableStart, maxOf(e.length - 1, 0)), rs, lk0.cols)
        }
        return true
    }

    private fun cleanCopy(cs: CharSequence): CharSequence = TableGuard.cleanSpans(android.text.SpannableStringBuilder(cs))

    /**
     * Moves the current column [dir] places inside the text row (negative = towards the start, positive = towards the end;
     * the screen shows the start on the right in right-to-left documents). The column goes exactly [dir] places, or as far as
     * the table allows. Every row is rebuilt from clean copies of its cells, so no drawing span is left behind on the wrong
     * text. Returns the cursor position inside the moved column, or null when it cannot move.
     */
    fun moveCol(e: Editable, pos: Int, dir: Int): Int? {
        val inf = info(e, pos) ?: return null
        val c = inf.col
        val to = (c + dir).coerceIn(0, inf.cols - 1)
        if (to == c) return null
        val s = e.toString()
        val ls = lines(s, pos) ?: return null
        val fr = widths(e, pos)
        val tableStart = ls.starts[0]
        // new order of the old column numbers
        val order = ArrayList<Int>((0 until inf.cols).toList())
        order.removeAt(c)
        order.add(to, c)
        // rebuild every line, last line first so the earlier positions stay valid
        for (i in ls.starts.indices.reversed()) {
            val ln = s.substring(ls.starts[i], ls.ends[i])
            if (Tables.isSeparator(ln)) continue
            val pl = pipes(s, ls.starts[i], ls.ends[i])
            if (pl.size < 2) continue
            val cells = ArrayList<CharSequence>()
            for (j in 0 until pl.size - 1) cells.add(cleanCopy(e.subSequence(pl[j] + 1, pl[j + 1])))
            val sb = android.text.SpannableStringBuilder()
            for (k in 0 until inf.cols) {
                if (k > 0) sb.append("|")
                val src = order[k]
                if (src < cells.size) sb.append(cells[src])
            }
            e.replace(pl[0] + 1, pl[pl.size - 1], sb)
        }
        if (fr != null && fr.size == inf.cols) {
            val w = FloatArray(inf.cols) { fr[order[it]] }
            setWidths(e, tableStart, w)
        }
        val lk = TableLocks.get(e, tableStart)
        if (lk.cols.isNotEmpty()) {
            // locked columns never move (the screen refuses that), but the ones between are shifted by one place
            val inv = IntArray(inf.cols)
            for (k in order.indices) inv[order[k]] = k
            TableLocks.set(e, tableStart, lk.rows, lk.cols.map { if (it in 0 until inf.cols) inv[it] else it }.toSet())
        }
        restyle(e, inf.style, tableStart)
        return cellPos(e, tableStart, inf.row, to)
    }

    /**
     * Moves the current row [dir] places (negative = up, positive = down), or as far as the table allows. The |---| header
     * line stays where it is. Returns the cursor position inside the moved row, or null when it cannot move.
     */
    fun moveRow(e: Editable, pos: Int, dir: Int): Int? {
        val inf = info(e, pos) ?: return null
        val r = inf.row
        val to = (r + dir).coerceIn(0, inf.rows - 1)
        if (to == r) return null
        val s = e.toString()
        val ls = lines(s, pos) ?: return null
        val data = dataLines(s, ls)
        val tableStart = ls.starts[0]
        val dens = android.content.res.Resources.getSystem().displayMetrics.density
        val n = data.size
        val order = ArrayList<Int>((0 until n).toList())
        order.removeAt(r)
        order.add(to, r)
        // clean inner text and extra height of every row, taken before anything is changed
        val inner = ArrayList<CharSequence>()
        val extra = ArrayList<Float>()
        for (k in 0 until n) {
            val li = data[k]
            val pl = pipes(s, ls.starts[li], ls.ends[li])
            inner.add(if (pl.size >= 2) cleanCopy(e.subSequence(pl[0] + 1, pl[pl.size - 1])) else "")
            extra.add(RowHeights.at(e, ls.starts[li]))
        }
        for (k in (0 until n).reversed()) {
            if (order[k] == k) continue
            val li = data[k]
            val pl = pipes(s, ls.starts[li], ls.ends[li])
            if (pl.size < 2) continue
            e.replace(pl[0] + 1, pl[pl.size - 1], inner[order[k]])
        }
        for (k in 0 until n) setRowExtra(e, tableStart, k, extra[order[k]], dens)
        val lk = TableLocks.get(e, tableStart)
        if (lk.rows.isNotEmpty()) {
            val inv = IntArray(n)
            for (k in order.indices) inv[order[k]] = k
            TableLocks.set(e, tableStart, lk.rows.map { if (it in 0 until n) inv[it] else it }.toSet(), lk.cols)
        }
        restyle(e, inf.style, tableStart)
        return cellPos(e, tableStart, to, inf.col)
    }

    /** Deletes the current column; false when it is the only column. */
    fun deleteCol(e: Editable, pos: Int): Boolean {
        val inf = info(e, pos) ?: return false
        if (inf.cols <= 1) return false
        val lk0 = TableLocks.get(e, pos)
        if (lk0.cols.contains(inf.col)) return false
        setWidths(e, pos, null)
        val s = e.toString()
        val ls = lines(s, pos) ?: return false
        for (i in ls.starts.indices.reversed()) {
            val pl = pipes(s, ls.starts[i], ls.ends[i])
            if (pl.size < 3) continue
            val c = minOf(inf.col, pl.size - 2)
            e.delete(pl[c], pl[c + 1])
        }
        restyle(e, inf.style, ls.starts[0])
        if (lk0.any) {
            val cs = lk0.cols.filter { it != inf.col }.map { if (it > inf.col) it - 1 else it }.toSet()
            TableLocks.set(e, ls.starts[0], lk0.rows, cs)
        }
        return true
    }

    /** Removes the whole table; returns where the cursor should go. */
    fun deleteTable(e: Editable, pos: Int): Int {
        val s = e.toString()
        val ls = lines(s, pos) ?: return pos
        var a = ls.starts[0]
        var b = ls.ends[ls.ends.size - 1]
        if (b < s.length) b += 1 else if (a > 0) a -= 1
        e.delete(a, b)
        return a.coerceIn(0, e.length)
    }

    /** Turns the header row (first row + |---| line) on or off. */
    fun setHeader(e: Editable, pos: Int, on: Boolean) {
        val inf = info(e, pos) ?: return
        val s = e.toString()
        val ls = lines(s, pos) ?: return
        val has = hasHeader(s, ls)
        if (on && !has) {
            e.insert(ls.ends[0], "\n" + separator(inf.cols))
        } else if (!on && has) {
            e.delete(ls.ends[0], ls.ends[1])
        }
        restyle(e, inf.style, ls.starts[0])
    }
}
