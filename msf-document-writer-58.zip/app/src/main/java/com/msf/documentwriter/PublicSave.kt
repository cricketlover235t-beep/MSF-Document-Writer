package com.msf.documentwriter

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import java.io.File

/**
 * Every saved document is also copied to a folder that the phone's File Manager can see.
 * Default: Documents/MSF Document Writer (phone storage). The user can pick any other folder
 * (phone storage or SD card) in Settings → "Save Location".
 */
object PublicSave {
    const val FOLDER = "MSF Document Writer"
    private const val KEY_TREE = "save_tree"

    fun treeUri(c: Context): Uri? {
        val s = Prefs.str(c, KEY_TREE, "")
        if (s.isEmpty()) return null
        val u = Uri.parse(s)
        val ok = c.contentResolver.persistedUriPermissions.any { it.uri == u && it.isWritePermission }
        return if (ok) u else null
    }

    fun setTree(c: Context, u: Uri?) = Prefs.setStr(c, KEY_TREE, u?.toString() ?: "")

    /** Readable place where the copies are saved. */
    fun where(c: Context): String {
        val t = treeUri(c)
        if (t != null) {
            return try {
                val id = DocumentsContract.getTreeDocumentId(t)
                val vol = id.substringBefore(':')
                val path = id.substringAfter(':', "")
                val root = if (vol == "primary") "موبائل اسٹوریج / Phone storage" else "SD کارڈ / SD card"
                if (path.isEmpty()) root else "$root/$path"
            } catch (_: Exception) { "Selected folder" }
        }
        return "موبائل اسٹوریج / Phone storage → Documents/$FOLDER"
    }

    /** Did the last copy reach the File Manager, and where. */
    var lastOk = true
    private var lastPlace = ""

    /** One line for the "saved" message: the real folder, or a warning when the copy failed. */
    fun note(c: Context): String =
        if (lastOk) "📁 " + lastPlace.ifEmpty { where(c) }
        else "⚠ فائل مینیجر میں کاپی نہیں ہو سکی / Copy to File Manager failed.\nSettings → Save Location میں فولڈر منتخب کریں"

    fun copy(c: Context, f: File): Boolean {
        lastOk = false
        if (!f.exists()) return false
        val t = treeUri(c)
        if (t != null) {
            try { if (copyToTree(c, t, f)) { lastOk = true; lastPlace = where(c); return true } } catch (_: Exception) {}
        }
        val ok = try { copyToDocuments(c, f) } catch (_: Exception) { false }
        lastOk = ok
        lastPlace = "موبائل اسٹوریج / Phone storage → ${if (f.name.substringAfterLast('.').lowercase() in setOf("jpg", "jpeg", "png")) "Pictures" else "Documents"}/$FOLDER"
        return ok
    }

    private fun copyToTree(c: Context, tree: Uri, f: File): Boolean {
        val r = c.contentResolver
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, rootId)
        var target: Uri? = null
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId)
        r.query(kids, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { cur ->
            while (cur.moveToNext()) {
                if (cur.getString(1) == f.name) { target = DocumentsContract.buildDocumentUriUsingTree(tree, cur.getString(0)); break }
            }
        }
        val dest = target ?: DocumentsContract.createDocument(r, parent, Store.mime(f), f.name) ?: return false
        val out = r.openOutputStream(dest, "wt") ?: return false
        out.use { o -> f.inputStream().use { it.copyTo(o) } }
        return true
    }

    private fun copyToDocuments(c: Context, f: File): Boolean {
        val mime = Store.mime(f)
        if (Build.VERSION.SDK_INT >= 29) {
            val r = c.contentResolver
            val isImage = mime.startsWith("image/")
            val coll = if (isImage) MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val rel = (if (isImage) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_DOCUMENTS) + "/" + FOLDER
            var uri: Uri? = null
            r.query(
                coll, arrayOf(MediaStore.MediaColumns._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                arrayOf(f.name, "$rel/%"), null
            )?.use { if (it.moveToFirst()) uri = ContentUris.withAppendedId(coll, it.getLong(0)) }
            if (uri == null) {
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                }
                uri = r.insert(coll, cv)
            }
            val u = uri ?: return false
            try {
                val out = r.openOutputStream(u, "wt") ?: return false
                out.use { o -> f.inputStream().use { it.copyTo(o) } }
                return true
            } catch (e: Exception) {
                // an older copy made by a previous install cannot be overwritten: save under a new name instead
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, f.nameWithoutExtension + "_" + (System.currentTimeMillis() % 100000) + "." + f.extension)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                }
                val u2 = r.insert(coll, cv) ?: return false
                val out2 = r.openOutputStream(u2, "wt") ?: return false
                out2.use { o -> f.inputStream().use { it.copyTo(o) } }
                return true
            }
        }
        // Android 7–9: plain file in Documents (needs the storage permission)
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), FOLDER)
        if (!dir.exists() && !dir.mkdirs()) return false
        val dest = File(dir, f.name)
        f.copyTo(dest, overwrite = true)
        MediaScannerConnection.scanFile(c, arrayOf(dest.absolutePath), null, null)
        return true
    }
}
