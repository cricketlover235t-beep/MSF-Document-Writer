@file:OptIn(ExperimentalMaterial3Api::class)

package com.msf.documentwriter

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.*
import java.io.File

val Themes = listOf(
    "Blue" to 0xFF0B4DB8, "Green" to 0xFF0F7B4F, "Purple" to 0xFF5B3CC4, "Teal" to 0xFF00796B, "Maroon" to 0xFF8E2430
)

object AppState {
    var accent by mutableStateOf(Color(0xFF0B4DB8))
    var urdu by mutableStateOf(true)
}

val Blue: Color get() = AppState.accent
val Yellow = Color(0xFFFFC107)
val Bg = Color(0xFFF2F6FF)

data class Nav(val icon: ImageVector, val label: String, val onClick: () -> Unit)

data class TileData(
    val en: String,
    val ur: String,
    val tint: Color,
    val bg: Color,
    val icon: ImageVector? = null,
    val letter: String? = null,
    val selected: Boolean = false,
    val onClick: () -> Unit
)

@Composable
fun AppHeader(
    sub: String,
    title1: String = "MSF Document ",
    accent: String = "Writer",
    title2: String = "",
    onBack: (() -> Unit)? = null,
    onHome: (() -> Unit)? = null,
    menu: List<Pair<String, () -> Unit>> = emptyList(),
    icon: ImageVector? = null,
    sub2: String? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    var more by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().background(Blue).padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null, tint = Color.White) }
        else Spacer(Modifier.width(8.dp))
        if (icon != null) Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF1F6BEA)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(28.dp))
        } else Image(painterResource(R.mipmap.ic_launcher), null, Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                buildAnnotatedString {
                    append(title1)
                    withStyle(SpanStyle(color = Yellow)) { append(accent) }
                    append(title2)
                },
                color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, maxLines = 1
            )
            Text(sub, color = Color.White.copy(alpha = 0.9f), fontSize = if (sub2 != null) 14.sp else 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub2 != null) Text(sub2, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        actions()
        if (onHome != null || menu.isNotEmpty()) Box {
            IconButton(onClick = { more = true }) { Icon(Icons.Filled.MoreVert, null, tint = Color.White) }
            DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
                if (onHome != null) DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Filled.Home, null, tint = Blue) },
                    text = { Text("Home / ہوم") }, onClick = { more = false; onHome() }
                )
                menu.forEach { (label, act) ->
                    DropdownMenuItem(text = { Text(label) }, onClick = { more = false; act() })
                }
            }
        }
    }
}

@Composable
fun Tile(t: TileData, modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(14.dp)).background(t.bg)
            .border(if (t.selected) 2.dp else 1.dp, if (t.selected) Blue else t.tint.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
            .clickable(onClick = t.onClick)
    ) {
        Column(
            Modifier.fillMaxWidth().align(Alignment.Center).padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(50.dp).clip(RoundedCornerShape(12.dp)).background(t.tint), contentAlignment = Alignment.Center) {
                if (t.letter != null) Text(t.letter, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                else if (t.icon != null) Icon(t.icon, null, tint = Color.White, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.height(6.dp))
            Text(t.en, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 2)
            if (AppState.urdu) Text(t.ur, fontSize = 12.sp, color = Color.DarkGray, textAlign = TextAlign.Center, maxLines = 2)
        }
        if (t.selected) Box(
            Modifier.align(Alignment.TopEnd).padding(6.dp).size(20.dp).clip(CircleShape).background(Blue),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(14.dp)) }
    }
}

@Composable
fun TileGrid(items: List<TileData>, height: Dp = 112.dp) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { t -> Tile(t, Modifier.weight(1f).height(height)) }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun SectionTitle(en: String, ur: String, trailing: String? = null, onTrailing: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(en, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color(0xFF0A2A66), modifier = Modifier.weight(1f))
        if (trailing != null) TextButton(onClick = onTrailing) { Text(trailing, color = Blue) }
        else if (AppState.urdu) Text(ur, fontSize = 15.sp, color = Color(0xFF0A2A66))
    }
}

@Composable
fun BottomBar(items: List<Nav>, selected: Int, center: Int = -1) {
    Row(
        Modifier.fillMaxWidth().background(Blue).height(68.dp).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEachIndexed { i, n ->
            val sel = i == selected
            if (i == center) {
                Column(
                    Modifier.weight(1f).requiredHeight(86.dp).offset(y = (-8).dp).clickable(onClick = n.onClick),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.size(56.dp).clip(CircleShape).background(Color(0xFF1F6BEA)).border(3.dp, Color(0xFFBBD0FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Icon(n.icon, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                    Spacer(Modifier.height(2.dp))
                    Text(n.label, fontSize = 11.sp, color = Color.White, maxLines = 1, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                }
            } else {
                Column(
                    Modifier.weight(1f).padding(vertical = 6.dp).clip(RoundedCornerShape(16.dp))
                        .background(if (sel) Color(0xFF1F6BEA) else Color.Transparent)
                        .clickable(onClick = n.onClick).padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(n.icon, null, tint = if (sel) Color.White else Color(0xFFC3D6FF), modifier = Modifier.size(26.dp))
                    Text(n.label, fontSize = 11.sp, maxLines = 1, color = if (sel) Color.White else Color(0xFFC3D6FF))
                    if (sel) Box(Modifier.padding(top = 2.dp).width(34.dp).height(2.dp).background(Color.White))
                }
            }
        }
    }
}

@Composable
fun SearchBox(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text(hint) },
        leadingIcon = { Icon(Icons.Filled.Search, null, tint = Blue) },
        shape = RoundedCornerShape(24.dp),
        modifier = modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(24.dp))
    )
}

@Composable
fun KindIcon(kind: DocKind, size: Dp = 46.dp) {
    val color = when (kind) {
        DocKind.WORD -> Color(0xFF1E5CD6)
        DocKind.PDF -> Color(0xFFE53935)
        DocKind.TEXT -> Color(0xFF16A34A)
        DocKind.IMAGE -> Color(0xFF1E88E5)
    }
    Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(color), contentAlignment = Alignment.Center) {
        when (kind) {
            DocKind.WORD -> Text("W", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            DocKind.TEXT -> Text("T", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            DocKind.PDF -> Icon(Icons.Filled.PictureAsPdf, null, tint = Color.White)
            DocKind.IMAGE -> Icon(Icons.Filled.Image, null, tint = Color.White)
        }
    }
}

@Composable
fun DocRow(f: File, onOpen: () -> Unit, onChanged: () -> Unit, snippet: androidx.compose.ui.text.AnnotatedString? = null) {
    val ctx = LocalContext.current
    val kind = kindOf(f.name) ?: DocKind.TEXT
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    val marked = remember(menu) { Prefs.items(ctx, "bookmarks").contains(f.name) }
    Card(
        onClick = onOpen,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFDDE6F5))
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            KindIcon(kind)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(if (Prefs.showExt(ctx)) f.name else f.nameWithoutExtension, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF0A2A66), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = Blue)) { append(kind.en) }
                        append("  \u2022  ${fmtSize(f.length())}  \u2022  ${fmtDate(f.lastModified())}")
                    },
                    fontSize = 12.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (snippet != null) Text(snippet, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Open / کھولیں") }, onClick = { menu = false; onOpen() })
                    DropdownMenuItem(text = { Text("Share / شیئر کریں") }, onClick = { menu = false; Actions.share(ctx, f); onChanged() })
                    DropdownMenuItem(text = { Text("Print / پرنٹ کریں") }, onClick = { menu = false; Actions.print(ctx, f) })
                    DropdownMenuItem(text = { Text("Rename / نام بدلیں") }, onClick = { menu = false; rename = true })
                    if (kind == DocKind.PDF) DropdownMenuItem(
                        text = { Text(if (marked) "Remove bookmark" else "Bookmark / بک مارک") },
                        onClick = { menu = false; Prefs.toggle(ctx, "bookmarks", f.name); onChanged() }
                    )
                    DropdownMenuItem(text = { Text("Delete / حذف کریں", color = Color(0xFFD32F2F)) }, onClick = { menu = false; del = true })
                }
            }
        }
    }
    if (rename) {
        var nm by remember { mutableStateOf(f.nameWithoutExtension) }
        AlertDialog(
            onDismissRequest = { rename = false },
            title = { Text("Rename / نام تبدیل کریں") },
            text = { OutlinedTextField(value = nm, onValueChange = { nm = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val t = File(f.parentFile, nm.trim() + "." + f.extension)
                    if (nm.isNotBlank() && !t.exists()) f.renameTo(t)
                    rename = false; onChanged()
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { rename = false }) { Text("Cancel") } }
        )
    }
    if (del) AlertDialog(
        onDismissRequest = { del = false },
        title = { Text("Delete / حذف کریں") },
        text = { Text("${f.name}\n\nکیا آپ واقعی حذف کرنا چاہتے ہیں؟ / Delete this file?") },
        confirmButton = { TextButton(onClick = { f.delete(); del = false; onChanged() }) { Text("Delete", color = Color(0xFFD32F2F)) } },
        dismissButton = { TextButton(onClick = { del = false }) { Text("Cancel") } }
    )
}


/** Navigate to a top-level screen without stacking duplicates. */
fun goTo(nav: androidx.navigation.NavController, route: String) {
    nav.navigate(route) {
        popUpTo("home") { inclusive = false }
        launchSingleTop = true
    }
}

/** Common bottom bar used on every main screen: Home · My Documents · New · Print · Settings. */
@Composable
fun MainBar(nav: androidx.navigation.NavController, selected: Int) {
    BottomBar(
        listOf(
            Nav(Icons.Filled.Home, "Home") { if (selected != 0) goHome(nav) },
            Nav(Icons.Filled.Folder, "My Documents") { if (selected != 1) goTo(nav, "docs/browse") },
            Nav(Icons.Filled.Add, "New") { nav.navigate("new") },
            Nav(Icons.Filled.Print, "Print") { if (selected != 3) goTo(nav, "print") },
            Nav(Icons.Filled.Settings, "Settings") { if (selected != 4) goTo(nav, "settings") }
        ), selected, center = 2
    )
}

/** Filter chip with icon and a count bubble, as in the Search mock-up. */
@Composable
fun KindChip(label: String, count: Int, selected: Boolean, icon: ImageVector?, tint: Color, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(12.dp))
            .background(if (selected) Blue else Color.White)
            .border(1.dp, if (selected) Blue else Color(0xFFCFDCF2), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) Icon(icon, null, tint = if (selected) Color.White else tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = if (selected) Color.White else Color(0xFF0A2A66))
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.clip(CircleShape).background(if (selected) Color(0xFF3D86F0) else Color(0xFFE3EEFF)).padding(horizontal = 7.dp, vertical = 1.dp)
        ) { Text("$count", fontSize = 12.sp, color = if (selected) Color.White else Blue, fontWeight = FontWeight.Bold) }
    }
}
