@file:OptIn(ExperimentalMaterial3Api::class)

package com.msf.documentwriter

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class Hit(val f: File, val pre: String, val match: String, val post: String)

@Composable
fun SearchScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Hit>?>(null) }
    var fsel by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    val fr = remember { FocusRequester() }
    val kinds = listOf<DocKind?>(null, DocKind.WORD, DocKind.PDF, DocKind.TEXT, DocKind.IMAGE)

    fun run() {
        val query = q.trim()
        if (query.isEmpty()) { results = null; return }
        scope.launch {
            busy = true
            results = withContext(Dispatchers.IO) {
                Store.list(ctx).mapNotNull { f ->
                    val kd = kindOf(f.name)
                    val txt = if (kd == DocKind.WORD || kd == DocKind.TEXT) Store.plainText(f).replace('\n', ' ') else ""
                    val i = txt.indexOf(query, ignoreCase = true)
                    val nameHit = f.name.contains(query, ignoreCase = true)
                    when {
                        i >= 0 -> {
                            val st = maxOf(0, i - 25)
                            val en = minOf(txt.length, i + query.length + 45)
                            Hit(f, "… " + txt.substring(st, i), txt.substring(i, i + query.length), txt.substring(i + query.length, en) + " …")
                        }
                        nameHit -> Hit(f, txt.take(70), "", "")
                        else -> null
                    }
                }
            }
            busy = false
        }
    }
    LaunchedEffect(Unit) { try { fr.requestFocus() } catch (_: Exception) {} }
    LaunchedEffect(tick) { if (tick > 0) run() }

    val all = results ?: emptyList()
    val shown = all.filter { kinds[fsel] == null || kindOf(it.f.name) == kinds[fsel] }
    fun count(k: DocKind?) = if (k == null) all.size else all.count { kindOf(it.f.name) == k }
    val labels = listOf("All", "Word", "PDF", "Text", "Image")
    val chipColors = FilterChipDefaults.filterChipColors(selectedContainerColor = Blue, selectedLabelColor = Color.White)

    Scaffold(
        containerColor = Bg,
        topBar = { AppHeader("آسان طریقے سے اپنی دستاویزات تلاش کریں", onBack = { nav.popBackStack() }, onHome = { goHome(nav) }) },
        bottomBar = {
            BottomBar(
                listOf(
                    Nav(Icons.Filled.Home, "Home") { goHome(nav) },
                    Nav(Icons.Filled.Folder, "My Documents") { goTo(nav, "docs/browse") },
                    Nav(Icons.Filled.Search, "Search") { run() },
                    Nav(Icons.Filled.Print, "Print") { goTo(nav, "print") },
                    Nav(Icons.Filled.Settings, "Settings") { goTo(nav, "settings") }
                ), 2, center = 2
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Spacer(Modifier.height(2.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, singleLine = true, placeholder = { Text("Search documents...") },
                    leadingIcon = { Icon(Icons.Filled.Search, null, tint = Blue) },
                    trailingIcon = { if (q.isNotEmpty()) IconButton(onClick = { q = ""; results = null }) { Icon(Icons.Filled.Close, null) } },
                    shape = RoundedCornerShape(14.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { run() }),
                    modifier = Modifier.weight(1f).background(Color.White, RoundedCornerShape(14.dp)).focusRequester(fr)
                )
                Button(onClick = { run() }, shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue), modifier = Modifier.height(54.dp)) {
                    Icon(Icons.Filled.Search, null); Spacer(Modifier.width(4.dp)); Text("Search")
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val icons = listOf<ImageVector?>(Icons.Filled.Description, Icons.Filled.Description, Icons.Filled.PictureAsPdf, Icons.Filled.TextSnippet, Icons.Filled.Image)
                val tints = listOf(Blue, Color(0xFF1E5CD6), Color(0xFFE53935), Color(0xFF16A34A), Color(0xFF1E88E5))
                kinds.forEachIndexed { i, k ->
                    KindChip(labels[i], count(k), fsel == i, icons[i], tints[i]) { fsel = i }
                }
            }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFFDCEBFF)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Search, null, tint = Blue)
                Spacer(Modifier.width(8.dp))
                Text("Search Results", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color(0xFF0A2A66), modifier = Modifier.weight(1f))
                Text(if (busy) "Searching…" else "${shown.size} files found", fontSize = 13.sp)
            }
            LazyColumn(Modifier.weight(1f)) {
                if (results == null) item { Text("تلاش کے لیے نام یا متن لکھیں / Type a name or text to search", color = Color.Gray, modifier = Modifier.padding(16.dp)) }
                else if (shown.isEmpty() && !busy) item { Text("کوئی فائل نہیں ملی / No files found", color = Color.Gray, modifier = Modifier.padding(16.dp)) }
                items(shown, key = { it.f.absolutePath }) { h ->
                    val ann = if (h.pre.isEmpty() && h.match.isEmpty()) null else buildAnnotatedString {
                        append(h.pre)
                        withStyle(SpanStyle(background = Color(0xFFFFEB3B), fontWeight = FontWeight.Bold)) { append(h.match) }
                        append(h.post)
                    }
                    DocRow(h.f, onOpen = { openFile(nav, ctx, h.f) }, onChanged = { tick++ }, snippet = ann)
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}
