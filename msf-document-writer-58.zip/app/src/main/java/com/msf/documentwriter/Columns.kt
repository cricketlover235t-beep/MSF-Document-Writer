package com.msf.documentwriter

import android.view.MotionEvent
import kotlin.math.floor

/**
 * Text columns in the page editor.
 *
 * The EditText keeps ONE tall column of text ([colW] wide). This map cuts that column into pieces ("chunks", one per
 * page column) and says where every piece is shown on the page sheets: chunk i = page i / [n], column i % [n]
 * (the first column is on the right for right-to-left documents). The editor draws each piece at its place and maps
 * touches / the caret back, so typing, selecting and scrolling behave as in one long column.
 *
 * [tops] / [bots] = vertical range of every chunk inside the text layout; an empty chunk has top == bot.
 */
class ColumnMap(
    val n: Int, val colW: Float, val gap: Float, val left: Float, val top: Float,
    val pageH: Int, val pageGap: Int, val rtl: Boolean,
    val tops: IntArray, val bots: IntArray
) {
    val count: Int get() = tops.size

    /** Screen x (in the sheet) of the left edge of chunk [i]. */
    fun x(i: Int): Float {
        val k = i % n
        val vk = if (rtl) n - 1 - k else k
        return left + vk * (colW + gap)
    }

    /** Screen y of the top of chunk [i]. */
    fun y(i: Int): Float = (i / n) * (pageH + pageGap) + top

    /** The chunk that holds layout height [ly]. */
    fun chunkAt(ly: Float): Int {
        var r = 0
        for (i in 0 until count) if (tops[i] <= ly) r = i
        return r
    }

    /** Rewrites a touch (view coordinates on the page) into the coordinates the text layout expects. */
    fun mapTouch(m: MotionEvent, padLeft: Int, padTop: Int) {
        val px = m.x
        val py = m.y
        val page = floor(py / (pageH + pageGap)).toInt().coerceAtLeast(0)
        val vk = floor((px - left + gap / 2f) / (colW + gap)).toInt().coerceIn(0, n - 1)
        val k = if (rtl) n - 1 - vk else vk
        var i = page * n + k
        if (i >= count) i = count - 1
        if (i < 0) i = 0
        val hi = maxOf(bots[i] - 1, tops[i]).toFloat()
        val ly = (py - y(i) + tops[i]).coerceIn(tops[i].toFloat(), hi)
        val lx = (px - x(i)).coerceIn(0f, colW)
        m.setLocation(lx + padLeft, ly + padTop)
    }
}
