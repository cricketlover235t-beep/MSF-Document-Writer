package com.msf.documentwriter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/**
 * Runs heavy work (saving PDF / Word, copying files) OFF the main thread so the app never freezes.
 * While it runs, App() shows a small "please wait" dialog (see [Work.label]).
 */
object Work {
    private val h = Handler(Looper.getMainLooper())
    var label by mutableStateOf<String?>(null)

    fun <T> run(msg: String, work: () -> T?, done: (T?) -> Unit) {
        if (label != null) return            // one job at a time: ignore double taps
        label = msg
        Thread(null, {
            val r = try { work() } catch (_: Throwable) { null }
            h.post {
                label = null
                try { done(r) } catch (_: Throwable) {}
            }
        }, "msf-work", 16L * 1024 * 1024).start()
    }
}

/** Files / text that arrive from other apps (Share → MSF Document Writer, or "Open with" from a File Manager). */
object Incoming {
    var pending by mutableStateOf<File?>(null)
    var text by mutableStateOf<String?>(null)

    @Suppress("DEPRECATION")
    private fun streamOf(i: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else i.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri

    @Suppress("DEPRECATION")
    fun handle(c: Context, i: Intent?) {
        if (i == null) return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> streamOf(i)
            Intent.ACTION_SEND_MULTIPLE -> try {
                i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.firstOrNull()
            } catch (_: Throwable) { null }
            else -> null
        }
        val txt = if (i.action == Intent.ACTION_SEND && uri == null) i.getStringExtra(Intent.EXTRA_TEXT) else null
        if (uri == null && txt.isNullOrEmpty()) return
        i.action = Intent.ACTION_MAIN        // handle each incoming intent only once
        if (uri == null) { text = txt; return }
        val app = c.applicationContext
        Work.run("فائل کھل رہی ہے… / Opening file…", { Store.importUri(app, uri) }) { f ->
            if (f == null) toast(app, "یہ فائل سپورٹڈ نہیں / This file type is not supported")
            else pending = f
        }
    }
}

/** "Open from File Manager": pick any file with the phone's file manager and open it directly. */
@androidx.compose.runtime.Composable
fun rememberOpenFromManager(): () -> Unit {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val l = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { u ->
        if (u != null) {
            val app = ctx.applicationContext
            Work.run("فائل کھل رہی ہے… / Opening file…", { Store.importUri(app, u) }) { f ->
                if (f == null) toast(app, "یہ فائل سپورٹڈ نہیں / This file type is not supported") else Incoming.pending = f
            }
        }
    }
    return { try { l.launch(arrayOf("*/*")) } catch (_: Throwable) { toast(ctx, "فائل مینیجر نہیں ملا / No file manager found") } }
}
