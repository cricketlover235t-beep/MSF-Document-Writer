package com.msf.documentwriter

import android.text.Editable
import android.text.Spanned
import android.text.style.ParagraphStyle

/**
 * Tables are stored in the text as lines of the form  |cell|cell|cell|
 * An optional line like  |---|---|  right after the first row marks it as a header row.
 * On export (PDF / Word / image) these lines become real tables.
 */
sealed class Block
class TextBlock(val a: Int, val b: Int) : Block()
/** rows -> cells -> (start, end) offsets in the full text (spaces already trimmed). */
class TableBlock(val rows: List<List<Pair<Int, Int>>>, val header: Boolean) : Block()

object Tables {
    fun isRow(line: String): Boolean {
        val t = line.trim()
        return t.length >= 2 && t.startsWith("|") && t.endsWith("|")
    }

    /** Same test as [isRow] for the range [a, b) of [s], without copying the line (used on every keystroke over the whole text). */
    fun isRowRange(s: CharSequence, a0: Int, b0: Int): Boolean {
        var a = a0.coerceAtLeast(0)
        var b = b0.coerceAtMost(s.length)
        while (a < b && s[a].isWhitespace()) a++
        while (b > a && s[b - 1].isWhitespace()) b--
        return b - a >= 2 && s[a] == '|' && s[b - 1] == '|'
    }

    fun isSeparator(line: String): Boolean {
        val t = line.trim()
        return isRow(t) && t.contains('-') && t.all { it == '|' || it == '-' || it == ':' || it == ' ' }
    }

    /** Cell ranges of the line s[ps, pe). */
    private fun cells(s: String, ps: Int, pe: Int): List<Pair<Int, Int>> {
        val first = s.indexOf('|', ps)
        val last = s.lastIndexOf('|', pe - 1)
        val out = ArrayList<Pair<Int, Int>>()
        if (first < 0 || last <= first) return out
        var p = first
        while (p < last) {
            val q = s.indexOf('|', p + 1)
            var a = p + 1
            var b = q
            while (a < b && s[a] == ' ') a++
            while (b > a && s[b - 1] == ' ') b--
            out.add(Pair(a, b))
            p = q
        }
        return out
    }

    /** Splits s[from, to) into plain-text blocks and table blocks. */
    fun split(s: String, from: Int, to: Int): List<Block> {
        val out = ArrayList<Block>()
        var textStart = from
        var ps = from
        var rows = ArrayList<List<Pair<Int, Int>>>()
        var header = false
        var inTable = false
        while (ps <= to) {
            val nl = s.indexOf('\n', ps)
            val pe = if (nl < 0 || nl > to) to else nl
            val line = s.substring(ps, pe)
            if (isRow(line)) {
                if (!inTable) {
                    inTable = true
                    val b = if (ps > textStart && s[ps - 1] == '\n') ps - 1 else ps
                    if (b > textStart) out.add(TextBlock(textStart, b))
                }
                if (isSeparator(line)) { if (rows.size == 1) header = true } else rows.add(cells(s, ps, pe))
            } else if (inTable) {
                if (rows.isNotEmpty()) out.add(TableBlock(rows, header))
                rows = ArrayList(); header = false; inTable = false
                textStart = ps
            }
            if (pe >= to) break
            ps = pe + 1
        }
        if (inTable) {
            if (rows.isNotEmpty()) out.add(TableBlock(rows, header))
        } else if (textStart < to) out.add(TextBlock(textStart, to))
        return out
    }

    fun any(s: String): Boolean = split(s, 0, s.length).any { it is TableBlock }

    /** Inserts a new empty table at [pos] with the colour style [style] (0-7, see [TableStyles]); returns the new cursor position. */
    fun insert(e: Editable, pos: Int, rows: Int, cols: Int, header: Boolean, style: Int): Int = TableGuard.free {
        val p = PageBreaks.outOfTable(e, pos.coerceIn(0, e.length))
        val start = p + (if (p > 0 && e[p - 1] != '\n') 1 else 0)
        val np = PageBreaks.insertBlock(e, p, template(rows, cols, header), 2)
        if (style > 0) {
            val end = (start + 2 + 4 * cols).coerceAtMost(e.length)
            if (end > start) e.setSpan(TableStyleSpan(style), start, end, Spanned.SPAN_PARAGRAPH)
            PageBreaks.decorate(e)
        }
        np
    }

    /** Text lines for a new empty table. */
    fun template(rows: Int, cols: Int, header: Boolean): String {
        val row = "|" + "   |".repeat(cols)
        val sep = "|" + "---|".repeat(cols)
        val sb = StringBuilder()
        for (r in 0 until rows) {
            sb.append(row).append('\n')
            if (r == 0 && header) sb.append(sep).append('\n')
        }
        return sb.toString()
    }
}

/** Column widths of a table as fractions of the table width (sum = 1), set by dragging a column border. Covers the whole table. */
class TableWidthSpan(val fr: FloatArray) : ParagraphStyle

/** Extra height (dp) of one table row, set by dragging a row border. Covers the row's line. */
class RowHeightSpan(val dp: Float, val density: Float) : android.text.style.LineHeightSpan {
    override fun chooseHeight(text: CharSequence, start: Int, end: Int, spanstartv: Int, lineHeight: Int, fm: android.graphics.Paint.FontMetricsInt) {
        val sp = text as? Spanned ?: return
        if (end < sp.getSpanEnd(this)) return
        val extra = Math.round(dp * android.content.res.Resources.getSystem().displayMetrics.density)
        fm.descent += extra
        fm.bottom += extra
    }
}

object TableWidths {
    /** Column fractions stored for the table whose text lies in [a, b), or null (equal columns). */
    fun at(t: CharSequence, a: Int, b: Int, cols: Int): FloatArray? {
        if (t !is Spanned) return null
        val hi = b.coerceIn(0, t.length)
        val lo = a.coerceIn(0, hi)
        for (sp in t.getSpans(lo, maxOf(hi, lo), TableWidthSpan::class.java)) {
            if (sp.fr.size == cols && t.getSpanEnd(sp) > lo) return sp.fr
        }
        return null
    }

    fun of(t: CharSequence, tb: TableBlock, cols: Int): FloatArray? {
        val c0 = tb.rows.firstOrNull()?.firstOrNull()?.first ?: return null
        val c1 = tb.rows.lastOrNull()?.lastOrNull()?.second ?: c0
        var ps = c0.coerceIn(0, t.length)
        while (ps > 0 && t[ps - 1] != '\n') ps--
        return at(t, ps, c1, cols)
    }

    /** Fractions (summing to 1) -> widths in twips of [total]; the last column takes the rounding rest. */
    fun twips(fr: FloatArray?, cols: Int, total: Int): IntArray {
        val out = IntArray(cols)
        var used = 0
        for (i in 0 until cols) {
            val f = if (fr != null && fr.size == cols) fr[i] else 1f / cols
            out[i] = if (i == cols - 1) total - used else Math.round(f * total)
            used += out[i]
        }
        return out
    }

    fun normalize(w: FloatArray): FloatArray {
        val sum = w.sum()
        return if (sum <= 0f) FloatArray(w.size) { 1f / w.size } else FloatArray(w.size) { w[it] / sum }
    }
}

object RowHeights {
    /** Extra height (dp) of the row whose line contains [ps]. */
    fun at(t: CharSequence, ps: Int): Float {
        if (t !is Spanned) return 0f
        for (sp in t.getSpans(ps, ps, RowHeightSpan::class.java)) {
            if (t.getSpanStart(sp) <= ps && t.getSpanEnd(sp) > ps) return sp.dp
        }
        return 0f
    }

    fun of(t: CharSequence, row: List<Pair<Int, Int>>): Float {
        val c0 = row.firstOrNull()?.first ?: return 0f
        var ps = c0.coerceIn(0, t.length)
        while (ps > 0 && t[ps - 1] != '\n') ps--
        return at(t, ps)
    }
}

/** Background colour of ONE table row (read from the shading of a Word table). Not visible text. */
class RowFillSpan(val color: Int) : ParagraphStyle

object RowFills {
    /** Colour of the row whose line contains [ps], or 0 when the row has no colour of its own. */
    fun at(t: CharSequence, ps: Int): Int {
        if (t !is Spanned) return 0
        for (sp in t.getSpans(ps, ps, RowFillSpan::class.java)) {
            if (t.getSpanStart(sp) <= ps && t.getSpanEnd(sp) > ps) return sp.color
        }
        return 0
    }

    fun of(t: CharSequence, row: List<Pair<Int, Int>>): Int {
        val c0 = row.firstOrNull()?.first ?: return 0
        var ps = c0.coerceIn(0, t.length)
        while (ps > 0 && t[ps - 1] != '\n') ps--
        return at(t, ps)
    }
}

/** Marks the first row of a table with its colour style (0 = plain). Not visible text. */
class TableStyleSpan(val id: Int) : ParagraphStyle

/** The eight table styles of the table picker: banded rows, the first row is the darker colour. */
object TableStyles {
    private fun c(v: Long): Int = v.toInt()
    val DARK = intArrayOf(c(0xFFFFFFFF), c(0xFF808080), c(0xFFA4BDE0), c(0xFFDDA5A5), c(0xFFCCDDAA), c(0xFFBFB2D6), c(0xFFA3D3E0), c(0xFFF9C99E))
    val LIGHT = intArrayOf(c(0xFFFFFFFF), c(0xFFBFBFBF), c(0xFFD3DFF0), c(0xFFEFD3D6), c(0xFFE6EED8), c(0xFFDFD9EB), c(0xFFD0E8EF), c(0xFFFDE3D3))

    /** Ids with this flag are "custom" styles of Word files: the header row has the RGB in the low 24 bits, body rows are white. */
    const val CUSTOM = 0x01000000

    /** Background colour of body/header row number [row] (0 = first row). */
    fun fill(style: Int, row: Int): Int {
        if ((style and CUSTOM) != 0) return if (row == 0) (0xFF000000.toInt() or (style and 0xFFFFFF)) else 0xFFFFFFFF.toInt()
        val s = style.coerceIn(0, DARK.size - 1)
        return if (row % 2 == 0) DARK[s] else LIGHT[s]
    }

    fun hex(color: Int): String = String.format("%06X", color and 0xFFFFFF)

    /** Style whose dark colour is [h] (RRGGBB), or 0. */
    fun fromHex(h: String): Int {
        for (i in 1 until DARK.size) if (hex(DARK[i]).equals(h, ignoreCase = true)) return i
        val v = if (h.length == 6) h.toIntOrNull(16) else null
        if (v != null && v != 0xFFFFFF) return CUSTOM or v
        return 0
    }

    /** Style of the table whose first row starts at [ps]. */
    fun at(t: CharSequence, ps: Int): Int {
        if (t !is Spanned) return 0
        for (sp in t.getSpans(ps, ps, TableStyleSpan::class.java)) {
            if (t.getSpanStart(sp) <= ps && t.getSpanEnd(sp) > ps) return if ((sp.id and CUSTOM) != 0) sp.id else sp.id.coerceIn(0, DARK.size - 1)
        }
        return 0
    }

    fun of(t: CharSequence, tb: TableBlock): Int {
        val c0 = tb.rows.firstOrNull()?.firstOrNull()?.first ?: return 0
        var ps = c0.coerceIn(0, t.length)
        while (ps > 0 && t[ps - 1] != '\n') ps--
        return at(t, ps)
    }
}

/** Colours the table lines in the editor according to the table style. */
class TableDeco(private val e: Editable) {
    private var inTable = false
    private var row = 0
    private var style = 0

    fun line(ps: Int, pe: Int, line: String) {
        if (pe > ps && Tables.isRow(line)) {
            if (!inTable) { inTable = true; row = 0; style = TableStyles.at(e, ps) }
            val rule = if (style == 0) 0xFF444444.toInt() else 0xFF555555.toInt()
            val rf = RowFills.at(e, ps)
            if (Tables.isSeparator(line)) {
                e.setSpan(TableRowSpan(if (rf != 0) rf else TableStyles.fill(style, 0), rule), ps, pe, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else {
                e.setSpan(TableRowSpan(if (rf != 0) rf else TableStyles.fill(style, row), rule), ps, pe, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                row++
            }
        } else inTable = false
    }
}
