package com.msf.documentwriter

import android.graphics.Typeface
import android.text.Editable
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.AlignmentSpan
import android.text.style.BackgroundColorSpan
import android.text.style.CharacterStyle
import android.text.style.MetricAffectingSpan
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import android.widget.EditText
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.roundToInt

/** Superscript ([up] = true, like x²) or subscript (x₂): smaller text raised or lowered. Written to Word as w:vertAlign. */
class ScriptSpan(val up: Boolean) : MetricAffectingSpan() {
    override fun updateDrawState(tp: TextPaint) { shift(tp) }
    override fun updateMeasureState(tp: TextPaint) { shift(tp) }
    private fun shift(tp: TextPaint) {
        val a = tp.ascent()
        val d = (a / 2f).toInt()
        if (up) tp.baselineShift += d else tp.baselineShift -= d
        tp.textSize = tp.textSize * 0.65f
    }
}

/** Selection based formatting helpers for the editor's EditText. */
object Rich {
    fun range(et: EditText): Pair<Int, Int> {
        val str = et.text.toString()
        var s = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        var en = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        if (s == en) {
            s = str.lastIndexOf('\n', s - 1) + 1
            val nl = str.indexOf('\n', en)
            en = if (nl < 0) str.length else nl
        }
        return Pair(s, en)
    }

    private fun <T : Any> spans(e: Editable, s: Int, en: Int, cls: Class<T>): List<T> =
        e.getSpans(s, en, cls).filter { (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }

    private fun <T : Any> clear(e: Editable, s: Int, en: Int, cls: Class<T>, copy: (T) -> T, test: (T) -> Boolean = { true }) {
        for (sp in spans(e, s, en, cls)) {
            if (!test(sp)) continue
            val ss = e.getSpanStart(sp)
            val se = e.getSpanEnd(sp)
            val fl = e.getSpanFlags(sp)
            e.removeSpan(sp)
            if (ss < s) e.setSpan(copy(sp), ss, s, fl)
            if (se > en) e.setSpan(copy(sp), en, se, fl)
        }
    }

    private fun covered(e: Editable, s: Int, en: Int, list: List<Any>): Boolean {
        var pos = s
        val iv = list.map { Pair(maxOf(e.getSpanStart(it), s), minOf(e.getSpanEnd(it), en)) }.sortedBy { it.first }
        for ((a, b) in iv) {
            if (a > pos) return false
            if (b > pos) pos = b
            if (pos >= en) return true
        }
        return pos >= en
    }

    private fun toggleStyle(e: Editable, s: Int, en: Int, st: Int) {
        val has = covered(e, s, en, spans(e, s, en, StyleSpan::class.java).filter { it.style == st })
        clear(e, s, en, StyleSpan::class.java, { StyleSpan(it.style) }) { it.style == st }
        if (!has) e.setSpan(StyleSpan(st), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun bold(e: Editable, s: Int, en: Int) = toggleStyle(e, s, en, Typeface.BOLD)
    fun italic(e: Editable, s: Int, en: Int) = toggleStyle(e, s, en, Typeface.ITALIC)

    fun underline(e: Editable, s: Int, en: Int) {
        val has = covered(e, s, en, spans(e, s, en, UnderlineSpan::class.java))
        clear(e, s, en, UnderlineSpan::class.java, { UnderlineSpan() })
        if (!has) e.setSpan(UnderlineSpan(), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun strike(e: Editable, s: Int, en: Int) {
        val has = covered(e, s, en, spans(e, s, en, StrikethroughSpan::class.java))
        clear(e, s, en, StrikethroughSpan::class.java, { StrikethroughSpan() })
        if (!has) e.setSpan(StrikethroughSpan(), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    /** True when the whole range [s, en) is superscript ([up]) or subscript. */
    fun hasScript(e: Editable, s: Int, en: Int, up: Boolean): Boolean {
        val from = if (en > s) s else maxOf(s - 1, 0)
        val to = if (en > s) en else s
        if (to <= from) return false
        return covered(e, from, to, spans(e, from, to, ScriptSpan::class.java).filter { it.up == up })
    }

    /** Superscript / subscript toggle on the selection; the other kind is removed from it. */
    fun script(e: Editable, s: Int, en: Int, up: Boolean) {
        val has = covered(e, s, en, spans(e, s, en, ScriptSpan::class.java).filter { it.up == up })
        clear(e, s, en, ScriptSpan::class.java, { ScriptSpan(it.up) })
        if (!has) e.setSpan(ScriptSpan(up), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun pendingScript(e: Editable, pos: Int, up: Boolean) {
        val ex = pendingAt(e, pos, ScriptSpan::class.java)
        val same = ex.any { it.up == up }
        ex.forEach { e.removeSpan(it) }
        if (!same) e.setSpan(ScriptSpan(up), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun color(e: Editable, s: Int, en: Int, c: Int?) {
        clear(e, s, en, ForegroundColorSpan::class.java, { ForegroundColorSpan(it.foregroundColor) })
        if (c != null) e.setSpan(ForegroundColorSpan(c), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun highlight(e: Editable, s: Int, en: Int, c: Int?) {
        clear(e, s, en, BackgroundColorSpan::class.java, { BackgroundColorSpan(it.backgroundColor) })
        if (c != null) e.setSpan(BackgroundColorSpan(c), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun size(e: Editable, s: Int, en: Int, pt: Int) {
        clear(e, s, en, AbsoluteSizeSpan::class.java, { AbsoluteSizeSpan(it.size, it.dip) })
        e.setSpan(AbsoluteSizeSpan(pt, true), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    // ---- cursor without selection: formatting for the text typed next (zero-length spans that grow while typing) ----
    private fun <T : Any> pendingAt(e: Editable, pos: Int, cls: Class<T>): List<T> =
        e.getSpans(0, e.length, cls).filter { e.getSpanStart(it) == pos && e.getSpanEnd(it) == pos }

    private fun <T : Any> dropEmpty(e: Editable, cls: Class<T>) {
        for (sp in e.getSpans(0, e.length, cls)) if (e.getSpanStart(sp) == e.getSpanEnd(sp)) e.removeSpan(sp)
    }

    fun pendingStyle(e: Editable, pos: Int, st: Int) {
        val ex = pendingAt(e, pos, StyleSpan::class.java).filter { it.style == st }
        if (ex.isNotEmpty()) ex.forEach { e.removeSpan(it) }
        else e.setSpan(StyleSpan(st), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun pendingUnderline(e: Editable, pos: Int) {
        val ex = pendingAt(e, pos, UnderlineSpan::class.java)
        if (ex.isNotEmpty()) ex.forEach { e.removeSpan(it) }
        else e.setSpan(UnderlineSpan(), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun pendingStrike(e: Editable, pos: Int) {
        val ex = pendingAt(e, pos, StrikethroughSpan::class.java)
        if (ex.isNotEmpty()) ex.forEach { e.removeSpan(it) }
        else e.setSpan(StrikethroughSpan(), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun pendingColor(e: Editable, pos: Int, c: Int?) {
        dropEmpty(e, ForegroundColorSpan::class.java)
        if (c != null) e.setSpan(ForegroundColorSpan(c), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun pendingSize(e: Editable, pos: Int, pt: Int) {
        dropEmpty(e, AbsoluteSizeSpan::class.java)
        e.setSpan(AbsoluteSizeSpan(pt, true), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun pendingFont(e: Editable, pos: Int, family: String) {
        dropEmpty(e, TypefaceSpan::class.java)
        e.setSpan(FontSpan(family), pos, pos, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    fun font(e: Editable, s: Int, en: Int, family: String) {
        clear(e, s, en, TypefaceSpan::class.java, { FontSpan(it.family ?: "sans-serif") })
        e.setSpan(FontSpan(family), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun clearFormat(e: Editable, s: Int, en: Int) {
        clear(e, s, en, StyleSpan::class.java, { StyleSpan(it.style) })
        clear(e, s, en, UnderlineSpan::class.java, { UnderlineSpan() })
        clear(e, s, en, StrikethroughSpan::class.java, { StrikethroughSpan() })
        clear(e, s, en, ScriptSpan::class.java, { ScriptSpan(it.up) })
        clear(e, s, en, ForegroundColorSpan::class.java, { ForegroundColorSpan(it.foregroundColor) })
        clear(e, s, en, BackgroundColorSpan::class.java, { BackgroundColorSpan(it.backgroundColor) })
        clear(e, s, en, AbsoluteSizeSpan::class.java, { AbsoluteSizeSpan(it.size, it.dip) })
        clear(e, s, en, TypefaceSpan::class.java, { FontSpan(it.family ?: "sans-serif") })
    }

    /** Paragraph ranges (start, end-without-newline) touched by the selection/cursor. */
    fun paragraphs(et: EditText): List<Pair<Int, Int>> {
        val str = et.text.toString()
        val a = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val b = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        var ps = str.lastIndexOf('\n', a - 1) + 1
        val res = mutableListOf<Pair<Int, Int>>()
        while (true) {
            val nl = str.indexOf('\n', ps)
            val pe = if (nl < 0) str.length else nl
            res.add(Pair(ps, pe))
            if (nl < 0 || nl >= b) break
            ps = nl + 1
        }
        return res
    }

    /** mode: 0 left, 1 centre, 2 right (visual). */
    fun align(et: EditText, mode: Int) {
        val e = et.text
        for ((ps, pe) in paragraphs(et)) {
            val end = if (pe < e.length) pe + 1 else pe
            for (sp in e.getSpans(ps, end, AlignmentSpan.Standard::class.java)) e.removeSpan(sp)
            val lay = et.layout
            val dir = if (lay != null && e.isNotEmpty()) lay.getParagraphDirection(lay.getLineForOffset(minOf(ps, e.length))) else 1
            val ltr = dir == Layout.DIR_LEFT_TO_RIGHT
            val al = when (mode) {
                1 -> Layout.Alignment.ALIGN_CENTER
                2 -> if (ltr) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL
                else -> if (ltr) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_OPPOSITE
            }
            e.setSpan(AlignmentSpan.Standard(al), ps, end, Spanned.SPAN_PARAGRAPH)
        }
    }

    fun list(et: EditText, numbered: Boolean) {
        val e = et.text
        val ps = paragraphs(et)
        val bullet = Regex("^• ")
        val num = Regex("^\\d+\\. ")
        val rx = if (numbered) num else bullet
        val all = ps.all { (a, b) -> rx.containsMatchIn(e.subSequence(a, b)) }
        for (i in ps.indices.reversed()) {
            val (a, b) = ps[i]
            val line = e.subSequence(a, b).toString()
            val old = (bullet.find(line) ?: num.find(line))?.value
            if (all) {
                e.delete(a, a + (old?.length ?: 0))
            } else {
                if (old != null) e.delete(a, a + old.length)
                e.insert(a, if (numbered) "${i + 1}. " else "• ")
            }
        }
    }

    fun heading(et: EditText, level: Int) {
        val e = et.text
        for ((a, b) in paragraphs(et).reversed()) {
            if (b <= a) continue
            clear(e, a, b, AbsoluteSizeSpan::class.java, { AbsoluteSizeSpan(it.size, it.dip) })
            clear(e, a, b, StyleSpan::class.java, { StyleSpan(it.style) }) { it.style == Typeface.BOLD }
            if (level > 0) {
                e.setSpan(AbsoluteSizeSpan(if (level == 1) 28 else 22, true), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                e.setSpan(StyleSpan(Typeface.BOLD), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
    }
}

data class RichDoc(val text: SpannableStringBuilder, val size: Int, val rtl: Boolean, val justify: Boolean, val font: String?)

object RichDocx {
    private val DOT = RegexOption.DOT_MATCHES_ALL
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun unesc(s: String) =
        s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
    private fun rtlChar(ch: Char): Boolean {
        val d = Character.getDirectionality(ch)
        return d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
    }
    private fun hasRtl(s: String) = s.any { rtlChar(it) }
    private fun firstStrongRtl(s: String): Boolean {
        for (ch in s) {
            val d = Character.getDirectionality(ch)
            if (d == Character.DIRECTIONALITY_LEFT_TO_RIGHT) return false
            if (rtlChar(ch)) return true
        }
        return false
    }
    private fun hex(c: Int) = String.format("%06X", c and 0xFFFFFF)

    private fun paragraph(sp: Spanned, str: String, ps: Int, pe: Int, base: Int, docRtl: Boolean, justify: Boolean, font: String?, pbBefore: Boolean = false, boldAll: Boolean = false): String {
        val bidi = docRtl || firstStrongRtl(str.substring(ps, pe))
        val al = if (pe > ps) sp.getSpans(ps, pe, AlignmentSpan::class.java).firstOrNull()?.alignment else null
        val jc = when {
            al == Layout.Alignment.ALIGN_CENTER -> "<w:jc w:val=\"center\"/>"
            al == Layout.Alignment.ALIGN_OPPOSITE -> "<w:jc w:val=\"right\"/>"
            justify -> "<w:jc w:val=\"both\"/>"
            else -> ""
        }
        val ind = Para.find(sp, ps, ParaIndentSpan::class.java)
        val spc = Para.find(sp, ps, ParaSpaceSpan::class.java)
        var spAttr = ""
        if (spc != null) spAttr += " w:before=\"${(spc.beforePt * 20).roundToInt()}\" w:after=\"${(spc.afterPt * 20).roundToInt()}\""
        if (Doc.lineSpacing != 1f) spAttr += " w:line=\"${(240 * Doc.lineSpacing).roundToInt()}\" w:lineRule=\"auto\""
        val spXml = if (spAttr.isNotEmpty()) "<w:spacing$spAttr/>" else ""
        var indXml = ""
        if (ind != null) {
            val firstRel = ind.firstPt - ind.restPt
            val fl = if (firstRel >= 0f) " w:firstLine=\"${(firstRel * 20).roundToInt()}\"" else " w:hanging=\"${(-firstRel * 20).roundToInt()}\""
            indXml = "<w:ind w:left=\"${(ind.restPt * 20).roundToInt()}\"$fl/>"
        }
        val ppr = "<w:pPr>" + (if (pbBefore) "<w:pageBreakBefore/>" else "") + (if (bidi) "<w:bidi/>" else "") + spXml + indXml + jc + "</w:pPr>"
        if (pe <= ps) return "<w:p>$ppr</w:p>"
        val cuts = sortedSetOf(ps, pe)
        for (s in sp.getSpans(ps, pe, CharacterStyle::class.java)) {
            cuts.add(maxOf(ps, sp.getSpanStart(s)))
            cuts.add(minOf(pe, sp.getSpanEnd(s)))
        }
        val cl = cuts.toList()
        val runs = StringBuilder()
        for (i in 0 until cl.size - 1) {
            val a = cl[i]
            val b = cl[i + 1]
            if (b <= a) continue
            var bold = boldAll; var ital = false; var und = false; var strike = false; var vert = 0
            var color: Int? = null; var bg: Int? = null; var size = base; var fam = font; var shape: ShapeSpan? = null
            for (s in sp.getSpans(a, b, CharacterStyle::class.java)) {
                if ((sp.getSpanFlags(s) and Spanned.SPAN_COMPOSING) != 0) continue
                when (s) {
                    is StyleSpan -> { if ((s.style and Typeface.BOLD) != 0) bold = true; if ((s.style and Typeface.ITALIC) != 0) ital = true }
                    is UnderlineSpan -> und = true
                    is StrikethroughSpan -> strike = true
                    is ScriptSpan -> vert = if (s.up) 1 else 2
                    is ShapeSpan -> shape = s
                    is ForegroundColorSpan -> color = s.foregroundColor
                    is BackgroundColorSpan -> bg = s.backgroundColor
                    is AbsoluteSizeSpan -> size = s.size
                    is TypefaceSpan -> fam = s.family ?: fam
                    else -> {}
                }
            }
            val txt = str.substring(a, b)
            var rpr = ""
            if (fam != null) rpr += "<w:rFonts w:ascii=\"${esc(fam)}\" w:hAnsi=\"${esc(fam)}\" w:cs=\"${esc(fam)}\"/>"
            if (bold) rpr += "<w:b/><w:bCs/>"
            if (ital) rpr += "<w:i/><w:iCs/>"
            if (strike) rpr += "<w:strike/>"
            if (color != null) rpr += "<w:color w:val=\"${hex(color)}\"/>"
            rpr += "<w:sz w:val=\"${size * 2}\"/><w:szCs w:val=\"${size * 2}\"/>"
            if (und) rpr += "<w:u w:val=\"single\"/>"
            if (bg != null) rpr += "<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"${hex(bg)}\"/>"
            if (vert != 0) rpr += "<w:vertAlign w:val=\"${if (vert == 1) "superscript" else "subscript"}\"/>"
            if (bidi || hasRtl(txt)) rpr += "<w:rtl/>"
            val t = esc(txt).replace("\t", "</w:t><w:tab/><w:t xml:space=\"preserve\">").replace(PAGE_BREAK.toString(), "</w:t><w:br w:type=\"page\"/><w:t xml:space=\"preserve\">")
            val shp = shape
            if (shp != null && txt == "\uFFFC") runs.append("<w:r><w:rPr>$rpr</w:rPr>" + shapeDrawing(shp, size, color) + "</w:r>")
            else runs.append("<w:r><w:rPr>$rpr</w:rPr><w:t xml:space=\"preserve\">$t</w:t></w:r>")
        }
        return "<w:p>$ppr$runs</w:p>"
    }

    private var shapeSeq = 1000

    /** A drawn shape as a real Word shape (DrawingML preset geometry); descr carries our own marker so it is read back. */
    private fun shapeDrawing(sh: ShapeSpan, sizePt: Int, color: Int?): String {
        val cy = sizePt * 12700L
        val cx = (cy * ShapeArt.aspect(sh.id) * sh.wScale).toLong()
        val col = if (color != null) hex(color) else "000000"
        val open = ShapeArt.art(sh.id)?.open == true
        val fill = if (sh.fill && !open) "<a:solidFill><a:srgbClr val=\"$col\"/></a:solidFill>" else "<a:noFill/>"
        val ln = "<a:ln w=\"19050\"><a:solidFill><a:srgbClr val=\"$col\"/></a:solidFill>" +
            (if (ShapeArt.headArrow(sh.id)) "<a:headEnd type=\"triangle\"/>" else "") +
            (if (ShapeArt.tailArrow(sh.id)) "<a:tailEnd type=\"triangle\"/>" else "") + "</a:ln>"
        // the text written inside the shape (a real Word text box inside the shape)
        var tbx = ""
        if (sh.label.isNotEmpty()) {
            val tcol = hex(sh.labelColor ?: ShapeArt.autoText(color ?: 0xFF000000.toInt(), sh.fill && !open))
            val lpt = (sizePt * 0.3f).roundToInt().coerceIn(6, 48)
            val lf = sh.labelFont
            val rf = if (lf != null) "<w:rFonts w:ascii=\"${esc(lf)}\" w:hAnsi=\"${esc(lf)}\" w:cs=\"${esc(lf)}\"/>" else ""
            val paras = sh.label.split("\n").joinToString("") { ln1 ->
                "<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:rPr>$rf<w:color w:val=\"$tcol\"/><w:sz w:val=\"${lpt * 2}\"/><w:szCs w:val=\"${lpt * 2}\"/>" +
                    (if (hasRtl(ln1)) "<w:rtl/>" else "") + "</w:rPr><w:t xml:space=\"preserve\">${esc(ln1)}</w:t></w:r></w:p>"
            }
            tbx = "<wps:txbx><w:txbxContent>$paras</w:txbxContent></wps:txbx>"
        }
        val n = shapeSeq++
        return "<w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"$cx\" cy=\"$cy\"/>" +
            "<wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/><wp:docPr id=\"$n\" name=\"Shape $n\" descr=\"${sh.descr()}\"/><wp:cNvGraphicFramePr/>" +
            "<a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:cNvSpPr/>" +
            "<wps:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"${ShapeArt.prst(sh.id)}\"><a:avLst/></a:prstGeom>$fill$ln</wps:spPr>" +
            tbx + "<wps:bodyPr anchor=\"ctr\"><a:normAutofit/></wps:bodyPr></wps:wsp></a:graphicData></a:graphic></wp:inline></w:drawing>"
    }

    private fun table(sp: Spanned, str: String, tb: TableBlock, base: Int, docRtl: Boolean, justify: Boolean, font: String?, textW: Int): String {
        val cols = tb.rows.maxOf { it.size }.coerceAtLeast(1)
        val cwl = TableWidths.twips(TableWidths.of(sp, tb, cols), cols, textW)
        val b = "w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"000000\""
        val sb = StringBuilder()
        sb.append("<w:tbl><w:tblPr>")
        if (docRtl) sb.append("<w:bidiVisual/>")
        sb.append("<w:tblW w:w=\"${cwl.sum()}\" w:type=\"dxa\"/>")
        sb.append("<w:tblBorders><w:top $b/><w:left $b/><w:bottom $b/><w:right $b/><w:insideH $b/><w:insideV $b/></w:tblBorders>")
        sb.append("<w:tblLayout w:type=\"fixed\"/>")
        sb.append("<w:tblCellMar><w:left w:w=\"100\" w:type=\"dxa\"/><w:right w:w=\"100\" w:type=\"dxa\"/></w:tblCellMar>")
        sb.append("<w:tblLook w:val=\"04A0\" w:firstRow=\"${if (tb.header) 1 else 0}\" w:lastRow=\"0\" w:firstColumn=\"0\" w:lastColumn=\"0\" w:noHBand=\"0\" w:noVBand=\"1\"/>")
        val tLk = TableLocks.of(sp, tb)
        if (tLk.any) sb.append("<w:tblDescription w:val=\"MSFLOCK;r=${tLk.rows.sorted().joinToString(",")};c=${tLk.cols.sorted().joinToString(",")}\"/>")
        sb.append("</w:tblPr><w:tblGrid>")
        for (i in 0 until cols) sb.append("<w:gridCol w:w=\"${cwl[i]}\"/>")
        sb.append("</w:tblGrid>")
        val tStyle = TableStyles.of(sp, tb)
        for ((ri, row) in tb.rows.withIndex()) {
            val head = tb.header && ri == 0
            sb.append("<w:tr>")
            val extraDp = RowHeights.of(sp, row)
            if (extraDp > 0.5f) sb.append("<w:trPr><w:trHeight w:val=\"${(base * 1.4f * 20f + 80f + extraDp * 15f).toInt()}\" w:hRule=\"atLeast\"/></w:trPr>")
            for (ci in 0 until cols) {
                val cell = row.getOrNull(ci)
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"${cwl[ci]}\" w:type=\"dxa\"/>")
                val rf = RowFills.of(sp, row)
                val fillHex = if (rf != 0) TableStyles.hex(rf) else if (tStyle > 0) TableStyles.hex(TableStyles.fill(tStyle, ri)) else if (head) "E8EEF7" else null
                if (fillHex != null) sb.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"$fillHex\"/>")
                sb.append("</w:tcPr>")
                if (cell == null || cell.second <= cell.first) sb.append("<w:p/>")
                else sb.append(paragraph(sp, str, cell.first, cell.second, base, docRtl, justify, font, false, head))
                sb.append("</w:tc>")
            }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl>")
        return sb.toString()
    }

    fun write(
        f: File, t: CharSequence, base: Int, docRtl: Boolean, justify: Boolean, font: String?, paper: Int, land: Boolean,
        design: Int = 0, bg: ByteArray? = null, numbers: Boolean = false, mar: Mar? = null, border: Boolean = false, pn: PageNumCfg = PageNumCfg(),
        cols: Int = 1
    ) {
        val sp = SpannableStringBuilder(t)
        val str = sp.toString()
        val (w, h) = Paper.twips(paper, land)
        val spec = if (!land && bg != null) PageDesigns.spec(design) else null
        val marL = if (spec != null) (w * spec.mx).toInt() else (mar?.let { (it.l * 20f).toInt() } ?: 1440)
        val marR = if (spec != null) (w * spec.mx).toInt() else (mar?.let { (it.r * 20f).toInt() } ?: 1440)
        val marTop = if (spec != null) (h * spec.mt).toInt() else (mar?.let { (it.t * 20f).toInt() } ?: 1440)
        val marBottom = if (spec != null) (h * spec.mb).toInt() else (mar?.let { (it.b * 20f).toInt() } ?: 1440)
        val footerDist = if (spec != null) (marBottom - 480).coerceAtLeast(300) else (Doc.footerDist * 20f).roundToInt()

        val colSpace = 360
        val textColW = if (cols > 1) (w - marL - marR - (cols - 1) * colSpace) / cols else w - marL - marR
        val body = StringBuilder()
        var pbNext = false
        var lastWasTable = false
        for (blk in Tables.split(str, 0, str.length)) {
            if (blk is TableBlock) {
                if (pbNext) { body.append("<w:p><w:pPr><w:pageBreakBefore/></w:pPr></w:p>"); pbNext = false }
                body.append(table(sp, str, blk, base, docRtl, justify, font, textColW))
                lastWasTable = true
            } else if (blk is TextBlock) {
                var ps = blk.a
                while (true) {
                    val nl = str.indexOf('\n', ps)
                    val pe = if (nl < 0 || nl > blk.b) blk.b else nl
                    if (pe - ps == 1 && str[ps] == PAGE_BREAK) {
                        // a line that only holds the page-break marker: the next paragraph starts on a new page
                        pbNext = true
                    } else {
                        body.append(paragraph(sp, str, ps, pe, base, docRtl, justify, font, pbNext))
                        pbNext = false
                    }
                    if (pe >= blk.b) break
                    ps = pe + 1
                }
                lastWasTable = false
            }
        }
        if (lastWasTable || body.isEmpty()) body.append("<w:p/>")

        val pgBdr = if (border) "<w:pgBorders w:offsetFrom=\"page\">" + listOf("top","left","bottom","right").joinToString("") { "<w:$it w:val=\"single\" w:sz=\"6\" w:space=\"24\" w:color=\"000000\"/>" } + "</w:pgBorders>" else ""
        val pgMar = "<w:pgMar w:top=\"$marTop\" w:right=\"$marR\" w:bottom=\"$marBottom\" w:left=\"$marL\" w:header=\"${(Doc.headerDist * 20f).roundToInt()}\" w:footer=\"$footerDist\" w:gutter=\"0\"/>"
        val ns = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
            "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
            "xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\" " +
            "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
            "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\""
        val colsXml = if (cols > 1) "<w:cols w:num=\"$cols\" w:space=\"$colSpace\"/>" + (if (docRtl) "<w:bidi/>" else "") else ""
        val numInHeader = numbers && pn.loc == 0
        val numInFooter = numbers && pn.loc != 0
        val hdrText = if (spec == null) Doc.headerText else ""
        val hasHeader = spec != null || numInHeader || hdrText.isNotEmpty()
        val hdrRef = if (hasHeader) "<w:headerReference w:type=\"default\" r:id=\"rId1\"/>" else ""
        val ftrText = if (spec == null) Doc.footerText else ""
        val hasFooter = numInFooter || ftrText.isNotEmpty()
        val ftrRef = if (hasFooter) "<w:footerReference w:type=\"default\" r:id=\"rId2\"/>" else ""
        // "- 1 -" is written as a normal decimal number with a dash before and after it
        val dash = pn.fmt == PageNum.DASH || (border && pn.fmt == 0)
        val wFmt = if (pn.fmt == PageNum.DASH) "decimal" else PageNum.wordFmt[pn.fmt.coerceIn(0, PageNum.wordFmt.size - 1)]
        val pgNum = if (numbers) "<w:pgNumType w:fmt=\"$wFmt\" w:start=\"${pn.start}\"/>" else ""
        val jc = when (pn.align) { 0 -> "left"; 2 -> "right"; else -> "center" }
        val cached = if (dash) pn.start.toString() else PageNum.format(pn.start, pn.fmt)
        val numPara = "<w:p><w:pPr><w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/><w:jc w:val=\"$jc\"/></w:pPr>" +
            (if (dash) "<w:r><w:t xml:space=\"preserve\">- </w:t></w:r>" else "") +
            "<w:r><w:fldChar w:fldCharType=\"begin\"/></w:r>" +
            "<w:r><w:instrText xml:space=\"preserve\"> PAGE </w:instrText></w:r>" +
            "<w:r><w:fldChar w:fldCharType=\"separate\"/></w:r>" +
            "<w:r><w:t>$cached</w:t></w:r>" +
            "<w:r><w:fldChar w:fldCharType=\"end\"/></w:r>" +
            (if (dash) "<w:r><w:t xml:space=\"preserve\"> -</w:t></w:r>" else "") + "</w:p>"
        val bidiX = if (docRtl) "<w:bidi/>" else ""
        val hdrCol = String.format("%06X", Doc.headerColor and 0xFFFFFF)
        val hdrFam = Doc.headerFont?.takeIf { it.isNotBlank() }?.let { "<w:rFonts w:ascii=\"${esc(it)}\" w:hAnsi=\"${esc(it)}\" w:cs=\"${esc(it)}\"/>" } ?: ""
        val textRun = "<w:r><w:rPr>$hdrFam<w:color w:val=\"$hdrCol\"/><w:sz w:val=\"${(Doc.headerSize * 2).toInt()}\"/>" + (if (docRtl) "<w:rtl/>" else "") + "</w:rPr><w:t xml:space=\"preserve\">${esc(hdrText)} </w:t></w:r>"
        val hdrLine = if (hdrText.isNotEmpty() && Doc.headerLine) "<w:pBdr><w:bottom w:val=\"single\" w:sz=\"4\" w:space=\"1\" w:color=\"9A9A9A\"/></w:pBdr>" else ""
        val hdrJc = when (Doc.headerAlign) {
            0 -> if (docRtl) "right" else "left"
            1 -> "center"
            2 -> if (docRtl) "left" else "right"
            else -> ""
        }.let { if (it.isEmpty()) "" else "<w:jc w:val=\"$it\"/>" }
        val hdrPara = when {
            hdrText.isEmpty() -> numPara
            numInHeader -> numPara.replace("<w:pPr>", "<w:pPr>$hdrLine$bidiX").replace("</w:pPr>", "</w:pPr>$textRun")
            else -> "<w:p><w:pPr>$hdrLine$bidiX<w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/>$hdrJc</w:pPr>$textRun</w:p>"
        }
        val ftrCol = String.format("%06X", Doc.footerColor and 0xFFFFFF)
        val ftrFam = Doc.footerFont?.takeIf { it.isNotBlank() }?.let { "<w:rFonts w:ascii=\"${esc(it)}\" w:hAnsi=\"${esc(it)}\" w:cs=\"${esc(it)}\"/>" } ?: ""
        val ftrRun = "<w:r><w:rPr>$ftrFam<w:color w:val=\"$ftrCol\"/><w:sz w:val=\"${(Doc.footerSize * 2).toInt()}\"/>" + (if (docRtl) "<w:rtl/>" else "") + "</w:rPr><w:t xml:space=\"preserve\">${esc(ftrText)} </w:t></w:r>"
        val ftrLine = if (ftrText.isNotEmpty() && Doc.footerLine) "<w:pBdr><w:top w:val=\"single\" w:sz=\"4\" w:space=\"1\" w:color=\"9A9A9A\"/></w:pBdr>" else ""
        val ftrJc = when (Doc.footerAlign) {
            0 -> if (docRtl) "right" else "left"
            1 -> "center"
            2 -> if (docRtl) "left" else "right"
            else -> ""
        }.let { if (it.isEmpty()) "" else "<w:jc w:val=\"$it\"/>" }
        val ftrPara = when {
            ftrText.isEmpty() -> numPara
            numInFooter -> numPara.replace("<w:pPr>", "<w:pPr>$ftrLine$bidiX").replace("</w:pPr>", "</w:pPr>$ftrRun")
            else -> "<w:p><w:pPr>$ftrLine$bidiX<w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/>$ftrJc</w:pPr>$ftrRun</w:p>"
        }
        val doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document $ns><w:body>$body" +
            "<w:sectPr>$hdrRef$ftrRef<w:pgSz w:w=\"$w\" w:h=\"$h\"${if (land) " w:orient=\"landscape\"" else ""}/>$pgMar$pgBdr$pgNum$colsXml</w:sectPr></w:body></w:document>"
        val types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            (if (spec != null) "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" else "") +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            (if (hasHeader) "<Override PartName=\"/word/header1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml\"/>" else "") +
            (if (hasFooter) "<Override PartName=\"/word/footer1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml\"/>" else "") +
            "</Types>"
        val rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>"
        ZipOutputStream(FileOutputStream(f)).use { z ->
            fun put(name: String, text: String) { z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml", types)
            put("_rels/.rels", rels)
            put("word/document.xml", doc)
            if (hasHeader || hasFooter) {
                put("word/_rels/document.xml.rels",
                    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    (if (hasHeader) "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/header\" Target=\"header1.xml\"/>" else "") +
                    (if (hasFooter) "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer\" Target=\"footer1.xml\"/>" else "") +
                    "</Relationships>")
            }
            if (hasFooter) {
                put("word/footer1.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:ftr $ns>" + ftrPara + "</w:ftr>")
            }
            if ((numInHeader || hdrText.isNotEmpty()) && !(spec != null && bg != null)) {
                put("word/header1.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:hdr $ns>" + hdrPara + "</w:hdr>")
            }
            if (spec != null && bg != null) {
                val name = "page_design_${spec.id}.jpg"
                val emuW = w.toLong() * 635L
                val emuH = h.toLong() * 635L
                put("word/_rels/header1.xml.rels",
                    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/$name\"/></Relationships>")
                put("word/header1.xml",
                    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:hdr $ns>" +
                    "<w:p><w:pPr><w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/></w:pPr><w:r><w:drawing>" +
                    "<wp:anchor distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"0\" behindDoc=\"1\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\">" +
                    "<wp:simplePos x=\"0\" y=\"0\"/>" +
                    "<wp:positionH relativeFrom=\"page\"><wp:posOffset>0</wp:posOffset></wp:positionH>" +
                    "<wp:positionV relativeFrom=\"page\"><wp:posOffset>0</wp:posOffset></wp:positionV>" +
                    "<wp:extent cx=\"$emuW\" cy=\"$emuH\"/><wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/><wp:wrapNone/>" +
                    "<wp:docPr id=\"1\" name=\"PageDesign\"/><wp:cNvGraphicFramePr/>" +
                    "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:pic>" +
                    "<pic:nvPicPr><pic:cNvPr id=\"0\" name=\"$name\"/><pic:cNvPicPr/></pic:nvPicPr>" +
                    "<pic:blipFill><a:blip r:embed=\"rId1\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
                    "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$emuW\" cy=\"$emuH\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr>" +
                    "</pic:pic></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r></w:p>" + (if (numInHeader) numPara else "") + "</w:hdr>")
                z.putNextEntry(ZipEntry("word/media/$name")); z.write(bg); z.closeEntry()
            }
        }
    }

    /** Paper index + landscape flag of a .docx whose page size is one of ours, else null. */
    fun pageOf(f: File): Pair<Int, Boolean>? = try {
        java.util.zip.ZipFile(f).use { z ->
            val e = z.getEntry("word/document.xml") ?: return@use null
            val xml = z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
            val m = Regex("<w:pgSz [^>]*>").find(xml)?.value ?: return@use null
            val w = Regex("w:w=\"(\\d+)\"").find(m)?.groupValues?.get(1)?.toIntOrNull() ?: return@use null
            val h = Regex("w:h=\"(\\d+)\"").find(m)?.groupValues?.get(1)?.toIntOrNull() ?: return@use null
            Paper.fromTwips(w, h)
        }
    } catch (e: Throwable) { null }

    /** Column preset (1 Two, 2 Three) of a .docx that has 2 or 3 columns, else null. */
    fun colsOf(f: File): Int? = try {
        java.util.zip.ZipFile(f).use { z ->
            val e = z.getEntry("word/document.xml") ?: return@use null
            val xml = z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
            val m = Regex("<w:cols [^>]*>").find(xml)?.value ?: return@use null
            when (Regex("w:num=\"(\\d+)\"").find(m)?.groupValues?.get(1)?.toIntOrNull()) { 2 -> 1; 3 -> 2; else -> null }
        }
    } catch (e: Throwable) { null }

    /** True when a .docx written by this app has page numbers (a footer). */
    fun hasNumbers(f: File): Boolean = try {
        java.util.zip.ZipFile(f).use { z -> z.getEntry("word/footer1.xml") != null }
    } catch (e: Throwable) { false }

    /** Page-number settings of a .docx written by this app (null = no page numbers). */
    fun numbersOf(f: File): PageNumCfg? = try {
        java.util.zip.ZipFile(f).use { z ->
            fun text(name: String): String? = z.getEntry(name)?.let { e -> z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) } }
            val ftr = text("word/footer1.xml")
            val hdr = text("word/header1.xml")
            val inFooter = ftr != null && ftr.contains(" PAGE ")
            val inHeader = !inFooter && hdr != null && hdr.contains(" PAGE ")
            if (!inFooter && !inHeader) return@use null
            val part = (if (inFooter) ftr else hdr) ?: ""
            val align = when (Regex("<w:jc w:val=\"(\\w+)\"").find(part)?.groupValues?.get(1)) { "left", "start" -> 0; "right", "end" -> 2; else -> 1 }
            val doc = text("word/document.xml") ?: ""
            val pg = Regex("<w:pgNumType [^>]*>").find(doc)?.value ?: ""
            var fmt = PageNum.wordFmt.indexOf(Regex("w:fmt=\"(\\w+)\"").find(pg)?.groupValues?.get(1) ?: "decimal").coerceAtLeast(0)
            if (fmt == 0 && part.contains("> -</w:t>")) fmt = PageNum.DASH
            val start = Regex("w:start=\"(\\d+)\"").find(pg)?.groupValues?.get(1)?.toIntOrNull() ?: 1
            PageNumCfg(if (inFooter) 1 else 0, align, fmt, start.coerceAtLeast(1))
        }
    } catch (e: Throwable) { null }

    /** Margins (points) of a .docx when they differ from the classic 1 inch, else null. */
    fun marginsOf(f: File): Mar? = try {
        java.util.zip.ZipFile(f).use { z ->
            val e = z.getEntry("word/document.xml") ?: return@use null
            val xml = z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
            val m = Regex("<w:pgMar [^>]*>").find(xml)?.value ?: return@use null
            fun v(n: String): Float? = Regex("w:$n=\"(\\d+)\"").find(m)?.groupValues?.get(1)?.toFloatOrNull()?.div(20f)
            val mar = Mar(v("left") ?: return@use null, v("top") ?: return@use null, v("right") ?: return@use null, v("bottom") ?: return@use null)
            if (mar == Mar.all(72f)) null else mar
        }
    } catch (e: Throwable) { null }

    /** Page design stored in a .docx written by this app (0 when none). */
    fun designOf(f: File): Int = try {
        java.util.zip.ZipFile(f).use { z ->
            z.entries().asSequence().mapNotNull { Regex("word/media/page_design_(\\d+)\\.jpg").matchEntire(it.name)?.groupValues?.get(1)?.toIntOrNull() }.firstOrNull() ?: 0
        }
    } catch (e: Throwable) { 0 }

    private fun highlightColor(n: String): Int? = when (n.lowercase()) {
        "yellow" -> 0xFFFFFF00.toInt(); "green" -> 0xFF00FF00.toInt(); "cyan" -> 0xFF00FFFF.toInt()
        "magenta" -> 0xFFFF00FF.toInt(); "red" -> 0xFFFF0000.toInt(); "blue" -> 0xFF0000FF.toInt()
        "lightgray" -> 0xFFD3D3D3.toInt(); else -> null
    }

    /**
     * Collects the text and the spans of a document while it is read, and builds the SpannableStringBuilder ONCE at the end.
     * (Appending to a SpannableStringBuilder that already has many spans is very slow - every append walks all spans -
     * which made big Word files "load" for minutes.)
     */
    private class SpanBuf {
        private class R(val w: Any, val s: Int, var e: Int, val f: Int)
        private val sb = StringBuilder()
        private val rs = ArrayList<R>()
        val length: Int get() = sb.length
        fun isNotEmpty() = sb.isNotEmpty()
        operator fun get(i: Int): Char = sb[i]
        fun append(x: String): SpanBuf { sb.append(x); return this }
        fun append(c: Char): SpanBuf { sb.append(c); return this }
        private val lastByKey = HashMap<String, R>()
        private fun keyOf(w: Any): String? = when (w) {
            is StyleSpan -> "S" + w.style
            is ForegroundColorSpan -> "F" + w.foregroundColor
            is BackgroundColorSpan -> "B" + w.backgroundColor
            is AbsoluteSizeSpan -> "Z" + w.size + "," + w.dip
            is FontSpan -> "N" + w.family
            is UnderlineSpan -> "U"
            is StrikethroughSpan -> "X"
            is ScriptSpan -> "V" + w.up
            else -> null
        }
        /** Character styles that touch (or only a line break / space apart) are merged into ONE span: far fewer spans to build. */
        fun setSpan(w: Any, s: Int, e: Int, f: Int) {
            val k = keyOf(w)
            if (k != null) {
                val prev = lastByKey[k]
                if (prev != null && prev.f == f && s >= prev.e && s - prev.e <= 2 && e <= sb.length) {
                    var gapOk = true
                    for (i in prev.e until s) { val c = sb[i]; if (c != '\n' && c != ' ' && c != '\t') { gapOk = false; break } }
                    if (gapOk) { prev.e = e; return }
                }
                val r = R(w, s, e, f)
                lastByKey[k] = r
                rs.add(r)
                return
            }
            rs.add(R(w, s, e, f))
        }
        fun dropLast(c: Char) { if (sb.isNotEmpty() && sb[sb.length - 1] == c) sb.setLength(sb.length - 1) }
        fun truncate(n: Int) { if (n in 0 until sb.length) sb.setLength(n) }
        fun slice(a: Int, b: Int): String = sb.substring(a.coerceIn(0, sb.length), b.coerceIn(0, sb.length))
        override fun toString(): String = sb.toString()
        fun build(): SpannableStringBuilder {
            val b = SpannableStringBuilder(sb)
            var n = 0
            Work.progress("اسپین بنا رہا ہے… 0 / " + rs.size + " (spans)")
            for (r in rs) {
                val st = r.s.coerceIn(0, b.length); val en = r.e.coerceIn(st, b.length)
                try { b.setSpan(r.w, st, en, r.f) } catch (_: Throwable) {}
                if ((++n % 20000) == 0) Work.progress("اسپین بنا رہا ہے… " + n + " / " + rs.size + " (spans)")
            }
            return b
        }
    }

    /** Reading may be given a time limit: past it, every loop and every regex step throws a TimeoutException. */
    class Limit(val deadline: Long) { @Volatile var cancel = false }
    /** Set only on the thread that reads with a time limit; every other caller is unaffected. */
    val limit = ThreadLocal<Limit?>()
    @Volatile var progress: ((Int) -> Unit)? = null
    fun guard() {
        val l = limit.get() ?: return
        if (l.cancel || System.nanoTime() > l.deadline) throw java.util.concurrent.TimeoutException("slow")
    }

    /** CharSequence that checks the time limit while a regex is walking over it. */
    private class TimedSeq(private val s: String) : CharSequence {
        private var n = 0
        override val length: Int get() = s.length
        override fun get(index: Int): Char { if ((++n and 0x3FFF) == 0) guard(); return s[index] }
        override fun subSequence(startIndex: Int, endIndex: Int): CharSequence = s.substring(startIndex, endIndex)
        override fun toString(): String = s
    }

    // ───────── fast streaming reader (XmlPullParser): reads the WHOLE document in a few seconds, however long it is ─────────
    private class RP {
        var bold: Boolean? = null; var ital: Boolean? = null; var und: Boolean? = null; var strike: Boolean? = null
        var color: Int? = null; var sz: Int? = null; var szCs: Int? = null
        var fAscii: String? = null; var fCs: String? = null
        var hl: Int? = null; var fill: Int? = null; var vert: Int? = null
        var rStyle: String? = null
        fun over(o: RP) {
            o.bold?.let { bold = it }; o.ital?.let { ital = it }; o.und?.let { und = it }; o.strike?.let { strike = it }
            o.color?.let { color = it }; o.sz?.let { sz = it }; o.szCs?.let { szCs = it }
            o.fAscii?.let { fAscii = it }; o.fCs?.let { fCs = it }
            o.hl?.let { hl = it }; o.fill?.let { fill = it }; o.vert?.let { vert = it }
        }
        fun copy(): RP { val r = RP(); r.over(this); return r }
    }

    private class PP {
        var jc: String? = null; var left: Float? = null; var first: Float? = null; var hang: Float? = null
        var before: Float? = null; var after: Float? = null; var bidi: Boolean? = null
        var pStyle: String? = null; var pageBreak = false
        var numId: String? = null; var ilvl: Int? = null
        fun over(o: PP) {
            o.numId?.let { numId = it }; o.ilvl?.let { ilvl = it }
            o.jc?.let { jc = it }; o.left?.let { left = it }
            if (o.first != null || o.hang != null) { first = o.first; hang = o.hang }
            o.before?.let { before = it }; o.after?.let { after = it }; o.bidi?.let { bidi = it }
        }
        fun copy(): PP { val r = PP(); r.over(this); return r }
    }

    private class St { var basedOn: String? = null; val rp = RP(); val pp = PP() }
    private class Styles { val map = HashMap<String, St>(); val defRp = RP(); val defPp = PP(); var defPara: String? = null }

    private fun av(p: XmlPullParser, n: String): String? = p.getAttributeValue(null, n)
    private fun onOff(p: XmlPullParser): Boolean { val v = av(p, "w:val"); return v == null || v == "1" || v == "true" || v == "on" }
    private fun hexColor(s: String?): Int? = if (s != null && s.length == 6) s.toIntOrNull(16)?.let { 0xFF000000.toInt() or it } else null
    private fun twipsPt(s: String?): Float? = s?.toFloatOrNull()?.div(20f)

    /** Called at a START_TAG: moves the parser to the matching END_TAG. */
    private fun skipTree(p: XmlPullParser) {
        val d = p.depth
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT || (ev == XmlPullParser.END_TAG && p.depth == d)) return
        }
    }

    /** Called at the START_TAG of w:rPr: reads the run properties and stops at its END_TAG. */
    private fun readRp(p: XmlPullParser, rp: RP) {
        val d = p.depth
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT || (ev == XmlPullParser.END_TAG && p.depth == d)) return
            if (ev != XmlPullParser.START_TAG) continue
            when (p.name) {
                "w:b" -> rp.bold = onOff(p)
                "w:i" -> rp.ital = onOff(p)
                "w:u" -> rp.und = av(p, "w:val") != "none"
                "w:strike" -> rp.strike = onOff(p)
                "w:color" -> { hexColor(av(p, "w:val"))?.let { rp.color = it } }
                "w:sz" -> { av(p, "w:val")?.toIntOrNull()?.let { rp.sz = it } }
                "w:szCs" -> { av(p, "w:val")?.toIntOrNull()?.let { rp.szCs = it } }
                "w:rFonts" -> { av(p, "w:ascii")?.let { rp.fAscii = it }; av(p, "w:cs")?.let { rp.fCs = it } }
                "w:vertAlign" -> rp.vert = when (av(p, "w:val")) { "superscript" -> 1; "subscript" -> 2; else -> 0 }
                "w:highlight" -> { highlightColor(av(p, "w:val") ?: "")?.let { rp.hl = it } }
                "w:shd" -> { val f = av(p, "w:fill"); if (f != null && !f.equals("FFFFFF", true)) hexColor(f)?.let { rp.fill = it } }
                "w:rStyle" -> rp.rStyle = av(p, "w:val")
                "w:rPrChange" -> skipTree(p)
            }
        }
    }

    /** Called at the START_TAG of w:pPr: reads the paragraph properties and stops at its END_TAG. */
    private fun readPp(p: XmlPullParser, pp: PP) {
        val d = p.depth
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT || (ev == XmlPullParser.END_TAG && p.depth == d)) return
            if (ev != XmlPullParser.START_TAG) continue
            when (p.name) {
                "w:jc" -> pp.jc = av(p, "w:val")
                "w:ind" -> {
                    twipsPt(av(p, "w:left") ?: av(p, "w:start"))?.let { pp.left = it }
                    twipsPt(av(p, "w:firstLine"))?.let { pp.first = it }
                    twipsPt(av(p, "w:hanging"))?.let { pp.hang = it }
                }
                "w:spacing" -> {
                    twipsPt(av(p, "w:before"))?.let { pp.before = it }
                    twipsPt(av(p, "w:after"))?.let { pp.after = it }
                }
                "w:bidi" -> pp.bidi = onOff(p)
                "w:pStyle" -> pp.pStyle = av(p, "w:val")
                "w:pageBreakBefore" -> pp.pageBreak = onOff(p)
                "w:numPr" -> {
                    val d2 = p.depth
                    while (true) {
                        val e2 = p.next()
                        if (e2 == XmlPullParser.END_DOCUMENT || (e2 == XmlPullParser.END_TAG && p.depth == d2)) break
                        if (e2 == XmlPullParser.START_TAG) {
                            if (p.name == "w:ilvl") pp.ilvl = av(p, "w:val")?.toIntOrNull()
                            else if (p.name == "w:numId") pp.numId = av(p, "w:val")
                        }
                    }
                }
                "w:rPr", "w:pPrChange", "w:sectPr", "w:pBdr", "w:tabs", "w:framePr" -> skipTree(p)
            }
        }
    }

    // ───────── automatic list numbers (numbering.xml) ─────────
    private class NumLvl { var fmt = "decimal"; var text = ""; var start = 1 }
    private class Numbering { val abs = HashMap<String, HashMap<Int, NumLvl>>(); val num = HashMap<String, String>() }

    private fun readNumbering(bytes: ByteArray?): Numbering {
        val nb = Numbering()
        if (bytes == null) return nb
        try {
            val p = android.util.Xml.newPullParser()
            p.setInput(java.io.ByteArrayInputStream(bytes), "UTF-8")
            var curAbs: HashMap<Int, NumLvl>? = null
            var curLvl: NumLvl? = null
            var curNum: String? = null
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "w:abstractNum" -> { val m = HashMap<Int, NumLvl>(); av(p, "w:abstractNumId")?.let { nb.abs[it] = m }; curAbs = m }
                        "w:lvl" -> { val l = NumLvl(); val i = av(p, "w:ilvl")?.toIntOrNull(); if (i != null) curAbs?.put(i, l); curLvl = l }
                        "w:start" -> { val l = curLvl; val v = av(p, "w:val")?.toIntOrNull(); if (l != null && v != null) l.start = v }
                        "w:numFmt" -> { val l = curLvl; val v = av(p, "w:val"); if (l != null && v != null) l.fmt = v }
                        "w:lvlText" -> { val l = curLvl; val v = av(p, "w:val"); if (l != null && v != null) l.text = v }
                        "w:num" -> curNum = av(p, "w:numId")
                        "w:abstractNumId" -> { val n = curNum; val a = av(p, "w:val"); if (n != null && a != null) nb.num[n] = a }
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    when (p.name) {
                        "w:lvl" -> curLvl = null
                        "w:abstractNum" -> curAbs = null
                        "w:num" -> curNum = null
                    }
                }
                ev = p.next()
            }
        } catch (e: Exception) { }
        return nb
    }

    private fun roman(n0: Int): String {
        var n = n0.coerceIn(1, 3999)
        val v = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
        val s = arrayOf("m", "cm", "d", "cd", "c", "xc", "l", "xl", "x", "ix", "v", "iv", "i")
        val sb = StringBuilder()
        for (i in v.indices) while (n >= v[i]) { sb.append(s[i]); n -= v[i] }
        return sb.toString()
    }

    private fun fmtNum(n: Int, fmt: String): String = when (fmt) {
        "decimalZero" -> String.format("%02d", n)
        "lowerLetter" -> ('a' + ((n - 1) % 26)).toString().repeat((n - 1) / 26 + 1)
        "upperLetter" -> ('A' + ((n - 1) % 26)).toString().repeat((n - 1) / 26 + 1)
        "lowerRoman" -> roman(n)
        "upperRoman" -> roman(n).uppercase()
        else -> n.toString()
    }

    private fun readStyles(bytes: ByteArray?): Styles {
        val s = Styles()
        if (bytes == null) return s
        try {
            val p = android.util.Xml.newPullParser()
            p.setInput(java.io.ByteArrayInputStream(bytes), "UTF-8")
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    if (p.name == "w:docDefaults") {
                        val d = p.depth
                        while (true) {
                            val e2 = p.next()
                            if (e2 == XmlPullParser.END_DOCUMENT || (e2 == XmlPullParser.END_TAG && p.depth == d)) break
                            if (e2 == XmlPullParser.START_TAG) {
                                if (p.name == "w:rPr") readRp(p, s.defRp) else if (p.name == "w:pPr") readPp(p, s.defPp)
                            }
                        }
                    } else if (p.name == "w:style") {
                        val id = av(p, "w:styleId")
                        val st = St()
                        if (id != null) {
                            s.map[id] = st
                            if (av(p, "w:type") == "paragraph" && av(p, "w:default") == "1") s.defPara = id
                        }
                        val d = p.depth
                        while (true) {
                            val e2 = p.next()
                            if (e2 == XmlPullParser.END_DOCUMENT || (e2 == XmlPullParser.END_TAG && p.depth == d)) break
                            if (e2 != XmlPullParser.START_TAG) continue
                            when (p.name) {
                                "w:basedOn" -> st.basedOn = av(p, "w:val")
                                "w:rPr" -> readRp(p, st.rp)
                                "w:pPr" -> readPp(p, st.pp)
                                "w:tblPr", "w:tblStylePr", "w:trPr", "w:tcPr" -> skipTree(p)
                            }
                        }
                    }
                }
                ev = p.next()
            }
        } catch (e: Exception) { }
        return s
    }

    private fun applyStyle(sty: Styles, id: String?, rp: RP, pp: PP?, depth: Int = 0) {
        if (id == null || depth > 12) return
        val s = sty.map[id] ?: return
        applyStyle(sty, s.basedOn, rp, pp, depth + 1)
        rp.over(s.rp)
        pp?.over(s.pp)
    }

    @Volatile var lastError = ""
    /** Which reader produced the last result (shown in the label under the page: stream / regex). */
    @Volatile var how = ""

    private val WANT = setOf("word/document.xml", "word/styles.xml", "word/numbering.xml", "word/footnotes.xml")
    /** Text of word/footnotes.xml of the file being read (used by the regex reader; null when the file has none). */
    @Volatile private var footXml: String? = null
    private fun norm(n: String) = n.replace('\\', '/').trimStart('/').lowercase()

    /** Reads a .docx from a file with java.util.zip.ZipFile (robust: uses the central directory, tolerant of odd entry names). */
    fun parse(f: java.io.File): RichDoc {
        val parts = HashMap<String, ByteArray>()
        val names = StringBuilder()
        java.util.zip.ZipFile(f).use { z ->
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (names.length < 400) names.append(e.name).append(';')
                val n = norm(e.name)
                if (n in WANT && !parts.containsKey(n)) parts[n] = z.getInputStream(e).use { it.readBytes() }
            }
        }
        return parseParts(parts, names.toString())
    }

    fun parse(input: InputStream): RichDoc {
        val parts = HashMap<String, ByteArray>()
        val names = StringBuilder()
        java.util.zip.ZipInputStream(input).use { z ->
            var en = z.nextEntry
            while (en != null) {
                if (names.length < 400) names.append(en.name).append(';')
                val n = norm(en.name)
                if (n in WANT && !parts.containsKey(n)) parts[n] = z.readBytes()
                en = z.nextEntry
            }
        }
        return parseParts(parts, names.toString())
    }

    private fun parseParts(parts: HashMap<String, ByteArray>, names: String): RichDoc {
        val doc = parts["word/document.xml"]
        if (doc == null) {
            lastError = "no word/document.xml in: " + names.take(120)
            return RichDoc(SpannableStringBuilder(), 11, false, false, null)
        }
        guard()
        footXml = parts["word/footnotes.xml"]?.let { String(it, Charsets.UTF_8) }
        how = "stream"
        val r = try {
            parseStream(doc, parts["word/styles.xml"], parts["word/numbering.xml"])
        } catch (e: java.util.concurrent.TimeoutException) {
            throw e
        } catch (e: Exception) {
            lastError = e.javaClass.simpleName + " " + (e.message ?: "")
            if (limit.get() != null) throw e
            how = "regex"
            return parseXml(String(doc, Charsets.UTF_8))
        }
        if (r.text.isBlank()) {
            lastError = "stream reader gave no text (xml " + (doc.size / 1024) + "KB); trying regex reader"
            how = "regex"
            try { return parseXml(String(doc, Charsets.UTF_8)) } catch (e: java.util.concurrent.TimeoutException) { throw e } catch (e: Exception) { }
        }
        return r
    }

    private fun parseStream(bytes: ByteArray, stylesBytes: ByteArray?, numBytes: ByteArray?): RichDoc {
        val sty = readStyles(stylesBytes)
        val nb = readNumbering(numBytes)
        val counters = HashMap<String, IntArray>()
        fun numLabel(numId: String, ilvl: Int): String {
            val lv = nb.abs[nb.num[numId] ?: return ""] ?: return ""
            val l0 = ilvl.coerceIn(0, 8)
            val cur = lv[l0] ?: return ""
            val cnt = counters.getOrPut(numId) { IntArray(9) }
            cnt[l0] = if (cnt[l0] == 0) cur.start else cnt[l0] + 1
            for (k in l0 + 1 until 9) cnt[k] = 0
            if (cur.fmt == "none") return ""
            if (cur.fmt == "bullet") return "•"
            var t = cur.text
            if (t.isEmpty()) return ""
            for (k in 0 until 9) {
                val ph = "%" + (k + 1)
                if (t.contains(ph)) {
                    val lk = lv[k]
                    val n = if (cnt[k] == 0) (lk?.start ?: 1) else cnt[k]
                    t = t.replace(ph, fmtNum(n, lk?.fmt ?: "decimal"))
                }
            }
            return t
        }
        guard()
        val out = SpanBuf()
        var base = -1
        var anyRtl = false
        var justify = false
        var font: String? = null
        val x = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        val pcFlag = Spanned.SPAN_PARAGRAPH

        val cache = HashMap<String, Pair<RP, PP>>()
        fun resolve(id: String?): Pair<RP, PP> {
            val key = id ?: sty.defPara ?: ""
            return cache.getOrPut(key) {
                val rp = sty.defRp.copy()
                val pp = sty.defPp.copy()
                applyStyle(sty, if (key.isEmpty()) null else key, rp, pp)
                Pair(rp, pp)
            }
        }

        var pDepth = 0
        var rDepth = 0
        var inT = false
        var curPp = PP()
        var paraRp = RP()
        var paraPp = PP()
        var paraReady = false
        var paraStart = 0
        var runDirect = RP()
        var runShape: ShapeSpan? = null
        val runText = StringBuilder()
        // table state (only the outermost table is turned into |cell|cell| rows)
        var tblDepth = 0
        var cellSpan = 1
        var tStart = 0
        var rowIdx = -1
        var rowStart = 0
        var rowCells = 0
        var rowH = 0f
        var cellP = 0
        var tLookHead = false
        var firstFill: String? = null
        var rowHeadFill = false
        var ncol0 = 0
        var lockDesc: String? = null
        val gw = ArrayList<Float>()
        val rowFills = ArrayList<String>()

        fun ensurePara() {
            if (paraReady) return
            paraReady = true
            val r = resolve(curPp.pStyle)
            paraRp = r.first
            val pp = r.second.copy()
            pp.over(curPp)
            paraPp = pp
            val nid = pp.numId
            if (nid != null && nid != "0" && tblDepth == 0) {
                val lab = numLabel(nid, pp.ilvl ?: 0)
                if (lab.isNotEmpty()) out.append(lab).append(' ')
            }
        }

        fun flushRun() {
            if (runText.isEmpty()) return
            ensurePara()
            val text = runText.toString()
            runText.setLength(0)
            val rp = paraRp.copy()
            runDirect.rStyle?.let { applyStyle(sty, it, rp, null) }
            rp.over(runDirect)
            val rs = out.length
            out.append(text)
            val re = out.length
            if (re <= rs) return
            runShape?.let { sh -> val ix = text.indexOf('\uFFFC'); if (ix >= 0) out.setSpan(sh, rs + ix, rs + ix + 1, x); runShape = null }
            val rtlT = hasRtl(text) || (paraPp.bidi == true && text.none { it.isLetter() })
            if (rp.bold == true) out.setSpan(StyleSpan(Typeface.BOLD), rs, re, x)
            if (rp.ital == true) out.setSpan(StyleSpan(Typeface.ITALIC), rs, re, x)
            if (rp.und == true) out.setSpan(UnderlineSpan(), rs, re, x)
            if (rp.strike == true) out.setSpan(StrikethroughSpan(), rs, re, x)
            if (rp.vert == 1) out.setSpan(ScriptSpan(true), rs, re, x) else if (rp.vert == 2) out.setSpan(ScriptSpan(false), rs, re, x)
            val col = rp.color
            if (col != null && col != 0xFF000000.toInt()) out.setSpan(ForegroundColorSpan(col), rs, re, x)
            val bg = rp.fill ?: rp.hl
            if (bg != null) out.setSpan(BackgroundColorSpan(bg), rs, re, x)
            val szHalf = if (rtlT) (rp.szCs ?: rp.sz) else rp.sz
            val sz = szHalf?.div(2)
            if (base < 0) {
                val d0 = resolve(null).first
                val b0 = (if (rtlT) (d0.szCs ?: d0.sz) else d0.sz)?.div(2)
                base = b0 ?: sz ?: 11
            }
            if (sz != null && sz != base) out.setSpan(AbsoluteSizeSpan(sz, true), rs, re, x)
            val fam = if (rtlT) (rp.fCs ?: rp.fAscii) else (rp.fAscii ?: rp.fCs)
            if (fam != null) {
                if (font == null) font = fam
                else if (fam != font) out.setSpan(FontSpan(fam), rs, re, x)
            }
        }

        fun endParagraph() {
            ensurePara()
            if (paraPp.bidi == true) anyRtl = true
            if (tblDepth == 0) {
                out.append("\n")
                val ps = paraStart
                val pe = out.length
                val jc = paraPp.jc
                if (jc == "both") justify = true
                val al = when (jc) {
                    "center" -> Layout.Alignment.ALIGN_CENTER
                    "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
                    else -> null
                }
                if (al != null) out.setSpan(AlignmentSpan.Standard(al), ps, pe, pcFlag)
                val iLeft = (paraPp.left ?: 0f).coerceAtLeast(0f)
                val iFirst = (iLeft + (paraPp.first ?: 0f) - (paraPp.hang ?: 0f)).coerceAtLeast(0f)
                if (iLeft > 0f || iFirst > 0f) out.setSpan(ParaIndentSpan(iFirst, iLeft), ps, pe, pcFlag)
                val sB = (paraPp.before ?: 0f).coerceAtLeast(0f)
                val sA = (paraPp.after ?: 0f).coerceAtLeast(0f)
                if (sB > 0f || sA > 0f) out.setSpan(ParaSpaceSpan(sB, sA), ps, pe, pcFlag)
            }
            paraReady = false
        }

        fun nlFrom(a: Int): Int { var i = a; val n = out.length; while (i < n) { if (out[i] == '\n') return i; i++ }; return -1 }

        fun endRow() {
            val rowEnd = out.length
            if (rowIdx == 0) {
                ncol0 = rowCells.coerceAtLeast(1)
                if (rowHeadFill || tLookHead) out.append("\n|").append("---|".repeat(ncol0))
            }
            val lineEnd = out.length
            out.append("\n")
            if (rowFills.isNotEmpty()) {
                val dom = rowFills.groupingBy { it.uppercase() }.eachCount().maxByOrNull { it.value }
                if (dom != null && dom.value * 2 >= rowCells.coerceAtLeast(1)) {
                    dom.key.toIntOrNull(16)?.let { out.setSpan(RowFillSpan(0xFF000000.toInt() or it), rowStart, lineEnd + 1, pcFlag) }
                }
            }
            val extra = (rowH - 400f) / 15f
            if (rowH > 0f && extra >= 1f && rowEnd + 1 > rowStart) out.setSpan(RowHeightSpan(extra, 2.75f), rowStart, rowEnd + 1, pcFlag)
        }

        fun endTable() {
            if (out.length <= tStart) return
            if (gw.size == ncol0 && ncol0 > 1 && gw.sum() > 0f) {
                val fr = TableWidths.normalize(gw.toFloatArray())
                val eqW = 1f / ncol0
                if (fr.any { Math.abs(it - eqW) > 0.01f }) out.setSpan(TableWidthSpan(fr), tStart, out.length, pcFlag)
            }
            lockDesc?.let { d ->
                val m = Regex("MSFLOCK;r=([0-9,]*);c=([0-9,]*)").find(d)
                if (m != null) {
                    val lr = m.groupValues[1].split(',').mapNotNull { it.toIntOrNull() }.toSet()
                    val lc = m.groupValues[2].split(',').mapNotNull { it.toIntOrNull() }.toSet()
                    if (lr.isNotEmpty() || lc.isNotEmpty()) out.setSpan(TableLockSpan(lr, lc), tStart, out.length, pcFlag)
                }
            }
            val tStyle = firstFill?.let { TableStyles.fromHex(it) } ?: 0
            if (tStyle > 0) {
                val nl1 = nlFrom(tStart)
                val tEnd = if (nl1 < 0) out.length else nl1 + 1
                out.setSpan(TableStyleSpan(tStyle), tStart, tEnd, pcFlag)
            }
        }

        val p = android.util.Xml.newPullParser()
        p.setInput(java.io.ByteArrayInputStream(bytes), "UTF-8")
        var steps = 0
        val tStart0 = System.nanoTime()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if ((++steps and 0xFFF) == 0) {
                guard()
                if ((steps and 0x7FFF) == 0) Work.progress("فارمیٹنگ پڑھ رہا ہے… " + ((System.nanoTime() - tStart0) / 1_000_000_000L) + "s / Reading formatting…")
            }
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "mc:Fallback", "w:sectPr" -> skipTree(p)
                    "w:tbl" -> {
                        if (tblDepth == 0) {
                            tStart = out.length; rowIdx = -1; ncol0 = 0; tLookHead = false; firstFill = null
                            rowHeadFill = false; lockDesc = null; gw.clear()
                        }
                        tblDepth++
                    }
                    "w:tblGridChange" -> skipTree(p)   // old copy of the grid: its columns were counted twice
                    "w:tblLook" -> if (tblDepth == 1 && av(p, "w:firstRow") == "1") tLookHead = true
                    "w:gridCol" -> if (tblDepth == 1 && rowIdx < 0) { av(p, "w:w")?.toFloatOrNull()?.let { gw.add(it) } }
                    "w:tblDescription" -> if (tblDepth == 1) lockDesc = av(p, "w:val")
                    "w:tr" -> if (tblDepth == 1) {
                        rowIdx++; rowStart = out.length; rowCells = 0; rowH = 0f; rowFills.clear()
                        if (rowIdx == 0) rowHeadFill = false
                        out.append("|")
                    }
                    "w:trHeight" -> if (tblDepth == 1) rowH = av(p, "w:val")?.toFloatOrNull() ?: 0f
                    "w:tc" -> if (tblDepth == 1) { out.append(" "); cellP = 0; rowCells++; cellSpan = 1 }
                    "w:gridSpan" -> if (tblDepth == 1) cellSpan = (av(p, "w:val")?.toIntOrNull() ?: 1).coerceIn(1, 30)
                    "w:shd" -> if (tblDepth == 1 && rowIdx >= 0) {
                        val f = av(p, "w:fill")
                        if (f != null && f.length == 6 && f.toIntOrNull(16) != null) {
                            if (rowIdx == 0) {
                                if (firstFill == null) firstFill = f
                                if (f == "E8EEF7") rowHeadFill = true
                            }
                            if (!f.equals("FFFFFF", true)) rowFills.add(f)
                        }
                    }
                    "w:p" -> {
                        if (pDepth == 0) {
                            curPp = PP(); paraReady = false; paraStart = out.length
                            if (tblDepth == 1) { if (cellP > 0) out.append(" "); cellP++ }
                            else if (tblDepth > 1) out.append(" ")
                        }
                        pDepth++
                    }
                    "w:pPr" -> if (pDepth == 1) {
                        readPp(p, curPp)
                        if (curPp.pageBreak && tblDepth == 0 && out.isNotEmpty()) { out.append(PAGE_BREAK).append("\n"); paraStart = out.length }
                    } else skipTree(p)
                    "w:r" -> if (pDepth >= 1) {
                        if (rDepth == 0) { runDirect = RP(); runText.setLength(0); runShape = null }
                        rDepth++
                    }
                    "wp:docPr" -> if (rDepth > 0) {
                        // one of our own drawn shapes (descr = "msfshape:<preset name>:<1 filled / 0 outline>[;w=..][;c=..][;t=..]")
                        val sp0 = ShapeSpan.fromDescr(av(p, "descr") ?: "")
                        if (sp0 != null) { runShape = sp0; runText.append('\uFFFC') }
                    }
                    // the text of a shape is kept in its descr; the text box inside the drawing must not be read again as normal text
                    "wps:txbx" -> if (rDepth > 0 && runShape != null) skipTree(p)
                    "w:rPr" -> if (rDepth >= 1) readRp(p, runDirect) else skipTree(p)
                    "w:t" -> inT = true
                    "w:tab" -> if (rDepth > 0) runText.append('\t')
                    "w:cr" -> if (rDepth > 0) runText.append('\n')
                    "w:br" -> if (rDepth > 0) runText.append(if (av(p, "w:type") == "page") PAGE_BREAK else '\n')
                }
                XmlPullParser.TEXT -> if (inT && rDepth > 0) runText.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "w:t" -> inT = false
                    "w:r" -> if (rDepth > 0) { rDepth--; if (rDepth == 0) flushRun() }
                    "w:p" -> if (pDepth > 0) {
                        pDepth--
                        if (pDepth == 0) endParagraph() else if (rDepth > 0) runText.append(' ')
                    }
                    "w:tc" -> if (tblDepth == 1) {
                        out.append(" |"); for (k in 1 until cellSpan) { out.append(" |"); rowCells++ }; cellSpan = 1 }
                    "w:tr" -> if (tblDepth == 1) endRow()
                    "w:tbl" -> if (tblDepth > 0) { tblDepth--; if (tblDepth == 0) endTable() }
                }
            }
            ev = p.next()
        }
        out.dropLast('\n')
        return RichDoc(out.build(), if (base < 0) 11 else base, anyRtl, justify, font)
    }

    /** Index of the next real opening tag `tag` (e.g. "<w:p" but not "<w:pPr"), or -1. Plain indexOf scan: linear, no regex. */
    private fun nextOpen(s: String, tag: String, from: Int): Int {
        var i = from
        while (true) {
            val a = s.indexOf(tag, i)
            if (a < 0) return -1
            val k = a + tag.length
            if (k < s.length) {
                val c = s[k]
                if (c == '>' || c == ' ' || (c == '/' && tag == "<w:p" && s.startsWith("<w:p/>", a))) return a
            }
            i = k
        }
    }

    /** End (exclusive) of the element that opens at [a], or -1 when it is never closed. */
    private fun endOf(s: String, a: Int, tag: String, close: String): Int {
        if (tag == "<w:p" && s.startsWith("<w:p/>", a)) return a + 6
        // tables / rows / cells can be nested (a table inside a cell): count the depth so the
        // matching close tag is found, not the first one (this used to double cells and rows)
        if (tag == "<w:tbl" || tag == "<w:tr" || tag == "<w:tc" || tag == "<w:p" || tag == "<w:r") {
            var depth = 1
            var i = a + tag.length
            while (depth > 0) {
                val o = nextOpen(s, tag, i)
                val c = s.indexOf(close, i)
                if (c < 0) return -1
                if (o in 0 until c) {
                    if (tag == "<w:p" && s.startsWith("<w:p/>", o)) i = o + 6 else { depth++; i = o + tag.length }
                }
                else { depth--; i = c + close.length }
            }
            return i
        }
        val e = s.indexOf(close, a + tag.length)
        return if (e < 0) -1 else e + close.length
    }

    /** All elements `tag ... close` inside [s], in order (not nested). */
    private fun blocksOf(s: String, tag: String, close: String): List<String> {
        val out = ArrayList<String>()
        var i = 0
        while (true) {
            val a = nextOpen(s, tag, i)
            if (a < 0) break
            val end = endOf(s, a, tag, close)
            if (end < 0) break
            out.add(s.substring(a, end))
            i = end
        }
        return out
    }

    /** Number of grid columns a row takes (merged cells count as their span). */
    private fun cellCount(rowXml: String): Int {
        var n = 0
        for (c in blocksOf(rowXml, "<w:tc", "</w:tc>")) {
            val gs = Regex("<w:gridSpan w:val=\"(\\d+)\"").find(c)?.groupValues?.get(1)?.toIntOrNull() ?: 1
            n += gs.coerceIn(1, 30)
        }
        return n
    }

    /** Removes <mc:Fallback>..</mc:Fallback> (a second copy of text boxes / shapes): reading both doubled the text. */
    private fun dropFallback(x: String): String {
        if (x.indexOf("<mc:Fallback") < 0) return x
        val sb = StringBuilder(x.length)
        var i = 0
        while (true) {
            val a = x.indexOf("<mc:Fallback", i)
            if (a < 0) { sb.append(x, i, x.length); break }
            sb.append(x, i, a)
            val e = x.indexOf("</mc:Fallback>", a)
            if (e < 0) break
            i = e + 14
        }
        return sb.toString()
    }

    private fun parseXml(xml0: String): RichDoc {
        val xml = dropFallback(xml0)
        guard()
        val out = SpanBuf()
        var base = -1
        var anyRtl = false
        var justify = false
        var font: String? = null
        val token = Regex("<w:drawing>(?=(?:(?!</w:drawing>).)*msfshape).*?</w:drawing>|<w:t(?: [^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br(?: [^>]*)?/>|<w:footnoteReference[^>]*/>|<w:footnoteRef/>", DOT)
        // footnotes (حوالہ جات): id -> its paragraphs; numbered 1, 2, 3 ... in the order they are referenced
        val fnParas = HashMap<String, List<String>>()
        footXml?.let { fx ->
            for (fb in blocksOf(fx, "<w:footnote", "</w:footnote>")) {
                val id = Regex("<w:footnote [^>]*w:id=\"(-?\\d+)\"").find(fb)?.groupValues?.get(1) ?: continue
                if (fb.contains("w:type=\"separator\"") || fb.contains("w:type=\"continuationSeparator\"")) continue
                fnParas[id] = blocksOf(fb, "<w:p", "</w:p>")
            }
        }
        val fnNum = HashMap<String, Int>()
        var curFnId = ""
        val rxFnRef = Regex("<w:footnoteReference[^>]*w:id=\"(-?\\d+)\"")
        // compiled once (they used to be rebuilt for every run of text = very slow on big documents)
        val rxRun = Regex("<w:r[ >].*?</w:r>", DOT)
        val rxRpr = Regex("<w:rPr>(.*?)</w:rPr>", DOT)
        val rxB = Regex("<w:b w:val=\"(1|true|on)\"")
        val rxI = Regex("<w:i w:val=\"(1|true|on)\"")
        val rxU = Regex("<w:u w:val=\"(?!none)\\w+\"")
        val rxColor = Regex("<w:color w:val=\"([0-9A-Fa-f]{6})\"")
        val rxFill = Regex("<w:shd [^>]*w:fill=\"([0-9A-Fa-f]{6})\"")
        val rxHl = Regex("<w:highlight w:val=\"(\\w+)\"")
        val rxSz = Regex("<w:sz w:val=\"(\\d+)\"")
        val rxFam = Regex("<w:rFonts [^>]*?w:(?:ascii|cs)=\"([^\"]+)\"")
        fun addRuns(px: String) {
        for (r in blocksOf(px, "<w:r", "</w:r>")) {
            val rx = r
            val rpr = rxRpr.find(rx)?.groupValues?.get(1) ?: ""
            val text = token.findAll(rx).joinToString("") {
                when {
                    it.value == "<w:footnoteRef/>" -> (fnNum[curFnId] ?: 0).takeIf { n -> n > 0 }?.toString() ?: ""
                    it.value.startsWith("<w:footnoteReference") -> {
                        val fid = Regex("w:id=\"(-?\\d+)\"").find(it.value)?.groupValues?.get(1) ?: ""
                        if (fid.isEmpty() || !fnParas.containsKey(fid)) "" else fnNum.getOrPut(fid) { fnNum.size + 1 }.toString()
                    }
                    it.value.startsWith("<w:drawing") -> "\uFFFC"
                    it.value.startsWith("<w:tab") -> "\t"
                    it.value.startsWith("<w:br") -> if (it.value.contains("\"page\"")) PAGE_BREAK.toString() else "\n"
                    else -> unesc(it.groupValues[1])
                }
            }
            val rs = out.length
            out.append(text)
            val re = out.length
            if (re <= rs) continue
            val x = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            if (text.contains('\uFFFC')) ShapeSpan.RX.find(rx)?.let { m ->
                val ix = text.indexOf('\uFFFC')
                ShapeSpan.make(m.groupValues[1], m.groupValues[2], m.groupValues[3])?.let { out.setSpan(it, rs + ix, rs + ix + 1, x) }
            }
            if (rpr.contains("<w:b/>") || rxB.containsMatchIn(rpr)) out.setSpan(StyleSpan(Typeface.BOLD), rs, re, x)
            if (rpr.contains("<w:i/>") || rxI.containsMatchIn(rpr)) out.setSpan(StyleSpan(Typeface.ITALIC), rs, re, x)
            if (rpr.contains("<w:u/>") || rxU.containsMatchIn(rpr)) out.setSpan(UnderlineSpan(), rs, re, x)
            if (rpr.contains("<w:strike/>")) out.setSpan(StrikethroughSpan(), rs, re, x)
            if (rpr.contains("w:vertAlign w:val=\"superscript\"")) out.setSpan(ScriptSpan(true), rs, re, x)
            else if (rpr.contains("w:vertAlign w:val=\"subscript\"")) out.setSpan(ScriptSpan(false), rs, re, x)
            rxColor.find(rpr)?.let {
                out.setSpan(ForegroundColorSpan(0xFF000000.toInt() or it.groupValues[1].toInt(16)), rs, re, x)
            }
            val fill = rxFill.find(rpr)?.groupValues?.get(1)
            val hl = rxHl.find(rpr)?.groupValues?.get(1)
            if (fill != null) out.setSpan(BackgroundColorSpan(0xFF000000.toInt() or fill.toInt(16)), rs, re, x)
            else if (hl != null) highlightColor(hl)?.let { out.setSpan(BackgroundColorSpan(it), rs, re, x) }
            val sz = rxSz.find(rpr)?.groupValues?.get(1)?.toIntOrNull()?.div(2)
            if (sz != null) {
                if (base < 0) base = sz
                if (sz != base) out.setSpan(AbsoluteSizeSpan(sz, true), rs, re, x)
            }
            val fam = rxFam.find(rpr)?.groupValues?.get(1)
            if (fam != null) {
                if (font == null) font = fam
                else if (fam != font) out.setSpan(FontSpan(fam), rs, re, x)
            }
        }
        }
        var segCount = 0
        // newline search without copying the whole text (out.toString() per table used to copy it again and again)
        fun nlFrom(a: Int): Int { var i = a; val n = out.length; while (i < n) { if (out[i] == '\n') return i; i++ }; return -1 }
        var nt = nextOpen(xml, "<w:tbl", 0)
        var np = nextOpen(xml, "<w:p", 0)
        while (nt >= 0 || np >= 0) {
            val useT = nt >= 0 && (np < 0 || nt < np)
            val sa = if (useT) nt else np
            val se = endOf(xml, sa, if (useT) "<w:tbl" else "<w:p", if (useT) "</w:tbl>" else "</w:p>")
            if (se < 0) break
            val px = xml.substring(sa, se)
            if (nt in 0 until se) nt = nextOpen(xml, "<w:tbl", se)
            if (np in 0 until se) np = nextOpen(xml, "<w:p", se)
            val isLastSeg = nt < 0 && np < 0
            if ((++segCount and 31) == 0) {
                guard()
                progress?.invoke(((se.toLong() * 100L) / xml.length.coerceAtLeast(1)).toInt().coerceIn(0, 99))
            }
            if (px.startsWith("<w:tbl")) {
                // a table becomes |cell|cell| lines (with a |---| line after a shaded header row)
                val rowsX = blocksOf(px, "<w:tr", "</w:tr>")
                val tStart = out.length
                val tLookHead = px.contains("w:firstRow=\"1\"")
                val tStyle = rowsX.firstOrNull()?.let { r0 ->
                    Regex("w:fill=\"([0-9A-Fa-f]{6})\"").find(r0)?.groupValues?.get(1)?.let { TableStyles.fromHex(it) }
                } ?: 0
                val rowStarts = ArrayList<Int>()
                // A Word table without <w:bidiVisual/> lists its cells from the LEFT, but this editor puts the first cell of a
                // right-to-left table at the RIGHT edge. For such a table (Urdu paragraphs in it) the cells are stored in
                // reverse order, so the screen and the PDF look like in Word / WPS (number column at the right edge).
                val reverseCols = !px.contains("<w:bidiVisual") && (px.contains("<w:bidi/>") || px.contains("<w:bidi "))
                for ((ri, rx) in rowsX.withIndex()) {
                    rowStarts.add(out.length)
                    out.append("|")
                    val cellsX = blocksOf(rx, "<w:tc", "</w:tc>").let { if (reverseCols) it.reversed() else it }
                    for (cx in cellsX) {
                        out.append(" ")
                        val cps = blocksOf(cx, "<w:p", "</w:p>")
                        for ((k, cp) in cps.withIndex()) {
                            if (k > 0) out.append(" ")
                            if (cp.contains("<w:bidi")) anyRtl = true
                            addRuns(cp)
                        }
                        out.append(" |")
                        // merged cell (gridSpan): keep the grid by adding empty cells, never repeat the text
                        val gs = Regex("<w:gridSpan w:val=\"(\\d+)\"").find(cx)?.groupValues?.get(1)?.toIntOrNull() ?: 1
                        for (k in 1 until gs.coerceIn(1, 30)) out.append(" |")
                    }
                    val last = isLastSeg && ri == rowsX.size - 1
                    if (ri == 0 && (rx.contains("w:fill=\"E8EEF7\"") || tLookHead)) {
                        val n = cellCount(rx).coerceAtLeast(1)
                        out.append("\n|").append("---|".repeat(n))
                    }
                    if (!last) out.append("\n")
                }
                if (out.length > tStart) {
                    val gw = Regex("<w:gridCol w:w=\"(\\d+)(?:\\.\\d+)?\"").findAll(Regex("<w:tblGridChange.*?</w:tblGridChange>", DOT).replace(px, "")).map { it.groupValues[1].toFloat() }.toList()
                    val ncol = cellCount(rowsX.firstOrNull() ?: "")
                    if (gw.size == ncol && ncol > 1 && gw.sum() > 0f) {
                        val fr = TableWidths.normalize((if (reverseCols) gw.reversed() else gw).toFloatArray())
                        val eqW = 1f / ncol
                        if (fr.any { Math.abs(it - eqW) > 0.01f }) out.setSpan(TableWidthSpan(fr), tStart, out.length, Spanned.SPAN_PARAGRAPH)
                    }
                    Regex("<w:tblDescription w:val=\"MSFLOCK;r=([0-9,]*);c=([0-9,]*)\"").find(px)?.let { m ->
                        val lr = m.groupValues[1].split(',').mapNotNull { it.toIntOrNull() }.toSet()
                        val lc = m.groupValues[2].split(',').mapNotNull { it.toIntOrNull() }.toSet()
                        if (lr.isNotEmpty() || lc.isNotEmpty()) out.setSpan(TableLockSpan(lr, lc), tStart, out.length, Spanned.SPAN_PARAGRAPH)
                    }
                    for ((ri, rx) in rowsX.withIndex()) {
                        val hv = Regex("<w:trHeight w:val=\"(\\d+)\"").find(rx)?.groupValues?.get(1)?.toFloatOrNull() ?: continue
                        val extra = (hv - 400f) / 15f
                        if (extra < 1f) continue
                        val a = rowStarts[ri]
                        var b = nlFrom(a)
                        b = if (b < 0) out.length else b + 1
                        if (b > a) out.setSpan(RowHeightSpan(extra, 2.75f), a, b, Spanned.SPAN_PARAGRAPH)
                    }
                }
                if (tStyle > 0 && out.length > tStart) {
                    val nl1 = nlFrom(tStart)
                    val tEnd = if (nl1 < 0) out.length else nl1 + 1
                    out.setSpan(TableStyleSpan(tStyle), tStart, tEnd, Spanned.SPAN_PARAGRAPH)
                }
                continue
            }
            if (px.contains("<w:pageBreakBefore") && out.isNotEmpty()) out.append(PAGE_BREAK).append("\n")
            val ps = out.length
            if (px.contains("<w:bidi")) anyRtl = true
            val jc = Regex("<w:jc w:val=\"(\\w+)\"").find(px)?.groupValues?.get(1)
            addRuns(px)
            if (!isLastSeg) out.append("\n")
            val al = when (jc) {
                "center" -> Layout.Alignment.ALIGN_CENTER
                "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
                else -> null
            }
            if (jc == "both") justify = true
            if (al != null) out.setSpan(AlignmentSpan.Standard(al), ps, out.length, Spanned.SPAN_PARAGRAPH)
            val pPr = Regex("<w:pPr>(.*?)</w:pPr>", DOT).find(px)?.groupValues?.get(1)?.replace(Regex("<w:rPr>.*?</w:rPr>", DOT), "") ?: ""
            fun attr(tag: String, name: String): Float? {
                val m = Regex("<w:$tag ([^>]*?)/?>").find(pPr) ?: return null
                return Regex("w:$name=\"(-?\\d+)\"").find(m.groupValues[1])?.groupValues?.get(1)?.toFloatOrNull()?.div(20f)
            }
            val iLeft = (attr("ind", "left") ?: attr("ind", "start") ?: 0f).coerceAtLeast(0f)
            val iFirst = (iLeft + (attr("ind", "firstLine") ?: 0f) - (attr("ind", "hanging") ?: 0f)).coerceAtLeast(0f)
            if (iLeft > 0f || iFirst > 0f) out.setSpan(ParaIndentSpan(iFirst, iLeft), ps, out.length, Spanned.SPAN_PARAGRAPH)
            val sBefore = (attr("spacing", "before") ?: 0f).coerceAtLeast(0f)
            val sAfter = (attr("spacing", "after") ?: 0f).coerceAtLeast(0f)
            if (sBefore > 0f || sAfter > 0f) out.setSpan(ParaSpaceSpan(sBefore, sAfter), ps, out.length, Spanned.SPAN_PARAGRAPH)
            // footnotes of this paragraph: a thin rule and the footnote text (small) right under the paragraph
            if (fnParas.isNotEmpty() && px.contains("<w:footnoteReference")) {
                val ids = rxFnRef.findAll(px).map { it.groupValues[1] }.filter { fnParas.containsKey(it) }.toList()
                if (ids.isNotEmpty()) {
                    if (isLastSeg) out.append("\n")
                    val rs0 = out.length
                    out.append("────────")
                    out.setSpan(ForegroundColorSpan(0xFF8A8A8A.toInt()), rs0, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    out.setSpan(AbsoluteSizeSpan(8, true), rs0, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    out.append("\n")
                    for (id in ids) {
                        curFnId = id
                        for (fp in fnParas[id] ?: emptyList()) {
                            if (fp.contains("<w:bidi")) anyRtl = true
                            addRuns(fp)
                            out.append("\n")
                        }
                    }
                }
            }
        }
        footXml = null
        return RichDoc(out.build(), if (base < 0) 11 else base, anyRtl, justify, font)
    }
}
