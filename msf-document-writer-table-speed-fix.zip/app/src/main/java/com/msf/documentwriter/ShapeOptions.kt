package com.msf.documentwriter

import android.view.GestureDetector
import android.view.MotionEvent
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.widget.EditText
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * The options of one shape: colour, outline / filled, size (height in pt), width (% of normal), the text written inside it and the
 * colour of that text (null = automatic). Used by the Shapes sheet (for the next shape that is inserted) and by the edit window
 * that opens when a shape in the document is tapped.
 */
class ShapeOpts {
    var color by mutableIntStateOf(0xFF000000.toInt())
    var fill by mutableStateOf(false)
    var heightPt by mutableIntStateOf(44)
    var widthPct by mutableIntStateOf(100)
    var label by mutableStateOf("")
    var labelColor by mutableStateOf<Int?>(null)
    var labelFont by mutableStateOf<String?>(null)
}

private val ShapePalette: List<Int> = listOf(
    0xFF000000, 0xFF616161, 0xFFE53935, 0xFFF4511E, 0xFFFB8C00, 0xFFFDD835, 0xFF7CB342, 0xFF2BA36A,
    0xFF00897B, 0xFF00ACC1, 0xFF3B8EDB, 0xFF1E3A8A, 0xFF8E24AA, 0xFFD81B60, 0xFF6D4C41, 0xFFFFFFFF
).map { it.toInt() }

/** Row of colours (scrolls sideways) + "custom colour" button. [auto] adds an "Auto" choice that gives null. */
@Composable
fun ShapeColorRow(sel: Int?, auto: Boolean, fg: Color, onPick: (Int?) -> Unit) {
    var custom by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (auto) {
            Text(
                "Auto", color = fg, fontSize = 13.sp,
                modifier = Modifier.padding(end = 8.dp)
                    .border(if (sel == null) 3.dp else 1.dp, if (sel == null) Color(0xFF4A8BEF) else Color(0xFF8E8E8E), RoundedCornerShape(14.dp))
                    .clickable { onPick(null) }.padding(horizontal = 10.dp, vertical = 5.dp)
            )
        }
        for (c in ShapePalette) {
            Box(
                Modifier.padding(end = 8.dp).size(30.dp).background(Color(c), CircleShape)
                    .border(if (sel == c) 3.dp else 1.dp, if (sel == c) Color(0xFF4A8BEF) else Color(0xFF8E8E8E), CircleShape)
                    .clickable { onPick(c) }
            )
        }
        Box(
            Modifier.size(30.dp).border(1.dp, Color(0xFF8E8E8E), CircleShape).clickable { custom = true },
            contentAlignment = Alignment.Center
        ) { Text("🎨", fontSize = 15.sp) }
    }
    if (custom) {
        RgbDialog(sel ?: 0xFF000000.toInt(), onOk = { onPick(it); custom = false }, onCancel = { custom = false })
    }
}

/** Own colour: red / green / blue sliders. */
@Composable
private fun RgbDialog(initial: Int, onOk: (Int) -> Unit, onCancel: () -> Unit) {
    var r by remember { mutableIntStateOf((initial shr 16) and 0xFF) }
    var g by remember { mutableIntStateOf((initial shr 8) and 0xFF) }
    var b by remember { mutableIntStateOf(initial and 0xFF) }
    val col = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Custom colour / اپنا رنگ") },
        text = {
            Column {
                Box(Modifier.fillMaxWidth().height(44.dp).background(Color(col), RoundedCornerShape(8.dp)).border(1.dp, Color(0xFF888888), RoundedCornerShape(8.dp)))
                Text("Red / سرخ: $r", fontSize = 13.sp)
                Slider(value = r.toFloat(), onValueChange = { r = it.roundToInt() }, valueRange = 0f..255f)
                Text("Green / سبز: $g", fontSize = 13.sp)
                Slider(value = g.toFloat(), onValueChange = { g = it.roundToInt() }, valueRange = 0f..255f)
                Text("Blue / نیلا: $b", fontSize = 13.sp)
                Slider(value = b.toFloat(), onValueChange = { b = it.roundToInt() }, valueRange = 0f..255f)
            }
        },
        confirmButton = { TextButton(onClick = { onOk(col) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

/** The controls: colour, outline / filled, size, width, text inside, text colour. */
@Composable
fun ShapeControls(o: ShapeOpts, fg: Color, sub: Color) {
    Column(Modifier.fillMaxWidth()) {
        Text("Colour / رنگ", color = fg, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        ShapeColorRow(o.color, false, fg) { if (it != null) o.color = it }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Start) {
            for ((label, f) in listOf("Outline / خالی" to false, "Filled / بھرا ہوا" to true)) {
                Text(
                    label, color = if (o.fill == f) Color.White else fg, fontSize = 14.sp,
                    modifier = Modifier.padding(end = 8.dp)
                        .background(if (o.fill == f) Color(0xFF3B5B99) else Color(0x33888888), RoundedCornerShape(14.dp))
                        .clickable { o.fill = f }.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
        }
        Text("Size / سائز: ${o.heightPt} pt", color = fg, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Slider(value = o.heightPt.toFloat(), onValueChange = { o.heightPt = it.roundToInt().coerceIn(10, 300) }, valueRange = 10f..300f)
        Text("Width / چوڑائی: ${o.widthPct}%", color = fg, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Slider(value = o.widthPct.toFloat(), onValueChange = { o.widthPct = it.roundToInt().coerceIn(20, 300) }, valueRange = 20f..300f)
        Text("Text inside / شکل کے اندر ٹیکسٹ", color = fg, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        BasicTextField(
            value = o.label, onValueChange = { o.label = it },
            textStyle = TextStyle(color = fg, fontSize = 16.sp),
            cursorBrush = SolidColor(fg),
            modifier = Modifier.fillMaxWidth().border(1.dp, sub, RoundedCornerShape(8.dp)).padding(10.dp),
            decorationBox = { inner ->
                if (o.label.isEmpty()) Text("…", color = sub, fontSize = 16.sp)
                inner()
            }
        )
        Spacer(Modifier.height(6.dp))
        Text("Font / فونٹ", color = fg, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            for ((flabel, fam) in Fonts.all()) {
                val value: String? = if (fam == "sans-serif") null else fam
                val on = o.labelFont == value
                val ff = try { androidx.compose.ui.text.font.FontFamily(Fonts.typeface(fam)) } catch (_: Throwable) { androidx.compose.ui.text.font.FontFamily.Default }
                Text(
                    flabel, color = fg, fontSize = 15.sp, fontFamily = ff,
                    modifier = Modifier.padding(end = 8.dp)
                        .border(if (on) 3.dp else 1.dp, if (on) Color(0xFF4A8BEF) else Color(0xFF8E8E8E), RoundedCornerShape(14.dp))
                        .clickable { o.labelFont = value }.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("Text colour / ٹیکسٹ کا رنگ", color = fg, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        ShapeColorRow(o.labelColor, true, fg) { o.labelColor = it }
    }
}

/** A white "page" that shows the shape [id] the way it will look with the options [o]. */
@Composable
fun ShapePreview(id: String, o: ShapeOpts) {
    Box(Modifier.fillMaxWidth().height(96.dp).background(Color.White, RoundedCornerShape(10.dp)).border(1.dp, Color(0xFF8E8E8E), RoundedCornerShape(10.dp))) {
        Canvas(Modifier.fillMaxWidth().height(96.dp)) {
            val pad = 12.dp.toPx()
            val asp = ShapeArt.aspect(id) * o.widthPct / 100f
            var h = size.height - 2 * pad
            var w = h * asp
            if (w > size.width - 2 * pad) { w = size.width - 2 * pad; h = w / asp }
            val l = (size.width - w) / 2f
            val t = (size.height - h) / 2f
            drawIntoCanvas { cv ->
                ShapeArt.draw(cv.nativeCanvas, id, l, t, w, h, o.color, o.fill, 2.dp.toPx())
                if (o.label.isNotEmpty()) ShapeArt.drawLabel(cv.nativeCanvas, o.label, l, t, w, h, o.labelColor ?: ShapeArt.autoText(o.color, o.fill), o.labelFont?.let { Fonts.typeface(it) })
            }
        }
    }
}

/** Which shape of the document is being edited: the index of its object character, or -1. */
object ShapeEdit {
    var start by mutableIntStateOf(-1)
}

/** Tapping a shape in the document opens its edit window. */
object ShapeTap {
    fun attach(et: EditText) {
        val gd = GestureDetector(et.context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                try {
                    val i = shapeAt(et, e.x, e.y)
                    if (i >= 0) ShapeEdit.start = i
                } catch (_: Throwable) { }
                return false
            }
        })
        et.setOnTouchListener { _, ev -> gd.onTouchEvent(ev); false }
    }

    private fun shapeAt(et: EditText, x: Float, y: Float): Int {
        val lay = et.layout ?: return -1
        val t = et.text
        val xx = x - et.totalPaddingLeft + et.scrollX
        val yy = y - et.totalPaddingTop + et.scrollY
        if (yy < 0f || yy > lay.height) return -1
        val line = lay.getLineForVertical(yy.toInt())
        val off = lay.getOffsetForHorizontal(line, xx)
        for (o in intArrayOf(off, off - 1)) {
            if (o < 0 || o >= t.length || t[o] != '\uFFFC') continue
            if (t.getSpans(o, o + 1, ShapeSpan::class.java).isEmpty()) continue
            val a = lay.getPrimaryHorizontal(o)
            val b = lay.getPrimaryHorizontal(o + 1)
            if (xx >= min(a, b) - 4f && xx <= max(a, b) + 4f && lay.getLineForOffset(o) == line) return o
        }
        return -1
    }
}

/** The edit window of the tapped shape (put once in the editor screen). */
@Composable
fun ShapeEditHost() {
    val st = ShapeEdit.start
    if (st < 0) return
    val et = InsertBridge.et
    val text = et?.text
    val span = if (text != null && st < text.length && text[st] == '\uFFFC') text.getSpans(st, st + 1, ShapeSpan::class.java).firstOrNull() else null
    if (et == null || text == null || span == null) {
        LaunchedEffect(st) { ShapeEdit.start = -1 }
        return
    }
    val o = remember(st) {
        ShapeOpts().also { op ->
            op.fill = span.fill
            op.widthPct = (span.wScale * 100f).roundToInt().coerceIn(20, 300)
            op.label = span.label
            op.labelColor = span.labelColor
            op.labelFont = span.labelFont
            val cs = text.getSpans(st, st + 1, ForegroundColorSpan::class.java).filter { text.getSpanStart(it) <= st && text.getSpanEnd(it) >= st + 1 }
                .minByOrNull { text.getSpanEnd(it) - text.getSpanStart(it) }
            op.color = cs?.foregroundColor ?: 0xFF000000.toInt()
            val zs = text.getSpans(st, st + 1, AbsoluteSizeSpan::class.java).filter { text.getSpanStart(it) <= st && text.getSpanEnd(it) >= st + 1 }
                .minByOrNull { text.getSpanEnd(it) - text.getSpanStart(it) }
            op.heightPt = (zs?.size ?: 44).coerceIn(10, 300)
        }
    }
    val fg = MaterialTheme.colorScheme.onSurface
    AlertDialog(
        onDismissRequest = { ShapeEdit.start = -1 },
        title = { Text("Shape / شکل") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                ShapePreview(span.id, o)
                Spacer(Modifier.height(8.dp))
                ShapeControls(o, fg, fg.copy(alpha = 0.5f))
            }
        },
        confirmButton = {
            TextButton(onClick = {
                InsertOps.updateShape(st, o.color, o.fill, o.heightPt, o.widthPct / 100f, o.label, o.labelColor, o.labelFont)
                ShapeEdit.start = -1
            }) { Text("Apply / لاگو کریں") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { InsertOps.deleteShape(st); ShapeEdit.start = -1 }) { Text("Delete / ہٹائیں", color = Color(0xFFD32F2F)) }
                TextButton(onClick = { ShapeEdit.start = -1 }) { Text("Cancel") }
            }
        }
    )
}
