package com.msf.documentwriter

import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.widget.EditText
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Marker on a footnote that was "picked up" (the text stays where it is until it is dropped, so nothing can get lost). */
class FootHold

/**
 * Footnotes (حوالہ جات) under the writer's control.
 * A footnote block is a thin rule line followed by lines that start with their number; it is ordinary, editable text.
 * The writer chooses WHERE a new footnote goes (under its paragraph, bottom / top of the page, end of the document, at the cursor)
 * and can move an existing footnote block later (page top / bottom, previous / next page, document end, one paragraph up / down,
 * or "pick up" and "drop here" at any place of the writer's choice).
 */
object FootOps {
    const val RULE = "────────"

    /** Where a new footnote is put. */
    val PLACES = listOf(
        "Under this paragraph / اسی پیراگراف کے نیچے",
        "Bottom of this page / صفحے کے آخر میں",
        "Top of this page / صفحے کے شروع میں",
        "End of document / دستاویز کے آخر میں",
        "Here, at the cursor / یہیں کرسر کی جگہ"
    )

    /** Where an existing footnote block can be moved. */
    val MOVES = listOf(
        "Bottom of this page / صفحے کے آخر میں",
        "Top of this page / صفحے کے شروع میں",
        "End of document / دستاویز کے آخر میں",
        "One paragraph up / ایک پیراگراف اوپر",
        "One paragraph down / ایک پیراگراف نیچے",
        "Bottom of the previous page / پچھلے صفحے کے آخر میں",
        "Top of the next page / اگلے صفحے کے شروع میں",
        "Pick up, then drop it where I put the cursor / اٹھائیں، پھر کرسر کی جگہ رکھیں"
    )
    /** Index of the "Pick up" entry of [MOVES]. */
    const val PICK = 7

    private fun lineStart(s: String, p: Int): Int = if (p <= 0) 0 else s.lastIndexOf('\n', p - 1) + 1
    private fun lineEnd(s: String, p: Int): Int { val i = s.indexOf('\n', p.coerceIn(0, s.length)); return if (i < 0) s.length else i + 1 }
    private fun lineText(s: String, a: Int): String = s.substring(a, lineEnd(s, a)).trimEnd('\n')
    private fun startsWithDigit(l: String): Boolean = l.trimStart().firstOrNull()?.isDigit() == true

    /** Start and end (exclusive, after the last newline) of the footnote block that holds [pos]; null when [pos] is not in one. */
    fun blockAt(s: String, pos: Int): IntRange? {
        var ls = lineStart(s, pos.coerceIn(0, s.length))
        var n = 0
        while (lineText(s, ls).trim() != RULE) {
            if (ls == 0 || ++n > 40) return null
            ls = lineStart(s, ls - 1)
        }
        var e = lineEnd(s, ls)
        while (e < s.length && startsWithDigit(lineText(s, e))) e = lineEnd(s, e)
        val inside = pos >= ls && (pos < e || (pos == e && e == s.length))
        return if (inside) ls until e else null
    }

    private fun nextNumber(s: String): Int {
        var count = 0
        var inBlock = false
        var a = 0
        while (a < s.length) {
            val l = lineText(s, a)
            if (l.trim() == RULE) inBlock = true
            else if (inBlock && startsWithDigit(l)) count++
            else inBlock = false
            a = lineEnd(s, a)
        }
        return count + 1
    }

    // ───────── pages. These are character offsets of the editor's page starts: they go out of date as soon as the text is changed,
    // so every caller reads them BEFORE it changes anything and moves them by hand afterwards.

    private fun pages(et: EditText, len: Int): List<Int> {
        val starts = (et.parent as? PageSheets)?.breakStarts ?: emptyList()
        return (listOf(0) + starts).filter { it in 0..len }.distinct().sorted()
    }
    private fun pageIndex(ps: List<Int>, pos: Int): Int { var k = 0; for (i in ps.indices) if (ps[i] <= pos) k = i; return k }
    /** End of page [idx]: where the next page starts (a page-break line belongs to the page before it, so the end is in front of it). */
    private fun pageEndAt(s: String, ps: List<Int>, idx: Int): Int {
        var t = ps.getOrNull(idx + 1) ?: s.length
        if (t > 0 && t < s.length) {
            val ls = lineStart(s, t - 1)
            if (s.substring(ls, t).contains(PAGE_BREAK)) t = ls
        }
        return t.coerceAtLeast(ps[idx])
    }

    private fun styled(text: String, rule: Boolean): SpannableStringBuilder {
        val b = SpannableStringBuilder(text)
        if (rule) {
            b.setSpan(ForegroundColorSpan(0xFF8A8A8A.toInt()), 0, b.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            b.setSpan(AbsoluteSizeSpan(8, true), 0, b.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        } else {
            b.setSpan(AbsoluteSizeSpan((Doc.baseSize * 0.8f).roundToInt().coerceAtLeast(9), true), 0, b.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return b
    }

    /** Puts [piece] at [at0] on lines of its own and returns where it starts. */
    private fun put(et: EditText, at0: Int, piece: CharSequence): Int {
        val e = et.text
        var at = at0.coerceIn(0, e.length)
        if (at > 0 && e[at - 1] != '\n') { e.insert(at, "\n"); at++ }
        e.insert(at, piece)
        return at
    }

    /** The footnote lines without the thin rule line in front of them. */
    private fun notesOf(p: CharSequence): CharSequence {
        val s = p.toString()
        val nl = s.indexOf('\n')
        return if (nl >= 0 && s.substring(0, nl).trim() == RULE) p.subSequence(nl + 1, p.length) else p
    }

    /**
     * The block [fa]..[fb] was just put at the END of its page. A page is always full, so the block would not fit: its lines run over
     * onto the next page (that was the "goes to the wrong place" bug). Word solves this by pushing the last lines of the page down.
     * Here: measure the block in the real editor and find the line of the page in front of which the block (plus everything above
     * it) still fits on the page; the lines after that line then flow to the next page, below the block.
     * Returns the offset of that line start, or -1 when the block can stay where it is.
     */
    private fun fitTarget(et: EditText, ps: Int, fa: Int, fb: Int, minAt: Int): Int {
        val lay = et.layout ?: return -1
        val sheets = et.parent as? PageSheets ?: return -1
        val e = et.text
        val room = sheets.pageRoomPx()
        if (room <= 0f || fb <= fa || fa > e.length) return -1
        val fl0 = lay.getLineForOffset(fa)
        val fl1 = lay.getLineForOffset((fb - 1).coerceAtLeast(fa))
        val h = (lay.getLineBottom(fl1) - lay.getLineTop(fl0)).toFloat()
        val l0 = lay.getLineForOffset(ps.coerceIn(0, e.length))
        if (fl0 <= l0) return -1
        val push = HashMap<Int, Int>()
        for (sp in e.getSpans(0, e.length, PagePushSpan::class.java)) push[e.getSpanStart(sp)] = sp.d
        // cum[k] = height of the lines l0 until l0 + k (the first line of a page carries a push that is not part of its text)
        val cum = FloatArray(fl0 - l0 + 1)
        for (i in l0 until fl0) {
            val nat = (lay.getLineBottom(i) - lay.getLineTop(i) - (push[lay.getLineStart(i)] ?: 0)).coerceAtLeast(1).toFloat()
            cum[i - l0 + 1] = cum[i - l0] + nat
        }
        val slack = 2f
        var pick = fl0
        var found = false
        var i = fl0
        while (i >= l0) {
            if (i < fl0 && lay.getLineStart(i) < minAt) break
            pick = i
            if (cum[i - l0] + h + slack <= room) { found = true; break }
            i--
        }
        // nothing fits: when the block must stay below its reference keep it right under the reference line, else leave it at the end
        if (!found && minAt <= ps) return -1
        if (pick >= fl0) return -1
        var t = lay.getLineStart(pick)
        // never cut another footnote block in two
        val bk = blockAt(e.toString(), t)
        if (bk != null && t > bk.first) t = bk.first
        return t
    }

    /**
     * Puts the footnote block [piece0] so that it is the last thing of the page [ps0]..[pe0] and still on that page.
     * A footnote block that already ends the page takes the new notes (the whole block is placed again).
     * [minAt] is the lowest offset it may go to (its reference must stay above it). Returns where the block starts.
     */
    private fun putBottom(et: EditText, ps0: Int, pe0: Int, piece0: CharSequence, minAt: Int): Int {
        val e = et.text
        val ps = ps0.coerceIn(0, e.length)
        var pe = pe0.coerceIn(ps, e.length)
        var piece: CharSequence = piece0
        val b = blockEndingAt(e.toString(), pe)
        if (b != null && b.first >= ps) {
            val old = cleanCopy(e.subSequence(b.first, pe))
            old.append(notesOf(piece0))
            piece = old
            e.delete(b.first, pe)
            pe = b.first
        }
        var at = pe
        if (at > 0 && e[at - 1] != '\n') { e.insert(at, "\n"); at++ }
        val fa = at
        e.insert(at, piece)
        val fb = at + piece.length
        var target = -1
        try { target = fitTarget(et, ps, fa, fb, minAt.coerceIn(ps, pe)) } catch (_: Throwable) { target = -1 }
        if (target in 0 until pe) {
            e.delete(pe, fb)            // the block and the line break that was put in front of it
            return put(et, target, piece)
        }
        return fa
    }

    /** A new footnote: a raised number at the cursor and "number  text" in a footnote block at the chosen place. */
    fun add(et: EditText, text: String, place: Int): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        val e = et.text
        val n = nextNumber(e.toString())
        val pos = InsertOps.pos(et)
        // the page of the cursor is looked up BEFORE the number is typed in; the number shifts every offset behind the cursor
        // (the old code used the old page ends on the new text and put the footnote a few letters before the end of the last line)
        val s0 = e.toString()
        val pl = pages(et, s0.length)
        val pIdx = pageIndex(pl, pos)
        val pStart = pl[pIdx]
        val pEnd0 = pageEndAt(s0, pl, pIdx)
        val ref = n.toString()
        e.insert(pos, ref)
        e.setSpan(ScriptSpan(true), pos, pos + ref.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val after = pos + ref.length
        val pEnd = (pEnd0 + ref.length).coerceAtMost(e.length)
        val s = e.toString()
        val line = SpannableStringBuilder(styled("$n  $t\n", false))
        val blk = SpannableStringBuilder()
        blk.append(styled(RULE + "\n", true)).append(line)
        if (place == 1) {
            val lay = et.layout
            val minAt = if (lay != null && e.isNotEmpty()) lay.getLineEnd(lay.getLineForOffset(after.coerceIn(0, e.length - 1))).coerceAtMost(e.length) else after
            putBottom(et, pStart, pEnd, blk, minAt)
        } else {
            val target = when (place) {
                0 -> lineEnd(s, after)
                2 -> pStart
                3 -> s.length
                else -> after
            }
            val existing = if (place == 0 || place == 3) blockEndingAt(s, target) else null
            // the place already has a footnote block just before it: add this note to it
            if (existing != null) put(et, target, line) else put(et, target, blk)
        }
        et.setSelection(after.coerceIn(0, et.text.length))
        Doc.dirty = true
        return true
    }

    /** The footnote block whose last line ends exactly at [t], if any. */
    private fun blockEndingAt(s: String, t: Int): IntRange? {
        if (t <= 0 || t > s.length || s[t - 1] != '\n') return null
        val b = blockAt(s, t - 1) ?: return null
        return if (b.last + 1 == t) b else null
    }

    /** The lines to move: the lines selected, or the footnote block that holds the cursor (null = neither). */
    private fun rangeToMove(et: EditText, s: String): IntRange? {
        val a = minOf(et.selectionStart, et.selectionEnd).coerceIn(0, s.length)
        val b = maxOf(et.selectionStart, et.selectionEnd).coerceIn(0, s.length)
        if (b > a) {
            val st = lineStart(s, a)
            val en = lineEnd(s, maxOf(a, b - 1))
            return if (en > st) st until en else null
        }
        return blockAt(s, a)
    }

    /** Moves the footnote block under the cursor (or the lines selected) to [where] (see [MOVES]). */
    fun move(et: EditText, where: Int): Boolean {
        val e = et.text
        val s = e.toString()
        val r = rangeToMove(et, s) ?: return false
        val start = r.first
        val end = r.last + 1
        if (end <= start) return false
        val pl = pages(et, s.length)
        val lastIdx = pageIndex(pl, (end - 1).coerceAtLeast(start))

        if (where == 0 || where == 5) {
            // the bottom of a page: the block is put there so that it still fits on that page (see [putBottom])
            val idx = if (where == 0) lastIdx else pageIndex(pl, start) - 1
            if (idx < 0) return false
            val pStart = pl[idx]
            val pEnd = pageEndAt(s, pl, idx)
            if (where == 0 && end == pEnd) return false        // it is already the last thing of its page
            val piece = cleanCopy(e.subSequence(start, end))
            if (piece.isEmpty() || piece[piece.length - 1] != '\n') piece.append("\n")
            val len = end - start
            e.delete(start, end)
            val shifted = { x: Int -> if (x <= start) x else if (x >= end) x - len else start }
            val at = putBottom(et, shifted(pStart), shifted(pEnd), piece, shifted(pStart))
            et.setSelection((at + 1).coerceIn(0, et.text.length))
            Doc.dirty = true
            return true
        }

        var target = when (where) {
            1 -> pl[pageIndex(pl, start)]
            2 -> s.length
            3 -> {
                if (start <= 0) return false
                var t = lineStart(s, start - 1)
                while (t > 0 && lineText(s, t).isBlank()) t = lineStart(s, t - 1)      // blank lines and page-break lines do not count
                val up = blockAt(s, t)
                if (up != null) t = up.first
                t
            }
            4 -> {
                var a2 = end
                while (a2 < s.length && lineText(s, a2).isBlank()) a2 = lineEnd(s, a2)
                if (a2 >= s.length) return false
                val nb = blockAt(s, a2)
                if (nb != null) nb.last + 1 else lineEnd(s, a2)
            }
            6 -> { val i = lastIdx + 1; if (i >= pl.size) return false; pl[i] }
            else -> return false
        }
        if (target in start..end) return false
        val piece = cleanCopy(e.subSequence(start, end))
        if (piece.isEmpty() || piece[piece.length - 1] != '\n') piece.append("\n")
        val len = end - start
        e.delete(start, end)
        if (target > start) target -= len
        val at = put(et, target, piece)
        et.setSelection((at + 1).coerceIn(0, et.text.length))
        Doc.dirty = true
        return true
    }

    /** "Pick up": marks the footnote block under the cursor (or the lines selected); [drop] puts it where the cursor is then. */
    fun pick(et: EditText): Boolean {
        val e = et.text
        val r = rangeToMove(et, e.toString()) ?: return false
        for (h in e.getSpans(0, e.length, FootHold::class.java)) e.removeSpan(h)
        e.setSpan(FootHold(), r.first, r.last + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return true
    }

    /** Puts the picked-up footnote at the cursor. 0 = done, 1 = nothing was picked up, 2 = the cursor is inside the picked-up footnote itself. */
    fun drop(et: EditText): Int {
        val e = et.text
        val h = e.getSpans(0, e.length, FootHold::class.java).firstOrNull() ?: return 1
        val a = e.getSpanStart(h)
        val b = e.getSpanEnd(h)
        if (a < 0 || b <= a) { e.removeSpan(h); return 1 }
        var c = InsertOps.pos(et)
        if (c in a..b) return 2
        e.removeSpan(h)
        val piece = cleanCopy(e.subSequence(a, b))
        if (piece.isEmpty() || piece[piece.length - 1] != '\n') piece.append("\n")
        val len = b - a
        e.delete(a, b)
        if (c > b) c -= len
        // never into the middle of another footnote block: behind it
        val inBlock = blockAt(e.toString(), c)
        if (inBlock != null && c > inBlock.first) c = inBlock.last + 1
        val at = put(et, c, piece)
        et.setSelection((at + 1).coerceIn(0, et.text.length))
        Doc.dirty = true
        return 0
    }
}

@Composable
private fun PlaceList(items: List<String>, sel: Int, onPick: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        items.forEachIndexed { i, s ->
            Row(Modifier.fillMaxWidth().clickable { onPick(i) }.padding(vertical = 9.dp)) {
                Text(if (i == sel) "◉  " else "○  ", fontSize = 17.sp)
                Text(s, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun FootnoteDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var place by remember { mutableIntStateOf(1) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Footnote / حوالہ") },
        text = {
            Column {
                OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Footnote text / حوالے کا متن") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                PlaceList(FootOps.PLACES, place) { place = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val et = InsertBridge.et
                if (et == null) toast(ctx, "پہلے دستاویز میں کرسر رکھیں / Tap inside the document first")
                else if (!FootOps.add(et, text, place)) toast(ctx, "حوالے کا متن لکھیں / Write the footnote text")
                else { onClose(); toast(ctx, "حوالہ شامل ہو گیا؛ اس کا متن عام متن کی طرح بدل سکتے ہیں / Footnote added; edit it like normal text") }
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun FootMoveDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var where by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Move footnote / حوالہ منتقل کریں") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("کرسر حوالے کے اندر رکھیں (یا حوالے کی سطریں منتخب کریں)۔\nPut the cursor inside the footnote (or select its lines).", fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                PlaceList(FootOps.MOVES, where) { where = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val et = InsertBridge.et
                if (et == null) toast(ctx, "پہلے دستاویز میں کرسر رکھیں / Tap inside the document first")
                else if (where == FootOps.PICK) {
                    if (FootOps.pick(et)) {
                        onClose()
                        toast(ctx, "حوالہ اٹھا لیا۔ اب کرسر اس جگہ رکھیں جہاں چاہیے، پھر Insert ← \"Drop Footnote Here / حوالہ یہاں رکھیں\" دبائیں / Footnote picked up: put the cursor where you want it, then Insert → Drop Footnote Here")
                    } else toast(ctx, "کرسر کسی حوالے کے اندر نہیں / Cursor is not inside a footnote")
                }
                else if (!FootOps.move(et, where)) toast(ctx, "کرسر کسی حوالے کے اندر نہیں، یا وہ پہلے ہی اسی جگہ ہے / Cursor is not inside a footnote, or it is already there")
                else onClose()
            }) { Text("Move") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
