package com.msf.documentwriter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.text.Editable
import android.text.Spanned
import android.text.style.ReplacementSpan

/** Page border designs (assets/pages) and the "new page" marker used inside the text. */
object PageDesigns {
    /** mx / mt / mb = text margins as a fraction of the page width / height, chosen to stay inside the border. */
    class Spec(val id: Int, val en: String, val ur: String, val asset: String, val mx: Float, val mt: Float, val mb: Float)

    val all: List<Spec> = listOf(
        Spec(1, "Golden Border", "سنہری بارڈر", "pages/page_design_1.jpg", 0.105f, 0.125f, 0.125f),
        Spec(2, "Islamic Frame", "اسلامی فریم", "pages/page_design_2.jpg", 0.105f, 0.150f, 0.150f),
        Spec(3, "Black Ornament", "سیاہ آرائشی فریم", "pages/page_design_3.jpg", 0.110f, 0.080f, 0.080f),
        Spec(4, "Thin Gold Line", "باریک سنہری لکیر", "pages/page_design_4.jpg", 0.110f, 0.085f, 0.085f),
        Spec(5, "Brown Flowers", "بھورے پھول", "pages/page_design_5.jpg", 0.130f, 0.120f, 0.120f),
        Spec(6, "Autumn Leaves", "خزاں کے پتے", "pages/page_design_6.jpg", 0.120f, 0.110f, 0.120f),
        Spec(7, "Blue Roses", "نیلے گلاب", "pages/page_design_7.jpg", 0.100f, 0.110f, 0.150f),
        Spec(8, "Navy Waves", "گہرا نیلا فریم", "pages/page_design_8.jpg", 0.080f, 0.080f, 0.080f),
        Spec(9, "Blue Corners", "نیلے کونے", "pages/page_design_9.jpg", 0.100f, 0.080f, 0.080f),
        Spec(10, "Rose Gold Frame", "گلابی سنہری فریم", "pages/page_design_10.jpg", 0.200f, 0.140f, 0.140f),
        Spec(11, "Pink Watercolor", "گلابی واٹر کلر", "pages/page_design_11.jpg", 0.120f, 0.130f, 0.150f),
        Spec(12, "Gold Scroll Frame", "سنہری آرائشی فریم", "pages/page_design_12.jpg", 0.130f, 0.150f, 0.150f),
        Spec(13, "Greek Border", "یونانی بارڈر", "pages/page_design_13.jpg", 0.140f, 0.220f, 0.220f),
        Spec(14, "Yellow Line Frame", "پیلا لائن فریم", "pages/page_design_14.jpg", 0.130f, 0.100f, 0.100f),
        Spec(15, "Black Calligraphy", "سیاہ خطاطی فریم", "pages/page_design_15.jpg", 0.150f, 0.100f, 0.100f),
        Spec(16, "Black Top-Bottom", "سیاہ اوپر نیچے آرائش", "pages/page_design_16.jpg", 0.160f, 0.150f, 0.150f),
        Spec(17, "Navy Flowers", "گہرے نیلے پھول", "pages/page_design_17.jpg", 0.130f, 0.150f, 0.150f),
        Spec(18, "Brown Classic", "بھورا کلاسک فریم", "pages/page_design_18.jpg", 0.110f, 0.090f, 0.090f),
        Spec(19, "Beige Scroll", "بیج آرائشی صفحہ", "pages/page_design_19.jpg", 0.100f, 0.140f, 0.140f),
        Spec(20, "Lace Gold Frame", "سنہری لیس فریم", "pages/page_design_20.jpg", 0.170f, 0.150f, 0.150f),
        Spec(21, "Brown Gold Floral", "بھورا سنہری پھول", "pages/page_design_21.jpg", 0.130f, 0.130f, 0.130f),
        Spec(22, "Art Deco Gold", "آرٹ ڈیکو سنہری", "pages/page_design_22.jpg", 0.160f, 0.150f, 0.150f),
        Spec(23, "Gold Leaves", "سنہری پتے", "pages/page_design_23.jpg", 0.110f, 0.100f, 0.100f),
        Spec(24, "Colour Corners", "رنگین کونے", "pages/page_design_24.jpg", 0.110f, 0.100f, 0.100f)
    )

    /** Width / height of the page sheet (A4). */
    const val RATIO = 0.7071f

    /** The built-in designs and the ones the user chose from the gallery / File Manager (see [CustomDesigns]). */
    fun spec(id: Int): Spec? = all.firstOrNull { it.id == id } ?: CustomDesigns.spec(id)

    private val cache = HashMap<Int, Bitmap?>()

    fun bitmap(c: Context, id: Int): Bitmap? {
        val s = spec(id) ?: return null
        if (cache.containsKey(id)) return cache[id]
        val b = try {
            if (CustomDesigns.isCustom(id)) BitmapFactory.decodeFile(s.asset)
            else c.applicationContext.assets.open(s.asset).use { BitmapFactory.decodeStream(it) }
        } catch (e: Throwable) { null }
        cache[id] = b
        return b
    }

    fun forget(id: Int) { cache.remove(id) }

    fun bytes(c: Context, id: Int): ByteArray? {
        val s = spec(id) ?: return null
        return try {
            if (CustomDesigns.isCustom(id)) java.io.File(s.asset).readBytes()
            else c.applicationContext.assets.open(s.asset).use { it.readBytes() }
        } catch (e: Throwable) { null }
    }
}

/** Page break character (form feed). It sits alone on its own line and is drawn as a full-width "page ends / next page" band. */
const val PAGE_BREAK = '\u000C'

/** [n] = number of the page that ends here. */
class PageBreakSpan(private val n: Int = 1) : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int {
        if (fm != null) { fm.ascent = -46; fm.descent = 46; fm.top = -46; fm.bottom = 46 }
        return android.content.res.Resources.getSystem().displayMetrics.widthPixels
    }

    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        val cb = canvas.clipBounds
        val left = if (cb.width() > 10) cb.left.toFloat() else x
        val right = if (cb.width() > 10) cb.right.toFloat() else x + 600f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xFFD9E2F1.toInt()
        canvas.drawRect(left, top + 8f, right, bottom - 8f, p)
        p.color = 0xFF7F9CCB.toInt()
        p.strokeWidth = 3f
        canvas.drawLine(left, top + 8f, right, top + 8f, p)
        canvas.drawLine(left, bottom - 8f, right, bottom - 8f, p)
        p.color = 0xFF0B4DB8.toInt()
        p.textSize = paint.textSize * 0.8f
        p.textAlign = Paint.Align.CENTER
        canvas.drawText("▲ صفحہ $n ختم   |   ▼ صفحہ ${n + 1} شروع", (left + right) / 2f, (top + bottom) / 2f + p.textSize / 3f, p)
    }
}

/** Light background + rules for the lines of a table (editor only; never exported). */
class TableRowSpan(val fill: Int = 0xFFEAF1FF.toInt(), val rule: Int = 0xFF7F9CCB.toInt()) : android.text.style.LineBackgroundSpan {
    /** Width of the table in pixels (set by [TableGrid]); -1 = the whole text width. */
    var width = -1f

    override fun drawBackground(
        c: Canvas, p: Paint, left: Int, right: Int, top: Int, baseline: Int, bottom: Int,
        text: CharSequence, start: Int, end: Int, lnum: Int
    ) {
        var l = left.toFloat()
        var r = right.toFloat()
        if (width > 0f) {
            if (TableGrid.rtl) l = maxOf(l, r - width) else r = minOf(r, l + width)
        }
        val t0 = (top + RowPush.at(text, start)).toFloat()   // the page push above the row is not part of the row
        val q = Paint()
        q.color = fill
        c.drawRect(l, t0, r, bottom.toFloat(), q)
        q.color = rule
        q.strokeWidth = 2f
        c.drawLine(l, t0, r, t0, q)
        c.drawLine(l, bottom.toFloat(), r, bottom.toFloat(), q)
    }
}

object PageBreaks {
    /** Re-draws the page-break bands (numbered) and table-row backgrounds. Needed after loading text and after edits. */
    fun decorate(e: Editable) {
        for (s in e.getSpans(0, e.length, PageBreakSpan::class.java)) e.removeSpan(s)
        for (s in e.getSpans(0, e.length, TableRowSpan::class.java)) e.removeSpan(s)
        val str = e.toString()
        var n = 0
        for (i in 0 until str.length) {
            if (str[i] == PAGE_BREAK) { n++; e.setSpan(PageBreakSpan(n), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
        }
        var ps = 0
        val deco = TableDeco(e)
        while (ps <= str.length) {
            val nl = str.indexOf('\n', ps)
            val pe = if (nl < 0) str.length else nl
            deco.line(ps, pe, str.substring(ps, pe))
            if (nl < 0) break
            ps = nl + 1
        }
    }

    /** Changes whenever the number of page breaks or table lines changes (so decorate() is only needed then). */
    fun signature(e: CharSequence): Int {
        val str = e.toString()
        var breaks = 0
        for (ch in str) if (ch == PAGE_BREAK) breaks++
        var rows = 0
        var ps = 0
        while (ps <= str.length) {
            val nl = str.indexOf('\n', ps)
            val pe = if (nl < 0) str.length else nl
            if (pe > ps && Tables.isRowRange(str, ps, pe)) rows++
            if (nl < 0) break
            ps = nl + 1
        }
        return breaks * 100003 + rows
    }

    /** Inserts [text] at [pos] on its own lines; returns the new cursor position. */
    fun insertBlock(e: Editable, pos: Int, text: String, cursorInside: Int): Int = TableGuard.free {
        val p = outOfTable(e, pos.coerceIn(0, e.length))
        val pre = if (p > 0 && e[p - 1] != '\n') "\n" else ""
        e.insert(p, pre + text)
        decorate(e)
        (p + pre.length + cursorInside).coerceIn(0, e.length)
    }

    /** A block is never put inside a table: when [pos] is in a table row it moves to the end of that table. */
    fun outOfTable(e: Editable, pos: Int): Int = TableOps.tableRange(e, pos)?.second ?: pos

    fun insertAt(e: Editable, pos: Int): Int = TableGuard.free {
        val p = outOfTable(e, pos.coerceIn(0, e.length))
        e.insert(p, "\n$PAGE_BREAK\n")
        decorate(e)
        p + 3
    }

    /** An empty page of its own between the previous and the next text. */
    fun insertBlank(e: Editable, pos: Int): Int = TableGuard.free {
        val p = outOfTable(e, pos.coerceIn(0, e.length))
        e.insert(p, "\n$PAGE_BREAK\n$PAGE_BREAK\n")
        decorate(e)
        p + 5
    }
}

/**
 * Page designs chosen by the user from the phone's Gallery or File Manager. The picture is cut to the page shape (A4),
 * saved inside the app (so it keeps working when the original file is moved) and gets an id from [BASE] upwards.
 * The text margins are chosen when the design is added (small / medium / large).
 */
object CustomDesigns {
    const val BASE = 100
    private const val KEY = "custom_designs"
    private val specs = LinkedHashMap<Int, PageDesigns.Spec>()
    private var loaded = false

    fun isCustom(id: Int) = id >= BASE

    private fun dir(c: Context): java.io.File = java.io.File(c.applicationContext.filesDir, "custom_designs").also { it.mkdirs() }

    fun init(c: Context) {
        if (loaded) return
        loaded = true
        specs.clear()
        for (line in Prefs.str(c, KEY, "").split('\n')) {
            val p = line.split(';')
            if (p.size < 5) continue
            val id = p[0].toIntOrNull() ?: continue
            val f = java.io.File(dir(c), "design_$id.jpg")
            if (!f.exists()) continue
            val mx = p[1].toFloatOrNull() ?: continue
            val mt = p[2].toFloatOrNull() ?: continue
            val mb = p[3].toFloatOrNull() ?: continue
            specs[id] = PageDesigns.Spec(id, p[4], p[4], f.absolutePath, mx, mt, mb)
        }
    }

    private fun save(c: Context) {
        Prefs.setStr(c, KEY, specs.values.joinToString("\n") { "${it.id};${it.mx};${it.mt};${it.mb};${it.en.replace(';', ' ').replace('\n', ' ')}" })
    }

    fun spec(id: Int): PageDesigns.Spec? = specs[id]
    
    fun list(): List<PageDesigns.Spec> = specs.values.toList()

    /** size: 0 small, 1 medium, 2 large text margins. Returns the new design (or null if the picture could not be read). */
    fun add(c: Context, u: android.net.Uri, size: Int): PageDesigns.Spec? {
        init(c)
        return try {
            val src = decodeBitmap(c, u, 2400) ?: return null
            val tw = 1240
            val th = (tw / PageDesigns.RATIO).toInt()
            // "cover": fill the whole page, cut what does not fit from the sides / top and bottom
            val sc = maxOf(tw.toFloat() / src.width, th.toFloat() / src.height)
            val sw = src.width * sc
            val sh = src.height * sc
            val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
            val cv = Canvas(out)
            cv.drawColor(android.graphics.Color.WHITE)
            cv.drawBitmap(src, null, RectF((tw - sw) / 2f, (th - sh) / 2f, (tw + sw) / 2f, (th + sh) / 2f), Paint(Paint.FILTER_BITMAP_FLAG))
            var id = BASE
            while (specs.containsKey(id)) id++
            val f = java.io.File(dir(c), "design_$id.jpg")
            java.io.FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            out.recycle(); src.recycle()
            val (mx, mt, mb) = when (size) { 0 -> Triple(0.07f, 0.06f, 0.06f); 2 -> Triple(0.18f, 0.15f, 0.15f); else -> Triple(0.12f, 0.10f, 0.10f) }
            val sp = PageDesigns.Spec(id, "My design ${id - BASE + 1}", "میرا ڈیزائن ${id - BASE + 1}", f.absolutePath, mx, mt, mb)
            specs[id] = sp
            PageDesigns.forget(id)
            save(c)
            sp
        } catch (e: Throwable) { null }
    }

    fun remove(c: Context, id: Int) {
        init(c)
        specs.remove(id)
        try { java.io.File(dir(c), "design_$id.jpg").delete() } catch (_: Throwable) {}
        PageDesigns.forget(id)
        DesignThumbs.forget(id)
        save(c)
    }
}
