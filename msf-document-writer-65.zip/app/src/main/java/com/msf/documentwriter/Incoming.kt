package com.msf.documentwriter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/**
 * Runs heavy work (saving PDF / Word, copying files) OFF the main thread so the app never freezes.
 * While it runs, App() shows a small "please wait" dialog (see [Work.label]).
 */
object Work {
    private val h = Handler(Looper.getMainLooper())
    var label by mutableStateOf<String?>(null)

    /** Updates the text of the "please wait" dialog from any thread. */
    fun progress(msg: String) { h.post { if (label != null) label = msg } }

    fun <T> run(msg: String, work: () -> T?, done: (T?) -> Unit) {
        if (label != null) return            // one job at a time: ignore double taps
        label = msg
        Thread(null, {
            val r = try { work() } catch (_: Throwable) { null }
            h.post {
                label = null
                try { done(r) } catch (_: Throwable) {}
            }
        }, "msf-work", 16L * 1024 * 1024).start()
    }
}

/** Files / text that arrive from other apps (Share → MSF Document Writer, or "Open with" from a File Manager). */
object Incoming {
    var pending by mutableStateOf<File?>(null)
    var text by mutableStateOf<String?>(null)

    @Suppress("DEPRECATION")
    private fun streamOf(i: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else i.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri

    @Suppress("DEPRECATION")
    fun handle(c: Context, i: Intent?) {
        if (i == null) return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> streamOf(i)
            Intent.ACTION_SEND_MULTIPLE -> try {
                i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.firstOrNull()
            } catch (_: Throwable) { null }
            else -> null
        }
        val txt = if (i.action == Intent.ACTION_SEND && uri == null) i.getStringExtra(Intent.EXTRA_TEXT) else null
        if (uri == null && txt.isNullOrEmpty()) return
        i.action = Intent.ACTION_MAIN        // handle each incoming intent only once
        if (uri == null) { text = txt; return }
        val app = c.applicationContext
        Work.run("فائل کھل رہی ہے… / Opening file…", { Store.importUri(app, uri) }) { f ->
            if (f == null) toast(app, "یہ فائل سپورٹڈ نہیں / This file type is not supported")
            else pending = f
        }
    }
}

/** "Open from File Manager": pick any file with the phone's file manager and open it directly. */
@androidx.compose.runtime.Composable
fun rememberOpenFromManager(): () -> Unit {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val l = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { u ->
        if (u != null) {
            val app = ctx.applicationContext
            Work.run("فائل کھل رہی ہے… / Opening file…", { Store.importUri(app, u) }) { f ->
                if (f == null) toast(app, "یہ فائل سپورٹڈ نہیں / This file type is not supported") else Incoming.pending = f
            }
        }
    }
    return { try { l.launch(arrayOf("*/*")) } catch (_: Throwable) { toast(ctx, "فائل مینیجر نہیں ملا / No file manager found") } }
}

/** "Open Word (.docx)": one tap -> pick a Word file -> it is read in the background and opens on the Blank Page (all of it). */
@androidx.compose.runtime.Composable
fun rememberOpenDocx(): () -> Unit {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val l = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { u ->
        if (u != null) {
            val app = ctx.applicationContext
            Work.run("فائل کھل رہی ہے… / Opening file…", { Store.importUri(app, u) }) { f ->
                if (f == null) toast(app, "یہ فائل سپورٹڈ نہیں / This file type is not supported") else Incoming.pending = f
            }
        }
    }
    return {
        try { l.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword")) }
        catch (_: Throwable) { toast(ctx, "فائل مینیجر نہیں ملا / No file manager found") }
    }
}

const val APP_VER = "1.0.52"

/**
 * Very fast, simple Word reader: only the text (paragraphs, tabs, line / page breaks). It walks the XML once with
 * indexOf - no regular expressions - so even a huge file is read in a second or two.
 */
object FastDocx {
    private fun unesc(s: String): String =
        if (s.indexOf('&') < 0) s else s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

    fun text(f: File): String {
        val xml = java.util.zip.ZipFile(f).use { z ->
            val e = z.getEntry("word/document.xml") ?: return ""
            z.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
        }
        val n = xml.length
        val sb = StringBuilder(n / 3)
        var i = 0
        var first = true
        while (i < n) {
            val lt = xml.indexOf('<', i)
            if (lt < 0 || lt + 5 >= n) break
            if (xml[lt + 1] != 'w' || xml[lt + 2] != ':') { i = lt + 1; continue }
            val d = xml[lt + 4]
            when (xml[lt + 3]) {
                'p' -> {
                    if (d == '>' || d == ' ' || d == '/') { if (!first) sb.append('\n'); first = false }
                    i = lt + 4
                }
                't' -> {
                    if (d == '>' || d == ' ') {
                        val gt = xml.indexOf('>', lt)
                        if (gt < 0) break
                        if (xml[gt - 1] == '/') i = gt + 1
                        else {
                            val end = xml.indexOf("</w:t>", gt)
                            if (end < 0) break
                            sb.append(unesc(xml.substring(gt + 1, end)))
                            i = end + 6
                        }
                    } else if (xml.startsWith("<w:tab/>", lt)) { sb.append('\t'); i = lt + 8 } else i = lt + 4
                }
                'b' -> {
                    if (xml.startsWith("<w:br/>", lt) || xml.startsWith("<w:br ", lt)) {
                        val gt = xml.indexOf('>', lt)
                        if (gt < 0) break
                        sb.append(if (xml.substring(lt, gt).contains("page")) PAGE_BREAK else '\n')
                        i = gt + 1
                    } else i = lt + 4
                }
                else -> i = lt + 4
            }
        }
        return sb.toString()
    }
}
