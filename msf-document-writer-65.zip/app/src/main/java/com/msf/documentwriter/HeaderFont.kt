package com.msf.documentwriter

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Lets the person choose the font of the running page header (menu: "Header font"). */
object HeaderFont {
    var show by mutableStateOf(false)
    /** Set by the page view so it redraws after a font is picked. */
    var onChange: (() -> Unit)? = null
}

@Composable
fun HeaderFontDialog() {
    if (!HeaderFont.show) return
    val list = listOf("" to "Same as document / دستاویز جیسا") + Fonts.all().map { it.second to it.first }
    AlertDialog(
        onDismissRequest = { HeaderFont.show = false },
        confirmButton = { TextButton(onClick = { HeaderFont.show = false }) { Text("Close") } },
        title = { Text("Header font / ہیڈر فونٹ") },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(list) { item ->
                    val fam = item.first
                    val cur = (Doc.headerFont ?: Doc.font ?: "") == fam
                    Text(
                        item.second + (if (cur) "  ✓" else ""),
                        Modifier.fillMaxWidth().clickable {
                            Doc.headerFont = if (fam.isEmpty()) Doc.font else fam
                            HeaderFont.onChange?.invoke()
                            HeaderFont.show = false
                        }.padding(vertical = 12.dp),
                        fontSize = 16.sp
                    )
                }
            }
        }
    )
}
