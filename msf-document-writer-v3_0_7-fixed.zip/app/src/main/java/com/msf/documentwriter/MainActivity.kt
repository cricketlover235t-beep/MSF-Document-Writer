package com.msf.documentwriter

import android.app.Activity
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.unit.dp

class MainActivity : FragmentActivity() {
    private val credL = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) Lock.unlocked = true
    }

    private fun credential() {
        val i = Lock.credentialIntent(this)
        if (i == null) Lock.unlocked = true else credL.launch(i)
    }

    private fun fingerprint() {
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { Lock.unlocked = true }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON) credential()
            }
        }
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("MSF Document Writer")
            .setSubtitle("Fingerprint / فنگر پرنٹ")
            .setNegativeButtonText("Use PIN / پن استعمال کریں")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), cb).authenticate(info)
    }

    fun unlock() {
        if (!Prefs.appLock(this)) { Lock.unlocked = true; return }
        if (Prefs.fingerprint(this) && Lock.canBiometric(this)) fingerprint() else credential()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Fonts.init(this)
        CrashLog.install(this)
        try { CustomDesigns.init(this) } catch (_: Throwable) {}
        if (android.os.Build.VERSION.SDK_INT < 29 &&
            androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            androidx.core.app.ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 77)
        }
        AppState.accent = Color(Themes[Prefs.theme(this).coerceIn(0, Themes.size - 1)].second)
        AppState.urdu = Prefs.urdu(this)
        if (!Prefs.appLock(this)) Lock.unlocked = true
        else if (savedInstanceState == null) Lock.unlocked = false
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue)) {
                if (Lock.unlocked) App() else LockScreen { unlock() }
            }
        }
        if (!Lock.unlocked) unlock()
        if (savedInstanceState == null) Incoming.handle(this, intent)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        Incoming.handle(this, intent)
    }
}

@Composable
fun App() {
    val nav = rememberNavController()
    val act = LocalContext.current as? Activity
    SideEffect {
        act?.window?.statusBarColor = Blue.toArgb()
        act?.window?.navigationBarColor = Blue.toArgb()
    }
    CrashDialog()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val p = Incoming.pending
    androidx.compose.runtime.LaunchedEffect(p) {
        if (p != null) { Incoming.pending = null; openFile(nav, ctx, p) }
    }
    val t = Incoming.text
    androidx.compose.runtime.LaunchedEffect(t) {
        if (t != null) { Incoming.text = null; Doc.new(ctx, DocKind.WORD, body = t); nav.navigate("editor") }
    }
    Work.label?.let { msg ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            text = {
                androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    androidx.compose.material3.CircularProgressIndicator(modifier = androidx.compose.ui.Modifier.size(28.dp), strokeWidth = 3.dp)
                    androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.width(16.dp))
                    androidx.compose.material3.Text(msg)
                }
            }
        )
    }
    NavHost(nav, startDestination = "home") {
        composable("home") { HomeScreen(nav) }
        composable("discover") { DiscoverScreen(nav) }
        composable("new") { NewDocScreen(nav) }
        composable("blank") { BlankPageScreen(nav) }
        composable("editor") { RichEditorScreen(nav, "edit") }
        composable("format") { RichEditorScreen(nav, "format") }
        composable("urdu") { RichEditorScreen(nav, "urdu") }
        composable("save") { SaveScreen(nav) }
        composable("search") { SearchScreen(nav) }
        composable("print") { PrintScreen(nav) }
        composable("docs/{mode}") { e -> DocsScreen(nav, e.arguments?.getString("mode") ?: "browse", false) }
        composable("words") { DocsScreen(nav, "browse", true) }
        composable("pdfmaker") { PdfMakerScreen(nav) }
        composable("profile") { ProfileScreen(nav) }
        composable("security") { SecurityScreen(nav) }
        composable("settings") { SettingsScreen(nav) }
        composable("privacy") {
            InfoScreen(
                nav, "حفاظت / Privacy & Security", Icons.Filled.Security, "Privacy Policy",
                listOf(
                    "تمام دستاویزات صرف آپ کے فون میں محفوظ ہوتی ہیں۔\nAll documents are stored only on your device.",
                    "ایپ انٹرنیٹ استعمال نہیں کرتی اور کوئی ڈیٹا اکٹھا نہیں کرتی۔\nThe app has no internet permission and collects no data.",
                    "فائلیں صرف تب شیئر یا بیک اپ ہوتی ہیں جب آپ خود منتخب کریں۔\nFiles are shared or backed up only when you choose to."
                )
            )
        }
        composable("terms") {
            InfoScreen(
                nav, "شرائط و ضوابط / Terms", Icons.Filled.Article, "Terms & Conditions",
                listOf(
                    "یہ ایپ جیسی ہے ویسی فراہم کی جاتی ہے۔ اپنی اہم فائلوں کا بیک اپ خود رکھیں۔\nThe app is provided as is. Please keep your own backups of important files.",
                    "آپ اپنی بنائی ہوئی دستاویزات کے مواد کے خود ذمہ دار ہیں۔\nYou are responsible for the content of the documents you create."
                )
            )
        }
        composable("about") {
            InfoScreen(
                nav, "ایپ کے بارے میں / About", Icons.Filled.Info, "MSF Document Writer",
                listOf(
                    "Version 1.0.0",
                    "Word (DOCX)، PDF اور Text دستاویزات بنائیں، ایڈٹ کریں، شیئر اور پرنٹ کریں۔\nCreate, edit, share and print Word, PDF and Text documents.",
                    "اردو اور عربی (دائیں سے بائیں) تحریر سپورٹڈ ہے۔\nUrdu and Arabic (right-to-left) writing supported.",
                    "PDF Maker: Word, Excel, PowerPoint, Image, Text → PDF."
                )
            )
        }
    }
}
