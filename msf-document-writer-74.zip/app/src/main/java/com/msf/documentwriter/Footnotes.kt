package com.msf.documentwriter

import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.widget.EditText
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * Footnotes (حوالہ جات) under the writer's control.
 * A footnote block is a thin rule line followed by lines that start with their number; it is ordinary, editable text.
 * The writer chooses WHERE a new footnote goes (under its paragraph, bottom / top of the page, end of the document, at the cursor)
 * and can move an existing footnote block later (page top / bottom, document end, one paragraph up / down).
 */
object FootOps {
    const val RULE = "────────"

    /** Where a new footnote is put. */
    val PLACES = listOf(
        "Under this paragraph / اسی پیراگراف کے نیچے",
        "Bottom of this page / صفحے کے آخر میں",
        "Top of this page / صفحے کے شروع میں",
        "End of document / دستاویز کے آخر میں",
        "Here, at the cursor / یہیں کرسر کی جگہ"
    )

    /** Where an existing footnote block can be moved. */
    val MOVES = listOf(
        "Bottom of this page / صفحے کے آخر میں",
        "Top of this page / صفحے کے شروع میں",
        "End of document / دستاویز کے آخر میں",
        "One paragraph up / ایک پیراگراف اوپر",
        "One paragraph down / ایک پیراگراف نیچے"
    )

    private fun lineStart(s: String, p: Int): Int = if (p <= 0) 0 else s.lastIndexOf('\n', p - 1) + 1
    private fun lineEnd(s: String, p: Int): Int { val i = s.indexOf('\n', p.coerceIn(0, s.length)); return if (i < 0) s.length else i + 1 }
    private fun lineText(s: String, a: Int): String = s.substring(a, lineEnd(s, a)).trimEnd('\n')
    private fun startsWithDigit(l: String): Boolean = l.trimStart().firstOrNull()?.isDigit() == true

    /** Start and end (exclusive, after the last newline) of the footnote block that holds [pos]; null when [pos] is not in one. */
    fun blockAt(s: String, pos: Int): IntRange? {
        var ls = lineStart(s, pos.coerceIn(0, s.length))
        var n = 0
        while (lineText(s, ls).trim() != RULE) {
            if (ls == 0 || ++n > 40) return null
            ls = lineStart(s, ls - 1)
        }
        var e = lineEnd(s, ls)
        while (e < s.length && startsWithDigit(lineText(s, e))) e = lineEnd(s, e)
        val inside = pos >= ls && (pos < e || (pos == e && e == s.length))
        return if (inside) ls until e else null
    }

    private fun nextNumber(s: String): Int {
        var count = 0
        var inBlock = false
        var a = 0
        while (a < s.length) {
            val l = lineText(s, a)
            if (l.trim() == RULE) inBlock = true
            else if (inBlock && startsWithDigit(l)) count++
            else inBlock = false
            a = lineEnd(s, a)
        }
        return count + 1
    }

    private fun pages(et: EditText, len: Int): List<Int> {
        val starts = (et.parent as? PageSheets)?.breakStarts ?: emptyList()
        return (listOf(0) + starts).filter { it in 0..len }.distinct().sorted()
    }
    private fun pageStartOf(et: EditText, pos: Int): Int = pages(et, et.text.length).lastOrNull { it <= pos } ?: 0
    private fun pageEndOf(et: EditText, pos: Int): Int {
        val s = et.text.toString()
        var t = pages(et, s.length).firstOrNull { it > pos } ?: s.length
        // a page-break line belongs to the page before it: the footnote goes in front of it
        if (t > 0 && t < s.length) {
            val ls = lineStart(s, t - 1)
            if (s.substring(ls, t).contains(PAGE_BREAK)) t = ls
        }
        return t
    }

    private fun styled(text: String, rule: Boolean): SpannableStringBuilder {
        val b = SpannableStringBuilder(text)
        if (rule) {
            b.setSpan(ForegroundColorSpan(0xFF8A8A8A.toInt()), 0, b.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            b.setSpan(AbsoluteSizeSpan(8, true), 0, b.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        } else {
            b.setSpan(AbsoluteSizeSpan((Doc.baseSize * 0.8f).roundToInt().coerceAtLeast(9), true), 0, b.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return b
    }

    /** Puts [piece] at [at] on lines of its own and returns where it starts. */
    private fun put(et: EditText, at0: Int, piece: CharSequence): Int {
        val e = et.text
        var at = at0.coerceIn(0, e.length)
        if (at > 0 && e[at - 1] != '\n') { e.insert(at, "\n"); at++ }
        e.insert(at, piece)
        return at
    }

    /** A new footnote: a raised number at the cursor and "number  text" in a footnote block at the chosen place. */
    fun add(et: EditText, text: String, place: Int): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        val e = et.text
        val n = nextNumber(e.toString())
        val pos = InsertOps.pos(et)
        val ref = n.toString()
        e.insert(pos, ref)
        e.setSpan(ScriptSpan(true), pos, pos + ref.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val after = pos + ref.length
        val s = e.toString()
        val target = when (place) {
            0 -> lineEnd(s, after)
            1 -> pageEndOf(et, pos)
            2 -> pageStartOf(et, pos)
            3 -> s.length
            else -> after
        }
        val existing = if (place == 0 || place == 1 || place == 3) blockEndingAt(s, target) else null
        val line = SpannableStringBuilder(styled("$n  $t\n", false))
        if (existing != null) {
            // the place already has a footnote block just before it: add this note to it
            put(et, target, line)
        } else {
            val blk = SpannableStringBuilder()
            blk.append(styled(RULE + "\n", true)).append(line)
            put(et, target, blk)
        }
        et.setSelection(after.coerceIn(0, et.text.length))
        Doc.dirty = true
        return true
    }

    /** The footnote block whose last line ends exactly at [t], if any. */
    private fun blockEndingAt(s: String, t: Int): IntRange? {
        if (t <= 0 || t > s.length || s[t - 1] != '\n') return null
        val b = blockAt(s, t - 1) ?: return null
        return if (b.last + 1 == t) b else null
    }

    /** Moves the footnote block under the cursor (or the lines selected) to [where] (see [MOVES]). */
    fun move(et: EditText, where: Int): Boolean {
        val e = et.text
        val s = e.toString()
        val a = minOf(et.selectionStart, et.selectionEnd).coerceIn(0, s.length)
        val b = maxOf(et.selectionStart, et.selectionEnd).coerceIn(0, s.length)
        val start: Int
        val end: Int
        if (b > a) { start = lineStart(s, a); end = lineEnd(s, maxOf(a, b - 1)) }
        else { val r = blockAt(s, a) ?: return false; start = r.first; end = r.last + 1 }
        if (end <= start) return false
        var target = when (where) {
            0 -> pageEndOf(et, start)
            1 -> pageStartOf(et, start)
            2 -> s.length
            3 -> if (start > 0) lineStart(s, start - 1) else return false
            else -> if (end < s.length) lineEnd(s, end) else return false
        }
        if (target in start..end) return false
        val piece = cleanCopy(e.subSequence(start, end))
        if (piece.isEmpty() || piece[piece.length - 1] != '\n') piece.append("\n")
        val len = end - start
        e.delete(start, end)
        if (target > start) target -= len
        val at = put(et, target, piece)
        et.setSelection((at + 1).coerceIn(0, et.text.length))
        Doc.dirty = true
        return true
    }
}

@Composable
private fun PlaceList(items: List<String>, sel: Int, onPick: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        items.forEachIndexed { i, s ->
            Row(Modifier.fillMaxWidth().clickable { onPick(i) }.padding(vertical = 9.dp)) {
                Text(if (i == sel) "◉  " else "○  ", fontSize = 17.sp)
                Text(s, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun FootnoteDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var place by remember { mutableIntStateOf(1) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Footnote / حوالہ") },
        text = {
            Column {
                OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Footnote text / حوالے کا متن") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                PlaceList(FootOps.PLACES, place) { place = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val et = InsertBridge.et
                if (et == null) toast(ctx, "پہلے دستاویز میں کرسر رکھیں / Tap inside the document first")
                else if (!FootOps.add(et, text, place)) toast(ctx, "حوالے کا متن لکھیں / Write the footnote text")
                else { onClose(); toast(ctx, "حوالہ شامل ہو گیا؛ اس کا متن عام متن کی طرح بدل سکتے ہیں / Footnote added; edit it like normal text") }
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun FootMoveDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var where by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Move footnote / حوالہ منتقل کریں") },
        text = {
            Column {
                Text("کرسر حوالے کے اندر رکھیں (یا حوالے کی سطریں منتخب کریں)۔\nPut the cursor inside the footnote (or select its lines).", fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                PlaceList(FootOps.MOVES, where) { where = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val et = InsertBridge.et
                if (et == null) toast(ctx, "پہلے دستاویز میں کرسر رکھیں / Tap inside the document first")
                else if (!FootOps.move(et, where)) toast(ctx, "کرسر کسی حوالے کے اندر نہیں، یا وہ پہلے ہی اسی جگہ ہے / Cursor is not inside a footnote, or it is already there")
                else onClose()
            }) { Text("Move") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
