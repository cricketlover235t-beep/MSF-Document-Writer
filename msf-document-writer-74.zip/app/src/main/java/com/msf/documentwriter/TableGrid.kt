package com.msf.documentwriter

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.style.CharacterStyle
import android.text.style.ReplacementSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * One "|" of a table row, drawn as a vertical rule. Its width also fills up the end of the cell before it, so that every
 * column has the same width in all rows (the table looks like a real grid on the page).
 */
/**
 * A table row that is the first line of a new page sheet carries the page push (the bottom margin, the gap and the top margin
 * of the next sheet) at the top of its line. The row itself is only the part BELOW that push, so the rules, the colour and the
 * text of a row must start at top + push; otherwise the table is drawn through the gap and the last row of the page looks huge.
 */
object RowPush {
    fun at(text: CharSequence?, pos: Int): Int {
        val sp = text as? android.text.Spanned ?: return 0
        var ls = pos.coerceIn(0, sp.length)
        while (ls > 0 && sp[ls - 1] != '\n') ls--
        if (ls >= sp.length) return 0
        for (x in sp.getSpans(ls, ls + 1, PagePushSpan::class.java)) if (sp.getSpanStart(x) == ls) return x.d
        return 0
    }
}

class PipeSpan(val gapBefore: Float, val barW: Float, val padAfter: Float) : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int =
        Math.round(gapBefore + barW + padAfter)

    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        val p = TableGrid.rulePaint
        p.strokeWidth = max(1f, barW * 0.3f)
        val rx = if (TableGrid.rtl) x + padAfter + barW / 2f else x + gapBefore + barW / 2f
        canvas.drawLine(rx, (top + RowPush.at(text, start)).toFloat(), rx, bottom.toFloat(), p)
    }
}

/**
 * The text of one table cell, drawn word-wrapped inside its column (like a real table cell). The span has a fixed width
 * (the column width) and makes the table row as tall as the wrapped text needs, so every row stays one aligned line.
 */
class CellSpan(val lay: StaticLayout, val w: Float, val padX: Float, val padY: Float, val sig: String) : ReplacementSpan() {
    /**
     * Android calls a ReplacementSpan once for EVERY piece of its range that has a different character style or text direction
     * (a cell with 20 runs of Word formatting = 20 calls, each one drawing the whole cell again and taking a full column width).
     * That showed every cell text two, three or four times in a row. Only the piece that starts where the span starts counts.
     */
    private fun isFirstPiece(text: CharSequence?, start: Int): Boolean {
        val sp = text as? android.text.Spanned ?: return true
        val st = sp.getSpanStart(this)
        return st < 0 || st == start
    }

    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int {
        if (!isFirstPiece(text, start)) return 0
        if (fm != null) {
            val need = Math.ceil((lay.height + padY * 2f).toDouble()).toInt()
            val asc = -(need - fm.descent)
            if (asc < fm.ascent) fm.ascent = asc
            if (fm.ascent < fm.top) fm.top = fm.ascent
            if (fm.descent > fm.bottom) fm.bottom = fm.descent
        }
        return Math.round(w)
    }

    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        if (!isFirstPiece(text, start)) return
        canvas.save()
        canvas.translate(x + padX, top + RowPush.at(text, start) + padY)
        lay.draw(canvas)
        canvas.restore()
    }
}

/** The "|---|---|" line that marks a header row is not shown: it takes no room on the page. */
class SepSpan : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int {
        if (fm != null) { fm.ascent = 0; fm.descent = 0; fm.top = 0; fm.bottom = 0 }
        return 0
    }
    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {}
}

object TableGrid {
    /** Right-to-left document: tables start at the right edge. Set by the screen. */
    var rtl = false
    val rulePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8E8E8E.toInt(); style = Paint.Style.STROKE }

    private class Ln(val a: Int, val b: Int, val sep: Boolean)

    private fun pipes(s: String, a: Int, b: Int): List<Int> {
        val out = ArrayList<Int>()
        for (i in a until b) if (s[i] == '|') out.add(i)
        return out
    }

    private fun setPipe(e: android.text.Editable, pos: Int, gap: Float, bar: Float, pad: Float, seen: HashSet<Any>): Boolean {
        val cur = e.getSpans(pos, pos + 1, PipeSpan::class.java).filter { e.getSpanStart(it) == pos && e.getSpanEnd(it) == pos + 1 }
        val ok = cur.firstOrNull()
        if (ok != null && abs(ok.gapBefore - gap) < 0.6f && abs(ok.barW - bar) < 0.1f && abs(ok.padAfter - pad) < 0.1f) {
            seen.add(ok)
            for (extra in cur) if (extra !== ok) e.removeSpan(extra)
            return false
        }
        for (sp in cur) e.removeSpan(sp)
        val n = PipeSpan(gap, bar, pad)
        e.setSpan(n, pos, pos + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        seen.add(n)
        return true
    }

    private const val CELL_PAD_X = 5f

    /** (Re)builds the word-wrapped drawing of the cell text in [a, b). Returns true when the span changed. */
    private fun setCell(et: EditText, a: Int, b: Int, w: Float, padY: Float, seen: HashSet<Any>): Boolean {
        val e = et.text
        val cur = e.getSpans(a, b, CellSpan::class.java).filter { e.getSpanStart(it) == a && e.getSpanEnd(it) == b }
        val padX = CELL_PAD_X * et.resources.displayMetrics.density
        val inner = (w - padX * 2f).toInt().coerceAtLeast(12)
        val sub = SpannableStringBuilder(e.subSequence(a, b))
        for (sp in sub.getSpans(0, sub.length, Any::class.java)) {
            if (sp is ReplacementSpan || sp !is CharacterStyle) sub.removeSpan(sp)
        }
        val sig = StringBuilder().append(sub.toString()).append('#').append(inner).append('#').append(et.textSize).append('#').append(rtl).append('#').append(et.currentTextColor)
        for (sp in sub.getSpans(0, sub.length, Any::class.java)) {
            sig.append(sp.javaClass.simpleName).append(sub.getSpanStart(sp)).append(',').append(sub.getSpanEnd(sp)).append(sp.toString().hashCode())
        }
        val key = sig.toString()
        val ok = cur.firstOrNull()
        if (ok != null && ok.sig == key && abs(ok.w - w) < 0.6f) {
            seen.add(ok)
            for (extra in cur) if (extra !== ok) e.removeSpan(extra)
            return false
        }
        for (sp in cur) e.removeSpan(sp)
        val tp = TextPaint(et.paint)
        tp.color = et.currentTextColor
        val lay = StaticLayout.Builder.obtain(sub, 0, sub.length, tp, inner)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(if (rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .setIncludePad(false)
            .build()
        val n = CellSpan(lay, w, padX, padY, key)
        e.setSpan(n, a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        seen.add(n)
        return true
    }

    /**
     * Gives every table in the editor text aligned columns: all columns equal (and as wide as the text needs), table as wide as
     * the text area. Returns true when spans changed (the text has to be laid out again).
     */
    fun fit(et: EditText): Boolean {
        val e = et.text
        val s = e.toString()
        var changed = false
        if (s.indexOf('|') < 0) {
            for (sp in e.getSpans(0, e.length, PipeSpan::class.java)) { e.removeSpan(sp); changed = true }
            for (sp in e.getSpans(0, e.length, SepSpan::class.java)) { e.removeSpan(sp); changed = true }
            for (sp in e.getSpans(0, e.length, CellSpan::class.java)) { e.removeSpan(sp); changed = true }
            return changed
        }
        val availPx = et.width - et.paddingLeft - et.paddingRight
        if (availPx <= 60) return false
        val paint = et.paint
        val bar = max(3f, paint.textSize * 0.12f)
        val pad = max(2f, paint.textSize * 0.22f)
        val seen = HashSet<Any>()
        var redraw = false

        fun table(lines: List<Ln>) {
            val data = lines.filter { !it.sep }
            if (data.isEmpty()) return
            val pl = data.map { pipes(s, it.a, it.b) }
            val ncols = pl.maxOf { it.size - 1 }.coerceAtLeast(1)
            val textW = Array(data.size) { FloatArray(ncols) }
            val colMax = FloatArray(ncols)
            for (r in data.indices) {
                val p = pl[r]
                for (j in 0 until p.size - 1) {
                    if (j >= ncols) break
                    val w = paint.measureText(s, p[j] + 1, p[j + 1])
                    textW[r][j] = w
                    if (w > colMax[j]) colMax[j] = w
                }
            }
            val fixed = (ncols + 1) * (bar + pad)
            // the table is exactly as wide as the text area; long cell text wraps inside its column
            val room = (availPx - 6f - ncols * 2f - fixed).coerceAtLeast(bar * 2f * ncols)
            val minCol = max(bar * 2f, paint.textSize * 1.2f)
            val fr = TableWidths.at(e, lines[0].a, lines[lines.size - 1].b, ncols)
            val colW = if (fr != null) FloatArray(ncols) { (room * fr[it]).coerceAtLeast(minCol) } else FloatArray(ncols) { (room / ncols).coerceAtLeast(minCol) }
            val total = fixed + colW.sum()
            val padY = 3f * et.resources.displayMetrics.density
            for (r in data.indices) {
                val p = pl[r]
                val wrapped = BooleanArray(ncols)
                for (j in 0 until p.size - 1) {
                    if (j >= ncols) break
                    val a = p[j] + 1
                    val b = p[j + 1]
                    if (b > a && s.substring(a, b).isNotBlank()) {
                        wrapped[j] = true
                        if (setCell(et, a, b, colW[j], padY, seen)) changed = true
                    }
                }
                for (k in p.indices) {
                    val gap = if (k == 0 || k - 1 >= ncols || wrapped[k - 1]) 0f else (colW[k - 1] - textW[r][k - 1]).coerceAtLeast(0f)
                    if (setPipe(e, p[k], gap, bar, pad, seen)) changed = true
                }
            }
            for (ln in lines) {
                if (ln.sep && ln.b > ln.a) {
                    val cur = e.getSpans(ln.a, ln.b, SepSpan::class.java).filter { e.getSpanStart(it) == ln.a && e.getSpanEnd(it) == ln.b }
                    if (cur.isEmpty()) {
                        val n = SepSpan()
                        e.setSpan(n, ln.a, ln.b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        seen.add(n); changed = true
                    } else cur.forEach { seen.add(it) }
                }
                for (rs in e.getSpans(ln.a, max(ln.b, ln.a + 1).coerceAtMost(e.length), TableRowSpan::class.java)) {
                    if (abs(rs.width - total) > 0.5f) { rs.width = total; redraw = true }
                }
            }
        }

        var cur = ArrayList<Ln>()
        var ps = 0
        while (ps <= s.length) {
            val nl = s.indexOf('\n', ps)
            val pe = if (nl < 0) s.length else nl
            val line = s.substring(ps, pe)
            if (Tables.isRow(line)) cur.add(Ln(ps, pe, Tables.isSeparator(line)))
            else if (cur.isNotEmpty()) { table(cur); cur = ArrayList() }
            if (nl < 0) break
            ps = nl + 1
        }
        if (cur.isNotEmpty()) table(cur)

        for (sp in e.getSpans(0, e.length, PipeSpan::class.java)) if (!seen.contains(sp)) { e.removeSpan(sp); changed = true }
        for (sp in e.getSpans(0, e.length, SepSpan::class.java)) if (!seen.contains(sp)) { e.removeSpan(sp); changed = true }
        for (sp in e.getSpans(0, e.length, CellSpan::class.java)) if (!seen.contains(sp)) { e.removeSpan(sp); changed = true }
        if (redraw) et.invalidate()
        return changed
    }
}

/** What the table handles can do; the editor screen fills these in. */
class TableActions(
    val onCol: (Int) -> Unit, val onRow: (Int) -> Unit,
    val onAddCol: () -> Unit, val onAddRow: () -> Unit,
    val onSelect: () -> Unit, val onSelectAll: () -> Unit, val onProps: () -> Unit,
    val onRowAbove: () -> Unit, val onColLeft: () -> Unit,
    val onDelRow: () -> Unit, val onDelCol: () -> Unit, val onDelTable: () -> Unit,
    /** Moves the current column one place to the left (-1) or to the right (+1) on the screen. */
    val onColMove: (Int) -> Unit = {},
    /** Moves the current row one place up (-1) or down (+1). */
    val onRowMove: (Int) -> Unit = {},
    /** Locks / unlocks the current row or column. */
    val onLockRow: () -> Unit = {},
    val onLockCol: () -> Unit = {}
)

/**
 * The table handles drawn on the page itself while the cursor is inside a table: column letters (A B C) above the table,
 * row numbers (1 2 3) at its left, "+" circles to add a column / row and the four-arrow button that opens the table menu
 * (Select, Select All, Table Properties ...). It sits over the editor and only takes touches that hit a handle.
 */
class TableOverlay(c: Context, private val et: SelEditText) : View(c) {
    var act: TableActions? = null
    private val dp = resources.displayMetrics.density
    private class Hit(val r: RectF, val run: () -> Unit)
    private val hits = ArrayList<Hit>()
    private var down: Hit? = null
    private var moveRect = RectF()
    /** Called after a column / row was dragged to a new size (the screen re-lays the page and marks the document changed). */
    var onResized: (() -> Unit)? = null

    // table geometry of the last draw (for dragging column / row borders)
    private var gEdges = FloatArray(0)
    private var gRowBottoms = FloatArray(0)
    private var gTop = 0f
    private var gBottom = 0f
    private var gStrip = 0f
    private var gPos = 0
    private var gRow = 0
    private var gSign = 1f
    private var gBarPad = 0f
    // drag: 0 none, 1 column border, 2 row border
    private var dragMode = 0
    private var dragIdx = 0
    private var dragX = 0f
    private var dragY = 0f
    private val dashBlue = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF1E88E5.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f * dp
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(7f * dp, 5f * dp), 0f)
    }

    private val acc = 0xFF1E88E5.toInt()
    private val chipFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.FILL }
    private val chipLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8A8A8A.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.2f * dp }
    private val chipText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF222222.toInt(); textAlign = Paint.Align.CENTER; textSize = 14f * dp }
    private val accFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = acc; style = Paint.Style.FILL }
    private val accLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = acc; style = Paint.Style.STROKE; strokeWidth = 2f * dp }
    private val lockFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE65100.toInt(); style = Paint.Style.FILL }
    private val lockLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE65100.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f * dp }
    private val lockStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE65100.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.6f * dp }
    private var gLk: TableLocks.Lk = TableLocks.NONE

    /** Little padlock centred at (cx, cy). */
    private fun padlock(canvas: Canvas, cx: Float, cy: Float, sz: Float) {
        val w = sz * 0.9f
        val h = sz * 0.62f
        val top = cy - h / 2f + sz * 0.16f
        canvas.drawRoundRect(RectF(cx - w / 2f, top, cx + w / 2f, top + h), sz * 0.12f, sz * 0.12f, lockFill)
        val sh = RectF(cx - w * 0.28f, top - sz * 0.42f, cx + w * 0.28f, top + sz * 0.2f)
        canvas.drawArc(sh, 180f, 180f, false, lockStroke)
        canvas.drawLine(sh.left, top - sz * 0.21f, sh.left, top + 1f, lockStroke)
        canvas.drawLine(sh.right, top - sz * 0.21f, sh.right, top + 1f, lockStroke)
    }

    init { setWillNotDraw(false) }

    private fun chip(canvas: Canvas, r: RectF, label: String, on: Boolean, locked: Boolean = false, run: () -> Unit) {
        val rr = 4f * dp
        canvas.drawRoundRect(r, rr, rr, chipFill)
        canvas.drawRoundRect(r, rr, rr, if (locked) lockLine else if (on) accLine else chipLine)
        chipText.color = if (on) acc else 0xFF222222.toInt()
        val ty = r.centerY() - (chipText.descent() + chipText.ascent()) / 2f
        canvas.drawText(label, r.centerX(), ty, chipText)
        if (locked) padlock(canvas, r.right - 6f * dp, r.top + 5f * dp, 10f * dp)
        val hit = RectF(r.left - 3 * dp, r.top - 3 * dp, r.right + 3 * dp, r.bottom + 3 * dp)
        hits.add(Hit(hit, run))
    }

    private fun circle(canvas: Canvas, cx: Float, cy: Float, r: Float, plus: Boolean, run: () -> Unit): RectF {
        canvas.drawCircle(cx, cy, r, chipFill)
        canvas.drawCircle(cx, cy, r, chipLine)
        if (plus) {
            val l = r * 0.5f
            canvas.drawLine(cx - l, cy, cx + l, cy, accLine)
            canvas.drawLine(cx, cy - l, cx, cy + l, accLine)
        } else {
            val t = r * 0.28f
            val m = r * 0.78f
            fun tri(dx: Float, dy: Float) {
                val p = Path()
                val tx = cx + dx * m
                val ty = cy + dy * m
                if (dx != 0f) { p.moveTo(tx, ty); p.lineTo(tx - dx * t * 1.4f, ty - t); p.lineTo(tx - dx * t * 1.4f, ty + t) }
                else { p.moveTo(tx, ty); p.lineTo(tx - t, ty - dy * t * 1.4f); p.lineTo(tx + t, ty - dy * t * 1.4f) }
                p.close()
                canvas.drawPath(p, accFill)
            }
            tri(1f, 0f); tri(-1f, 0f); tri(0f, 1f); tri(0f, -1f)
        }
        val hit = RectF(cx - r - 4 * dp, cy - r - 4 * dp, cx + r + 4 * dp, cy + r + 4 * dp)
        hits.add(Hit(hit, run))
        return hit
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        hits.clear()
        try { drawHandles(canvas) } catch (e: Throwable) { hits.clear() }
        try { drawGuide(canvas) } catch (e: Throwable) { }
    }

    private fun clampCol(x: Float): Float {
        val k = dragIdx
        val minW = 26f * dp + gBarPad
        val lo = gSign * gEdges[k - 1] + minW
        val hi = gSign * gEdges[k + 1] - minW
        if (hi < lo) return gEdges[k]
        return gSign * (gSign * x).coerceIn(lo, hi)
    }

    private fun clampRow(y: Float): Float {
        val top = if (dragIdx == 0) gTop else gRowBottoms[dragIdx - 1]
        return max(y, top + 20f * dp)
    }

    private fun arrowHeads(canvas: Canvas, cx: Float, cy: Float, horizontal: Boolean) {
        val a = 7f * dp
        val p = Path()
        if (horizontal) {
            p.moveTo(cx - 14f * dp, cy); p.lineTo(cx - 14f * dp + a, cy - a * 0.7f); p.lineTo(cx - 14f * dp + a, cy + a * 0.7f); p.close()
            p.moveTo(cx + 14f * dp, cy); p.lineTo(cx + 14f * dp - a, cy - a * 0.7f); p.lineTo(cx + 14f * dp - a, cy + a * 0.7f); p.close()
        } else {
            p.moveTo(cx, cy - 14f * dp); p.lineTo(cx - a * 0.7f, cy - 14f * dp + a); p.lineTo(cx + a * 0.7f, cy - 14f * dp + a); p.close()
            p.moveTo(cx, cy + 14f * dp); p.lineTo(cx - a * 0.7f, cy + 14f * dp - a); p.lineTo(cx + a * 0.7f, cy + 14f * dp - a); p.close()
        }
        canvas.drawPath(p, accFill)
    }

    /** Blue dashed guide line (and the two-way arrow) while a column / row border is being dragged. */
    private fun drawGuide(canvas: Canvas) {
        if (dragMode == 1) {
            val x = clampCol(dragX)
            canvas.drawLine(x, gStrip, x, height.toFloat(), dashBlue)
            val cy = (gTop + gBottom) / 2f
            canvas.drawLine(x - 14f * dp, cy, x + 14f * dp, cy, accLine)
            arrowHeads(canvas, x, cy, true)
        } else if (dragMode == 2) {
            val y = clampRow(dragY)
            val l = min(gEdges.first(), gEdges.last()) - 8f * dp
            val r = max(gEdges.first(), gEdges.last()) + 8f * dp
            canvas.drawLine(l, y, r, y, dashBlue)
            val cx = (l + r) / 2f
            canvas.drawLine(cx, y - 14f * dp, cx, y + 14f * dp, accLine)
            arrowHeads(canvas, cx, y, false)
        }
    }

    private fun findBorder(x: Float, y: Float): Boolean {
        if (gEdges.size < 2) return false
        val slop = 12f * dp
        val l = min(gEdges.first(), gEdges.last())
        val r = max(gEdges.first(), gEdges.last())
        var bestK = -1
        var bestD = slop
        if (y >= gStrip && y <= gBottom + slop) {
            for (k in 1 until gEdges.size - 1) {
                val d = abs(x - gEdges[k])
                if (d < bestD) { bestD = d; bestK = k }
            }
        }
        var bestR = -1
        var bestRD = slop
        if (x >= l - slop && x <= r + slop) {
            for (i in gRowBottoms.indices) {
                val d = abs(y - gRowBottoms[i])
                if (d < bestRD) { bestRD = d; bestR = i }
            }
        }
        if (bestK >= 0 && bestD <= bestRD) {
            if (gLk.cols.contains(bestK - 1) || gLk.cols.contains(bestK)) { toast(context, "کالم لاک ہے / Column is locked"); return false }
            dragMode = 1; dragIdx = bestK; dragX = x; dragY = y; return true
        }
        if (bestR >= 0) {
            if (gLk.rows.contains(bestR)) { toast(context, "قطار لاک ہے / Row is locked"); return false }
            dragMode = 2; dragIdx = bestR; dragX = x; dragY = y; return true
        }
        return false
    }

    private fun finishDrag() {
        val mode = dragMode
        dragMode = 0
        val e = et.text
        try {
            if (mode == 1) {
                val k = dragIdx
                val n = gEdges.size - 1
                val x = clampCol(dragX)
                val d = gSign * (x - gEdges[k])
                // Only the two columns beside the dragged border change; every other column keeps its stored width exactly.
                val total = abs(gEdges[n] - gEdges[0])
                val room = (total - (n + 1) * gBarPad).coerceAtLeast(40f)
                val old = TableOps.widths(e, gPos)
                val fr = if (old != null && old.size == n) old.copyOf() else FloatArray(n) { 1f / n }
                val minFr = (26f * dp / room).coerceAtMost(0.5f / n)
                val pair = fr[k - 1] + fr[k]
                val nl = (fr[k - 1] + d / room).coerceIn(minFr, pair - minFr)
                fr[k - 1] = nl
                fr[k] = pair - nl
                TableOps.setWidths(e, gPos, fr)
            } else if (mode == 2) {
                val r = dragIdx
                val top = if (r == 0) gTop else gRowBottoms[r - 1]
                val cur = gRowBottoms[r] - top
                val want = clampRow(dragY) - top
                val extra = TableOps.rowExtra(e, gPos, r) + (want - cur) / dp
                TableOps.setRowExtra(e, gPos, r, max(0f, extra), dp)
            }
        } catch (t: Throwable) { }
        try { TableGrid.fit(et) } catch (t: Throwable) { }
        et.requestLayout()
        onResized?.invoke()
        invalidate()
    }

    private fun drawHandles(canvas: Canvas) {
        val a = act ?: return
        val lay = et.layout ?: return
        val e = et.text
        if (e.isEmpty()) return
        val pos = et.selectionStart.coerceIn(0, e.length)
        val info = TableOps.info(e, pos) ?: return
        val range = TableOps.tableRange(e, pos) ?: return
        val s = e.toString()
        val lk = TableLocks.get(e, pos)
        gLk = lk
        val cm = et.colMap
        fun shiftOf(layoutY: Int): Pair<Float, Float> {
            if (cm == null || cm.count == 0) return Pair(0f, 0f)
            val i = cm.chunkAt(layoutY.toFloat())
            return Pair(cm.x(i) - et.paddingLeft, cm.y(i) - cm.tops[i] - et.paddingTop)
        }
        // rows of the table (the |---| line is not a row)
        val rowsOff = ArrayList<IntArray>()
        var ps = range.first
        while (ps <= range.second) {
            val nl = s.indexOf('\n', ps)
            val pe = if (nl < 0 || nl > range.second) range.second else nl
            if (!Tables.isSeparator(s.substring(ps, pe))) rowsOff.add(intArrayOf(ps, pe))
            if (pe >= range.second) break
            ps = pe + 1
        }
        if (rowsOff.isEmpty()) return
        val first = rowsOff[0]
        val pl = ArrayList<Int>()
        for (i in first[0] until first[1]) if (s[i] == '|') pl.add(i)
        if (pl.size < 2) return
        val ncols = pl.size - 1
        val line0 = lay.getLineForOffset(first[0])
        val (sx, sy0) = shiftOf(lay.getLineTop(line0))
        val edges = FloatArray(ncols + 1) { lay.getPrimaryHorizontal(pl[it]) + et.paddingLeft + sx }
        val endEdge = lay.getPrimaryHorizontal(minOf(pl[ncols] + 1, e.length)) + et.paddingLeft + sx
        val tableL = minOf(edges.min(), endEdge)
        val tableR = maxOf(edges.max(), endEdge)
        val tableTop = lay.getLineTop(line0) + et.paddingTop + sy0
        val lastLine = lay.getLineForOffset(rowsOff.last()[1])
        val (_, syL) = shiftOf(lay.getLineTop(lastLine))
        val tableBottom = lay.getLineBottom(lastLine) + et.paddingTop + syL

        val chipH = 24f * dp
        val stripTop = tableTop - chipH - 5f * dp
        // column letters
        for (j in 0 until ncols) {
            val x1 = minOf(edges[j], if (j + 1 <= ncols) edges[j + 1] else endEdge)
            val x2 = maxOf(edges[j], if (j + 1 <= ncols) edges[j + 1] else endEdge)
            val last = j == ncols - 1
            val xe2 = if (last) maxOf(x2, endEdge.takeIf { endEdge > x1 } ?: x2) else x2
            val r = RectF(x1 + 1.5f * dp, stripTop, (if (last) xe2 else x2) - 1.5f * dp, stripTop + chipH)
            val jj = j
            chip(canvas, r, tableColName(j), j == info.col, lk.cols.contains(j)) { a.onCol(jj) }
        }
        // row numbers (in the page margin at the left of the table)
        val room = tableL - 6f * dp
        val rw = max(14f * dp, min(28f * dp, room))
        val rx = max(2f * dp, tableL - rw - 4f * dp)
        for ((ri, off) in rowsOff.withIndex()) {
            val l1 = lay.getLineForOffset(off[0])
            val l2 = lay.getLineForOffset(off[1])
            val (_, sy) = shiftOf(lay.getLineTop(l1))
            val top = lay.getLineTop(l1) + et.paddingTop + sy
            val bot = lay.getLineBottom(l2) + et.paddingTop + sy
            if (bot - top < 4f) continue
            val rr = RectF(rx, top + 1.5f * dp, rx + rw, bot - 1.5f * dp)
            val rri = ri
            chip(canvas, rr, "${ri + 1}", ri == info.row, lk.rows.contains(ri)) { a.onRow(rri) }
        }
        gEdges = edges
        gTop = tableTop
        gBottom = tableBottom
        gStrip = stripTop
        gPos = pos
        gSign = if (edges[ncols] >= edges[0]) 1f else -1f
        val tsz = et.paint.textSize
        gBarPad = max(3f, tsz * 0.12f) + max(2f, tsz * 0.22f)
        val rb = FloatArray(rowsOff.size)
        for ((ri, off) in rowsOff.withIndex()) {
            val l2 = lay.getLineForOffset(off[1])
            val (_, sy) = shiftOf(lay.getLineTop(l2))
            rb[ri] = lay.getLineBottom(l2) + et.paddingTop + sy
        }
        gRowBottoms = rb
        gRow = rowsOff.size
        val cr = 14f * dp
        val cxLeft = rx + rw / 2f
        moveRect = circle(canvas, max(cr + 2f * dp, cxLeft), stripTop + chipH / 2f, cr, false) { showMenu(a) }
        val plusX = min(width - cr - 2f * dp, tableR + 6f * dp + cr)
        circle(canvas, plusX, stripTop + chipH / 2f, cr, true) { a.onAddCol() }
        val rowPlusX = max(cr + 2f * dp, cxLeft)
        val rowPlusY = tableBottom + cr + 6f * dp
        circle(canvas, rowPlusX, rowPlusY, cr, true) { a.onAddRow() }
        // move the current column to the left / right
        val gx = rowPlusX + cr * 2.6f
        arrowCircle(canvas, gx, rowPlusY, cr, -1f) { a.onColMove(-1) }
        arrowCircle(canvas, gx + cr * 2.4f, rowPlusY, cr, 1f) { a.onColMove(1) }
    }

    private fun arrowCircle(canvas: Canvas, cx: Float, cy: Float, r: Float, dir: Float, run: () -> Unit) {
        canvas.drawCircle(cx, cy, r, chipFill)
        canvas.drawCircle(cx, cy, r, chipLine)
        val t = r * 0.42f
        val p = Path()
        p.moveTo(cx + dir * t, cy - t * 1.1f)
        p.lineTo(cx - dir * t, cy)
        p.lineTo(cx + dir * t, cy + t * 1.1f)
        p.close()
        canvas.drawPath(p, accFill)
        hits.add(Hit(RectF(cx - r - 4 * dp, cy - r - 4 * dp, cx + r + 4 * dp, cy + r + 4 * dp), run))
    }

    private fun showMenu(a: TableActions) {
        val items = listOf<Pair<String, () -> Unit>>(
            "Select" to a.onSelect,
            "Select All" to a.onSelectAll,
            "Table Properties" to a.onProps,
            "Row above / اوپر قطار" to a.onRowAbove,
            "Column left / بائیں کالم" to a.onColLeft,
            "Move column left / کالم بائیں کھسکائیں" to { a.onColMove(-1) },
            "Move column right / کالم دائیں کھسکائیں" to { a.onColMove(1) },
            "Delete row / قطار مٹائیں" to a.onDelRow,
            "Delete column / کالم مٹائیں" to a.onDelCol,
            "Delete table / ٹیبل مٹائیں" to a.onDelTable
        )
        val box = LinearLayout(context)
        box.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xFF303030.toInt())
        bg.cornerRadius = 12f * dp
        box.background = bg
        val sv = ScrollView(context)
        sv.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val menuW = (250f * dp).toInt()
        val menuH = min((items.size * 50f * dp).toInt(), (330f * dp).toInt())
        val pw = PopupWindow(sv, menuW, menuH, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        pw.elevation = 12f * dp
        for ((label, run) in items) {
            val tv = TextView(context)
            tv.text = label
            tv.textSize = 16f
            tv.setTextColor(if (label.startsWith("Delete")) 0xFFFF8A80.toInt() else 0xFFE6E6E6.toInt())
            tv.setPadding((22f * dp).toInt(), (14f * dp).toInt(), (22f * dp).toInt(), (14f * dp).toInt())
            tv.setOnClickListener { pw.dismiss(); run() }
            box.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val dm = resources.displayMetrics
        val x = min(max(loc[0] + moveRect.left.toInt(), (8f * dp).toInt()), dm.widthPixels - menuW - (8f * dp).toInt())
        val y = min(loc[1] + moveRect.bottom.toInt() + (6f * dp).toInt(), dm.heightPixels - menuH - (16f * dp).toInt())
        pw.showAtLocation(this, Gravity.NO_GRAVITY, x, max(y, (24f * dp).toInt()))
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = hits.firstOrNull { it.r.contains(ev.x, ev.y) }
                if (down != null) return true
                if (findBorder(ev.x, ev.y)) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    invalidate()
                    return true
                }
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragMode != 0) { dragX = ev.x; dragY = ev.y; invalidate(); return true }
            }
            MotionEvent.ACTION_UP -> {
                if (dragMode != 0) { dragX = ev.x; dragY = ev.y; finishDrag(); return true }
                val h = down
                down = null
                if (h != null && h.r.contains(ev.x, ev.y)) { h.run(); invalidate() }
                return h != null
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragMode != 0) { dragMode = 0; invalidate() }
                down = null
                return false
            }
        }
        return down != null || dragMode != 0
    }
}
