package com.msf.documentwriter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

fun decodeBitmap(c: Context, u: Uri, max: Int): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
    c.contentResolver.openInputStream(u)?.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
    }
} catch (e: Exception) { null }

object Render {
    fun layout(t: CharSequence, base: Float, font: String?, rtl: Boolean, justify: Boolean, width: Int, density: Float): StaticLayout {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.textSize = base * density
        tp.density = density
        tp.color = Color.BLACK
        if (font != null) tp.typeface = Fonts.typeface(font)
        val b = StaticLayout.Builder.obtain(t, 0, t.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(if (rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .setLineSpacing(0f, 1.25f * Doc.lineSpacing)
        if (justify && Build.VERSION.SDK_INT >= 26) b.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
        return b.build()
    }

    /** First page preview (A4 @ 595x842). */
    fun page(t0: CharSequence, base: Int, font: String?, rtl: Boolean, justify: Boolean, bg: Bitmap? = null, spec: PageDesigns.Spec? = null, numbers: Boolean = false, paper: Int = 0, land: Boolean = false, margin: Mar? = null, pn: PageNumCfg = PageNumCfg()): Bitmap {
        val t = withFontSpans(t0)
        val (pw, ph) = Paper.pt(paper, land)
        val PW = pw.toFloat(); val PH = ph.toFloat()
        val bmp = Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        if (bg != null) c.drawBitmap(bg, null, RectF(0f, 0f, PW, PH), Paint(Paint.FILTER_BITMAP_FLAG))
        val useBg = spec != null && bg != null
        val ml = if (useBg) PW * spec!!.mx else (margin?.l ?: 40f)
        val mr = if (useBg) PW * spec!!.mx else (margin?.r ?: 40f)
        val mt = if (useBg) PH * spec!!.mt else (margin?.t ?: 40f)
        val mb = if (useBg) PH * spec!!.mb else (margin?.b ?: 40f)
        val cut = t.indexOf(PAGE_BREAK)
        val first = if (cut >= 0) t.subSequence(0, cut) else t
        val lay = layout(first, base.toFloat(), font, rtl, justify, (PW - ml - mr).toInt().coerceAtLeast(10), 1f)
        c.save()
        c.translate(ml, mt)
        c.clipRect(0f, 0f, PW - ml - mr, PH - mt - mb)
        lay.draw(c)
        c.restore()
        if (numbers) drawPageNumber(c, PW, PH, ml, mr, mt, mb, PageNum.label(1, pn), pn)
        return bmp
    }

    /** Draws the page number (header or footer, left / centre / right) on a page canvas. */
    fun drawPageNumber(c: Canvas, pw: Float, ph: Float, ml: Float, mr: Float, mt: Float, mb: Float, text: String, pn: PageNumCfg) {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = 11f
        p.color = 0xFF333333.toInt()
        val x: Float
        when (pn.align) {
            0 -> { p.textAlign = Paint.Align.LEFT; x = ml }
            2 -> { p.textAlign = Paint.Align.RIGHT; x = pw - mr }
            else -> { p.textAlign = Paint.Align.CENTER; x = pw / 2f }
        }
        val y = if (pn.loc == 0) (mt - 24f).coerceAtLeast(16f) else ph - mb + 24f
        c.drawText(text, x, y, p)
    }

    /** Renders every page of a PDF (max 8) one below the other into a single JPEG. */
    fun pdfToJpeg(pdf: File, out: File, width: Int = 1000, maxPages: Int = 8) {
        val pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try {
            val n = minOf(r.pageCount, maxPages).coerceAtLeast(1)
            val p0 = r.openPage(0)
            val h = (width.toFloat() * p0.height / p0.width).toInt()
            p0.close()
            val all = Bitmap.createBitmap(width, h * n, Bitmap.Config.ARGB_8888)
            val ac = Canvas(all)
            ac.drawColor(Color.WHITE)
            val one = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            for (i in 0 until n) {
                one.eraseColor(Color.WHITE)
                val pg = r.openPage(i)
                pg.render(one, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                pg.close()
                ac.drawBitmap(one, 0f, (i * h).toFloat(), null)
            }
            one.recycle()
            FileOutputStream(out).use { all.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            all.recycle()
        } finally { r.close(); pfd.close() }
    }

    fun toJpeg(t: CharSequence, base: Int, font: String?, rtl: Boolean, justify: Boolean, image: Bitmap?, out: File) {
        val scale = 2f
        val w = 1190
        val m = 80
        val lay = layout(t, base.toFloat(), font, rtl, justify, w - 2 * m, scale)
        val imgW = w - 2 * m
        val imgH = if (image != null) (image.height * (imgW.toFloat() / image.width)).toInt().coerceAtMost(1400) + 30 else 0
        val h = maxOf(1684, lay.height + imgH + 2 * m).coerceAtMost(16000)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        var y = m.toFloat()
        if (image != null) {
            c.drawBitmap(image, null, RectF(m.toFloat(), y, (m + imgW).toFloat(), y + imgH - 30), Paint(Paint.FILTER_BITMAP_FLAG))
            y += imgH
        }
        c.translate(m.toFloat(), y)
        lay.draw(c)
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }
}

/** Copy of [t] in which every font span is a [FontSpan], so that bundled and user-added fonts are used in the PDF. */
fun withFontSpans(t: CharSequence): SpannableStringBuilder {
    val b = SpannableStringBuilder(t)
    for (sp in b.getSpans(0, b.length, android.text.style.TypefaceSpan::class.java)) {
        if (sp is FontSpan) continue
        val fam = sp.family ?: continue
        val s = b.getSpanStart(sp); val e = b.getSpanEnd(sp); val fl = b.getSpanFlags(sp)
        b.removeSpan(sp)
        b.setSpan(FontSpan(fam), s, e, fl)
    }
    return b
}

class PdfBuilder(paper: Int = 0, landscape: Boolean = false, private val bg: Bitmap? = null, spec: PageDesigns.Spec? = null, private val numbers: Boolean = false, margin: Mar? = null, extraSpecs: List<PageDesigns.Spec> = emptyList(), private val pn: PageNumCfg = PageNumCfg()) {
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var n = 0
    private var y = 0f
    private var pending = false
    /** Page breaks met in the text whose page has not been started yet: a page is only started when something is drawn on it,
     *  so breaks at the very start / very end of the text never produce an empty first or last page. */
    private var pendingBreaks = 0
    /** draw the pen strokes of the editor on the pages (only for documents written by the editor) */
    var ink = false
    private val W: Int
    private val H: Int
    private val ml: Float
    private val mr: Float
    private var mt: Float
    private val mb: Float
    private val hasDesign: Boolean
    /** Character offsets where the page editor started a new page; the PDF follows them so pages look exactly like on screen. */
    var breaks: Set<Int> = emptySet()
    private val usedBreaks = HashSet<Int>()
    /** Thin frame around every page + page numbers as "- n -". */
    var border = false
    /** Background of page n (1-based) when pages have different designs; null = plain page. */
    var pageBg: ((Int) -> Bitmap?)? = null
    private val fresh: Boolean get() = y <= mt + 0.5f
    /** Number of text columns (1-3) and whether the first column is on the right (right-to-left documents). */
    var cols = 1
    var colRtl = false
    private var col = 0
    private val gutter = 18f

    private fun columnWidth(): Float = ((W - ml - mr - (cols - 1) * gutter) / cols).coerceAtLeast(20f)
    private fun colLeft(): Float {
        val vk = if (colRtl) cols - 1 - col else col
        return ml + vk * (columnWidth() + gutter)
    }
    /** The next column of this page, or the next page after the last column. */
    private fun nextColumnOrPage() {
        if (col < cols - 1) { col++; y = mt } else newPage()
    }

    init {
        val (pw, ph) = Paper.pt(paper, landscape)
        W = pw; H = ph
        val useBg = bg != null && spec != null && !landscape
        val all = if (useBg) listOf(spec!!) + extraSpecs else emptyList()
        ml = if (useBg) W * all.maxOf { it.mx } else (margin?.l ?: 40f)
        mr = if (useBg) W * all.maxOf { it.mx } else (margin?.r ?: 40f)
        mt = if (useBg) H * all.maxOf { it.mt } else (margin?.t ?: 40f)
        mb = if (useBg) H * all.maxOf { it.mb } else (margin?.b ?: 40f)
        hasDesign = useBg
    }

    /** Running header text drawn at the top of every page (with a thin line). */
    var headerText = ""
    var headerColor = 0xFF666666.toInt()
    var headerSize = 11f
    var headerDist = 35.4f
    var headerLine = true
    var headerAlign = -1
    var headerFont: String? = null

    /** The text starts below the header (Word: the body moves down when the header is taller than the top margin). Call after the header is set. */
    fun applyHeaderTop() {
        if (headerText.isNotEmpty() && !hasDesign) mt = maxOf(mt, headerDist + headerSize * 1.25f + 8f)
    }

    fun startNewPage() { pending = true }

    private fun closePage() {
        val pg = page ?: return
        if (ink && InkStore.strokes.isNotEmpty()) InkStore.draw(pg.canvas, W.toFloat(), H.toFloat(), 0f, n - 1)
        val hdrNum = headerText.isNotEmpty() && numbers && pn.loc == 0
        if (headerText.isNotEmpty()) {
            val hy = if (hasDesign) (mt - 24f).coerceAtLeast(16f) else headerDist + headerSize * 0.9f
            RunHeader.draw(pg.canvas, headerText, if (hdrNum) PageNum.label(n, pn, border) else null, ml, W.toFloat() - mr, hy, headerSize, colRtl, pn.align, 0.6f, headerColor, headerLine, headerAlign, headerFont)
        }
        if (numbers && !(headerText.isNotEmpty() && pn.loc == 0)) Render.drawPageNumber(pg.canvas, W.toFloat(), H.toFloat(), ml, mr, mt, mb, PageNum.label(n, pn, border), pn)
        doc.finishPage(pg)
    }

    private fun newPage() {
        closePage()
        n++
        page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, n).create())
        val pf = pageBg
        val pbg: Bitmap? = if (!hasDesign) null else if (pf != null) pf(n) else bg
        if (pbg != null) page!!.canvas.drawBitmap(pbg, null, RectF(0f, 0f, W.toFloat(), H.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
        if (border) {
            val inset = minOf(minOf(ml, mr), minOf(mt, mb)) * 0.55f
            val bp = Paint(Paint.ANTI_ALIAS_FLAG)
            bp.color = Color.BLACK; bp.style = Paint.Style.STROKE; bp.strokeWidth = 1f
            page!!.canvas.drawRect(inset, inset, W - inset, H - inset, bp)
        }
        y = mt
        col = 0
        pending = false
    }

    private fun ensure() {
        if (pendingBreaks > 0) {
            // breaks before anything was drawn (blank first page) are dropped; later ones become real (possibly blank) pages
            val k = pendingBreaks
            pendingBreaks = 0
            if (page != null) repeat(k) { newPage() }
        }
        if (page == null || pending) newPage()
    }

    private fun drawLayout(lay: StaticLayout, w: Int, off: Int = 0) {
        for (i in 0 until lay.lineCount) {
            val top = lay.getLineTop(i)
            val bot = lay.getLineBottom(i)
            val h = bot - top
            ensure()
            val ls = off + lay.getLineStart(i)
            val le = off + lay.getLineEnd(i)
            // the editor says: a new page starts here. The PDF wraps lines a little differently from the screen, so the
            // break is matched to the line that CONTAINS the offset (not only a line starting exactly there).
            var hit = -1
            if (breaks.isNotEmpty()) {
                for (b in breaks) if (b !in usedBreaks && b >= ls && (b < le || b == ls)) { hit = b; break }
            }
            if (hit >= 0) {
                usedBreaks.add(hit)
                if (!fresh) newPage()
            }
            // with the editor's page breaks known, allow a small overflow instead of creating an extra, almost empty page
            // just before the editor's own page break
            val limit = H - mb + (if (breaks.isNotEmpty()) h * 1.2f else 0f)
            if (!fresh && y + h > limit) {
                var nextBreak = Int.MAX_VALUE
                for (b in breaks) if (b !in usedBreaks && b >= ls && b < nextBreak) nextBreak = b
                val closeToBreak = nextBreak != Int.MAX_VALUE && nextBreak - ls < 160 && y + h <= H - 8f
                if (!closeToBreak) nextColumnOrPage()
            }
            val c = page!!.canvas
            c.save()
            c.translate(colLeft(), y - top)
            c.clipRect(0f, top.toFloat(), w.toFloat(), bot.toFloat())
            lay.draw(c)
            c.restore()
            y += (bot - top)
        }
    }

    /** Rich (spanned) text. Spans such as bold, colour, size, alignment are honoured; page breaks and |tables| are handled. */
    fun rich(t0: CharSequence, base: Int, font: String?, rtl: Boolean, justify: Boolean) {
        val t = withFontSpans(t0)
        val w = columnWidth().toInt().coerceAtLeast(10)
        val s = t.toString()
        // Leading page breaks / blank lines before the first real text, and anything after the last real text (blank lines,
        // page breaks) are not content. Without this the PDF got an empty first page and an empty last page.
        var first = 0
        while (first < s.length && (s[first].isWhitespace() || s[first] == PAGE_BREAK)) first++
        var last = s.length
        while (last > first && (s[last - 1].isWhitespace() || s[last - 1] == PAGE_BREAK)) last--
        var start = 0
        run {
            var k = first - 1
            while (k >= 0 && s[k] != PAGE_BREAK) k--
            // only when a page break sits in front of the first text; plain leading blank lines are kept
            if (k >= 0) { start = k + 1; if (start < s.length && s[start] == '\n') start++ }
        }
        if (last <= start) return
        val total = last
        while (true) {
            val i = s.indexOf(PAGE_BREAK, start)
            val end = if (i < 0 || i >= total) total else i
            for (blk in Tables.split(s, start, end)) {
                when (blk) {
                    is TextBlock -> {
                        var ps = blk.a
                        while (true) {
                            val nl = s.indexOf('\n', ps)
                            val pe = if (nl < 0 || nl > blk.b) blk.b else nl
                            // the newline written before a page-break mark leaves an empty "paragraph" at the end of the block.
                            // The editor has no such line, and on a full page it would spill onto a new page and then the
                            // page break adds another one: a blank page in the middle of the PDF. Skip it.
                            if (i >= 0 && i < total && pe == ps && pe >= blk.b && ps > blk.a) break
                            drawLayout(Render.layout(t.subSequence(ps, pe), base.toFloat(), font, rtl, justify, w, 1f), w, ps)
                            if (pe >= blk.b) break
                            ps = pe + 1
                        }
                    }
                    is TableBlock -> drawTable(t, blk, base, font, rtl, w)
                }
            }
            if (i < 0 || i >= total) break
            // the next page is only started when something is drawn on it (see ensure)
            if (page != null) pendingBreaks++
            start = i + 1
            if (start < s.length && s[start] == '\n') start++
        }
    }

    private fun drawTable(t: CharSequence, tb: TableBlock, base: Int, font: String?, rtl: Boolean, w: Int) {
        val cols = tb.rows.maxOf { it.size }.coerceAtLeast(1)
        val fr = TableWidths.of(t, tb, cols)
        val cws = FloatArray(cols) { (if (fr != null) fr[it] else 1f / cols) * w }
        val cxs = FloatArray(cols)
        for (i in 1 until cols) cxs[i] = cxs[i - 1] + cws[i - 1]
        val pad = 4f
        val border = Paint(Paint.ANTI_ALIAS_FLAG)
        border.color = Color.BLACK
        border.style = Paint.Style.STROKE
        border.strokeWidth = 0.8f
        val shade = Paint()
        shade.color = 0xFFE8EEF7.toInt()
        shade.style = Paint.Style.FILL
        val tStyle = TableStyles.of(t, tb)
        for ((ri, row) in tb.rows.withIndex()) {
            val head = tb.header && ri == 0
            val lays = ArrayList<StaticLayout>()
            for (ci in 0 until cols) {
                val cell = row.getOrNull(ci)
                val txt: CharSequence = if (cell == null || cell.second <= cell.first) "" else t.subSequence(cell.first, cell.second)
                val shown: CharSequence = if (head && txt.isNotEmpty()) {
                    val sb = SpannableStringBuilder(txt)
                    sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb
                } else txt
                lays.add(Render.layout(shown, base.toFloat(), font, rtl, false, (cws[ci] - 2 * pad).toInt().coerceAtLeast(10), 1f))
            }
            var rowH = 0f
            for (l in lays) rowH = maxOf(rowH, l.height.toFloat())
            rowH += 2 * pad + RowHeights.of(t, row) * 0.75f
            ensure()
            if (y + rowH > H - mb) nextColumnOrPage()
            val c = page!!.canvas
            for (ci in 0 until cols) {
                val colW = cws[ci]
                val x = colLeft() + (if (rtl) w - cxs[ci] - colW else cxs[ci])
                val r = RectF(x, y, x + colW, y + rowH)
                val rowFill = RowFills.of(t, row)
                if (rowFill != 0) { shade.color = rowFill; c.drawRect(r, shade) }
                else if (tStyle > 0) { shade.color = TableStyles.fill(tStyle, ri); c.drawRect(r, shade) }
                else if (head) { shade.color = 0xFFE8EEF7.toInt(); c.drawRect(r, shade) }
                c.drawRect(r, border)
                c.save()
                c.translate(x + pad, y + pad)
                c.clipRect(0f, 0f, colW - 2 * pad, rowH - 2 * pad)
                lays[ci].draw(c)
                c.restore()
            }
            y += rowH
        }
        y += 8f
    }

    fun text(t: String, f: Fmt) {
        ensure()
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = f.size.toFloat()
            color = Color.BLACK
            typeface = Typeface.create(
                Typeface.DEFAULT,
                when { f.bold && f.italic -> Typeface.BOLD_ITALIC; f.bold -> Typeface.BOLD; f.italic -> Typeface.ITALIC; else -> Typeface.NORMAL }
            )
        }
        val w = (W - ml - mr).toInt().coerceAtLeast(10)
        val al = when (f.align) {
            1 -> Layout.Alignment.ALIGN_CENTER
            2 -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        val dir = if (f.rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR
        for (para in t.replace("\r", "").split("\n")) {
            val lay = StaticLayout.Builder.obtain(para, 0, para.length, tp, w)
                .setAlignment(al).setTextDirection(dir).setLineSpacing(0f, 1.25f * Doc.lineSpacing).build()
            drawLayout(lay, w)
        }
    }

    fun image(b: Bitmap) {
        ensure()
        val s = minOf((W - ml - mr) / b.width, (H - mt - mb) / b.height)
        val h = b.height * s
        if (y + h > H - mb) newPage()
        page!!.canvas.drawBitmap(b, null, RectF(ml, y, ml + b.width * s, y + h), Paint(Paint.FILTER_BITMAP_FLAG))
        y += h + 12f
    }

    /** Stamps the signature under the last text (or at the bottom right if there is room) of the last page. */
    fun signature(b: Bitmap) {
        ensure()
        val w = minOf(150f, (W - ml - mr) / 2f)
        val h = w * b.height / b.width
        if (y + h + 10f > H - mb) newPage()
        val x = if (colRtl) ml else W - mr - w
        page!!.canvas.drawBitmap(b, null, RectF(x, y + 10f, x + w, y + 10f + h), Paint(Paint.FILTER_BITMAP_FLAG))
        y += h + 20f
    }

    fun finish(out: File) {
        pendingBreaks = 0   // pages that were asked for but stayed empty at the very end are not written
        if (page == null) newPage()
        closePage()
        page = null
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
    }

    fun discard() { try { doc.close() } catch (_: Exception) {} }
}
