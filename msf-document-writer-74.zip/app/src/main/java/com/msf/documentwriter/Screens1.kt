@file:OptIn(ExperimentalMaterial3Api::class)

package com.msf.documentwriter

import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

fun openFile(nav: NavController, ctx: Context, f: File) {
    // a document with a password (File → Document Encryption) asks for it first
    FileTools.gate(ctx, f) { openFileNow(nav, ctx, f) }
}

private fun openFileNow(nav: NavController, ctx: Context, f: File) {
    when (kindOf(f.name)) {
        DocKind.WORD, DocKind.TEXT ->
            if (f.extension.lowercase() == "rtf") Actions.open(ctx, f) else {
                Prefs.setInt(ctx, "viewed", Prefs.viewed(ctx) + 1)
                // one click: the document is read in the background (no frozen white screen) and opens on the Blank Page
                // breadcrumb: if the app is killed while opening, the next open of this file uses the light "safe mode"
                val crashed = Prefs.str(ctx, "opening", "") == f.name
                Prefs.setStr(ctx, "opening", f.name)
                RichDocx.progress = { p -> Work.progress("دستاویز کھل رہی ہے… $p% / Opening… (v$APP_VER)") }
                Work.run("دستاویز کھل رہی ہے… / Opening… (v$APP_VER)", { Doc.open(ctx, f, crashed); true }) { ok ->
                    RichDocx.progress = null
                    if (ok == true) {
                        nav.navigate("blank")
                    } else { Prefs.setStr(ctx, "opening", ""); toast(ctx, "فائل نہیں کھل سکی / Could not open file\n" + Doc.diag) }
                }
            }
        else -> Actions.open(ctx, f)
    }
}

fun goHome(nav: NavController) { nav.popBackStack("home", false) }

@Composable
fun Tag(t: String, c: Color) {
    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(c).padding(horizontal = 12.dp, vertical = 4.dp)) {
        Text(t, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

// ───────────────────────── DISCOVER (all tools) ─────────────────────────
@Composable
fun DiscoverScreen(nav: NavController) {
    val ctx = LocalContext.current
    val name = remember { Prefs.name(ctx) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val n = uris.count { Store.importUri(ctx, it) != null }
            toast(ctx, if (n > 0) "$n فائل شامل ہو گئی / $n file(s) added" else "سپورٹڈ فائل نہیں ملی / No supported file found")
            nav.navigate("docs/browse")
        }
    }
    val openFm = rememberOpenFromManager()
    val openDocx = rememberOpenDocx()
    val tiles = listOf(
        TileData("Open Word (.docx)", "ورڈ فائل ایک کلک پر کھولیں", Color(0xFF1E5CD6), Color(0xFFE3EEFF), letter = "W") { openDocx() },
        TileData("Open from File Manager", "فائل مینیجر سے کھولیں", Color(0xFF00897B), Color(0xFFDDF5F2), icon = Icons.Filled.FolderOpen) { openFm() },
        TileData("New Document", "نئی دستاویز بنائیں", Color(0xFF1E88E5), Color(0xFFE3F0FF), icon = Icons.Filled.NoteAdd) { nav.navigate("new") },
        TileData("Blank Page", "خالی صفحہ", Color(0xFF455A64), Color(0xFFE6ECEF), icon = Icons.Filled.CropPortrait) {
            Doc.new(ctx, DocKind.WORD); nav.navigate("blank")
        },
        TileData("My Documents", "میری فائلیں", Color(0xFFF59E0B), Color(0xFFFFF3D6), icon = Icons.Filled.Folder) { nav.navigate("docs/browse") },
        TileData("Word Documents", "ورڈ ڈاکیومنٹ بنائیں", Color(0xFF1E5CD6), Color(0xFFE3EEFF), letter = "W") { nav.navigate("words") },
        TileData("PDF Maker", "پی ڈی ایف بنائیں", Color(0xFFE53935), Color(0xFFFFE8E8), icon = Icons.Filled.PictureAsPdf) { nav.navigate("pdfmaker") },
        TileData("Text Formatting", "ٹیکسٹ فارمیٹنگ", Color(0xFF14B8A6), Color(0xFFDDF7F1), icon = Icons.Filled.Palette) {
            Doc.new(ctx, DocKind.WORD); nav.navigate("format")
        },
        TileData("Urdu & Arabic Writing", "اردو اور عربی میں لکھیں", Color(0xFF7C4DFF), Color(0xFFEDE7FF), icon = Icons.Filled.Translate) {
            Doc.new(ctx, DocKind.WORD, rtl = true); nav.navigate("urdu")
        },
        TileData("Share Document", "دستاویز شیئر کریں", Color(0xFF0EA5E9), Color(0xFFDDF3FF), icon = Icons.Filled.Share) { nav.navigate("docs/share") },
        TileData("Print Document", "دستاویز پرنٹ کریں", Color(0xFF3949AB), Color(0xFFE6E9FB), icon = Icons.Filled.Print) { nav.navigate("print") },
        TileData("Search Documents", "فائلیں تلاش کریں", Color(0xFF16A34A), Color(0xFFDFF7E8), icon = Icons.Filled.Search) { nav.navigate("search") },
        TileData("Settings", "سیٹنگز", Color(0xFF5E35B1), Color(0xFFECE7FA), icon = Icons.Filled.Settings) { nav.navigate("settings") },
        TileData("Privacy & Security", "حفاظت", Color(0xFF0288D1), Color(0xFFD9F2FF), icon = Icons.Filled.Security) { nav.navigate("security") },
        TileData("About", "ایپ کے بارے میں", Color(0xFF1E5CD6), Color(0xFFE3EEFF), icon = Icons.Filled.Info) { nav.navigate("about") }
    )
    Scaffold(
        containerColor = Blue,
        bottomBar = {
            RecentBar(nav, 3)
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 22.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(painterResource(R.mipmap.ic_launcher), null, Modifier.size(86.dp).clip(RoundedCornerShape(20.dp)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("MSF", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        buildAnnotatedString { append("Document "); withStyle(SpanStyle(color = Yellow)) { append("Writer") } },
                        color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold
                    )
                    Text("آسان طریقے سے اپنی دستاویزات بنائیں", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Tag("DOCX", Color(0xFF1E5CD6)); Tag("PDF", Color(0xFFE53935)); Tag("TXT", Color(0xFF16A34A))
                }
            }
            Column(
                Modifier.weight(1f).fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)).background(Bg)
                    .verticalScroll(rememberScrollState()).padding(14.dp)
            ) {
                Card(
                    onClick = { nav.navigate("profile") }, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE3EEFF))
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(54.dp).clip(CircleShape).background(Blue), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(34.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("MSF Document Writer", color = Blue)
                        }
                        Icon(Icons.Filled.ChevronRight, null, tint = Blue)
                    }
                }
                Spacer(Modifier.height(12.dp))
                TileGrid(tiles, 118.dp)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

// ───────────────────────── NEW DOCUMENT ─────────────────────────
data class Template(val en: String, val ur: String, val title: String, val body: String, val rtl: Boolean, val icon: ImageVector, val color: Color, val trans: String = "")

val Templates = listOf(
    Template("Letter", "خط", "Letter", "Date: \n\nTo,\n[Recipient Name]\n[Address]\n\nSubject: \n\nDear Sir/Madam,\n\n[Write your letter here]\n\nYours sincerely,\n[Your Name]", false, Icons.Filled.Mail, Color(0xFF1E5CD6)),
    Template("Resume", "سوانح حیات", "Resume", "[Your Name]\nPhone: \nEmail: \n\nObjective\n\n\nEducation\n\n\nExperience\n\n\nSkills\n\n\nLanguages\n", false, Icons.Filled.Badge, Color(0xFF0EA5E9)),
    Template("Report", "رپورٹ", "Report", "Title: \nPrepared by: \nDate: \n\n1. Introduction\n\n\n2. Findings\n\n\n3. Conclusion\n", false, Icons.Filled.BarChart, Color(0xFF16A34A)),
    Template("Urdu Document", "اردو دستاویز", "اردو دستاویز", "عنوان:\nتاریخ:\n\nبسم اللہ الرحمٰن الرحیم\n\n", true, Icons.Filled.Translate, Color(0xFF0F766E)),
    Template("Arabic Document", "مستند عربي", "مستند عربي", "بسم الله الرحمن الرحيم\n\nالعنوان:\nالتاريخ:\n\n", true, Icons.Filled.MenuBook, Color(0xFF92400E))
)

@Composable
fun NewDocScreen(nav: NavController) {
    val ctx = LocalContext.current
    var sel by remember { mutableIntStateOf(when (Prefs.defFormat(ctx)) { 0 -> 0; 1 -> 1; else -> 2 }) }
    var showTpl by remember { mutableStateOf(false) }
    var design by remember { mutableIntStateOf(0) }
    fun go(kind: DocKind, title: String = "", body: String = "", rtl: Boolean = false, img: Boolean = false) {
        Doc.new(ctx, kind, title, body, rtl); Doc.pickImage = img; Doc.pageDesign = design; nav.navigate("editor")
    }
    val types = listOf(
        TileData("Word Document", "ورڈ دستاویز", Color(0xFF1E5CD6), Color(0xFFE8F0FF), letter = "W", selected = sel == 0) { sel = 0 },
        TileData("PDF Document", "پی ڈی ایف دستاویز", Color(0xFFE53935), Color(0xFFFFEEEE), icon = Icons.Filled.PictureAsPdf, selected = sel == 1) { sel = 1 },
        TileData("Text Document", "سادہ متن دستاویز", Color(0xFF16A34A), Color(0xFFE3F8EC), letter = "T", selected = sel == 2) { sel = 2 },
        TileData("Document with Image", "تصویر کے ساتھ دستاویز", Color(0xFF7C4DFF), Color(0xFFEFE9FF), icon = Icons.Filled.Image, selected = sel == 3) { sel = 3 },
        TileData("From Template", "ٹیمپلیٹ سے بنائیں", Color(0xFFF59E0B), Color(0xFFFFF4DC), icon = Icons.Filled.Description, selected = sel == 4) { sel = 4 },
        TileData("Blank Document", "خالی دستاویز", Color(0xFF1E88E5), Color(0xFFE3F2FF), icon = Icons.Filled.NoteAdd, selected = sel == 5) { sel = 5 }
    )
    Scaffold(
        containerColor = Bg,
        topBar = { AppHeader("آسان طریقے سے اپنی دستاویزات بنائیں", onBack = { nav.popBackStack() }, onHome = { goHome(nav) }) },
        bottomBar = {
            Box(Modifier.background(Bg).padding(12.dp)) {
                Button(
                    onClick = {
                        when (sel) {
                            0 -> go(DocKind.WORD)
                            1 -> go(DocKind.PDF)
                            2 -> go(DocKind.TEXT)
                            3 -> go(DocKind.PDF, img = true)
                            4 -> showTpl = true
                            else -> { Doc.new(ctx, DocKind.WORD); Doc.pageDesign = 0; nav.navigate("blank") }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(60.dp), shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) {
                    Icon(Icons.Filled.NoteAdd, null)
                    Spacer(Modifier.width(10.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Create New Document", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("نئی دستاویز بنائیں", fontSize = 13.sp)
                    }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(14.dp)) {
            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFDCEBFF))
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)).background(Blue), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.NoteAdd, null, tint = Color.White, modifier = Modifier.size(38.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("New Document", fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, color = Color(0xFF0A2A66))
                        Text("نئی دستاویز بنائیں", fontSize = 18.sp)
                        Text("اپنی تحریر، رپورٹ یا کوئی بھی دستاویز تیار کریں۔", fontSize = 12.sp, color = Color.DarkGray)
                    }
                }
            }
            SectionTitle("Select Document Type", "دستاویز کی قسم منتخب کریں")
            TileGrid(types, 118.dp)
            SectionTitle("Page Design", "پیج ڈیزائن منتخب کریں")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GalleryDesignButton(true) { design = it }
                (listOf<PageDesigns.Spec?>(null) + CustomDesigns.list() + PageDesigns.all).forEach { sp ->
                    val id = sp?.id ?: 0
                    val on = design == id
                    Column(
                        Modifier.width(104.dp).clip(RoundedCornerShape(12.dp)).background(if (on) Color(0xFFDCEBFF) else Color.White)
                            .border(if (on) 2.dp else 1.dp, if (on) Blue else Color(0xFFD5E0F2), RoundedCornerShape(12.dp))
                            .clickable { design = id }.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val tb = if (sp != null) PageDesigns.bitmap(ctx, id) else null
                        if (tb != null) Image(
                            bitmap = tb.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit,
                            modifier = Modifier.width(70.dp).height(100.dp)
                        ) else Box(Modifier.width(70.dp).height(100.dp).background(Color.White).border(1.dp, Color(0xFFBBC7DA)))
                        Spacer(Modifier.height(4.dp))
                        Text(sp?.en ?: "Plain page", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(sp?.ur ?: "سادہ صفحہ", fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
            SectionTitle("Recent Templates", "حالیہ ٹمیلیٹس")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Templates.forEach { t ->
                    Column(
                        Modifier.width(92.dp).clip(RoundedCornerShape(12.dp)).background(Color.White)
                            .clickable { go(DocKind.WORD, t.title, t.body, t.rtl) }.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(64.dp, 76.dp).background(Color(0xFFF4F7FC), RoundedCornerShape(6.dp)).border(1.dp, Color(0xFFDDE6F5), RoundedCornerShape(6.dp)),
                            contentAlignment = Alignment.Center
                        ) { Icon(t.icon, null, tint = t.color, modifier = Modifier.size(34.dp)) }
                        Spacer(Modifier.height(4.dp))
                        Text(t.en, fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
                        Text(t.ur, fontSize = 11.sp, color = Color.DarkGray, textAlign = TextAlign.Center)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
    if (showTpl) AlertDialog(
        onDismissRequest = { showTpl = false },
        title = { Text("Template / ٹیمپلیٹ منتخب کریں") },
        text = {
            Column {
                Templates.forEach { t ->
                    TextButton(onClick = { showTpl = false; go(DocKind.WORD, t.title, t.body, t.rtl) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(t.icon, null, tint = t.color)
                        Spacer(Modifier.width(10.dp))
                        Text("${t.en}  —  ${t.ur}", modifier = Modifier.weight(1f))
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { showTpl = false }) { Text("Cancel") } }
    )
}

