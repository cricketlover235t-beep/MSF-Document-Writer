package com.msf.documentwriter

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class DocKind(val en: String, val ur: String) {
    WORD("Word Document", "ورڈ دستاویز"),
    PDF("PDF Document", "پی ڈی ایف دستاویز"),
    TEXT("Text Document", "سادہ متن دستاویز"),
    IMAGE("Image File", "تصویر")
}

data class Fmt(
    val size: Int = 14,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val align: Int = 0, // 0 start, 1 center, 2 end
    val rtl: Boolean = false
)

fun kindOf(name: String): DocKind? = when (name.substringAfterLast('.', "").lowercase()) {
    "docx" -> DocKind.WORD
    "pdf" -> DocKind.PDF
    "txt", "rtf" -> DocKind.TEXT
    "jpg", "jpeg", "png", "bmp", "webp" -> DocKind.IMAGE
    else -> null
}

fun fmtSize(b: Long): String =
    if (b < 1024 * 1024) "${maxOf(1L, b / 1024)} KB" else String.format(Locale.US, "%.2f MB", b / 1048576.0)

fun fmtDate(t: Long): String = SimpleDateFormat("yyyy-MM-dd  hh:mm a", Locale.US).format(Date(t))

fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())

fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()

object Store {
    fun dir(c: Context): File = File(c.filesDir, "documents").apply { mkdirs() }

    fun list(c: Context, includeHidden: Boolean = false): List<File> {
        val hidden = if (includeHidden) emptySet() else Prefs.items(c, "hidden")
        return dir(c).listFiles()?.filter { it.isFile && kindOf(it.name) != null && it.name !in hidden }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
    }

    fun uniqueFile(c: Context, base: String, ext: String): File {
        val clean = base.trim().ifEmpty { "Document" }.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        var f = File(dir(c), "$clean.$ext")
        var i = 1
        while (f.exists()) { f = File(dir(c), "$clean ($i).$ext"); i++ }
        return f
    }

    fun uri(c: Context, f: File): Uri = FileProvider.getUriForFile(c, c.packageName + ".fileprovider", f)

    fun nameOf(c: Context, u: Uri): String {
        var n: String? = null
        try {
            c.contentResolver.query(u, null, null, null, null)?.use { cur ->
                if (cur.moveToFirst()) {
                    val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) n = cur.getString(i)
                }
            }
        } catch (_: Exception) {}
        return n ?: u.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    fun importUri(c: Context, u: Uri): File? {
        val name = nameOf(c, u)
        if (kindOf(name) == null) return null
        val out = uniqueFile(c, name.substringBeforeLast('.'), name.substringAfterLast('.').lowercase())
        return try {
            c.contentResolver.openInputStream(u)?.use { i -> FileOutputStream(out).use { o -> i.copyTo(o) } }
            if (out.exists()) out else null
        } catch (_: Exception) { null }
    }

    fun plainText(f: File): String = try {
        if (f.extension.lowercase() == "docx") FileInputStream(f).use { Docx.parse(it).first } else f.readText().take(200000)
    } catch (_: Exception) { "" }

    fun mime(f: File): String = when (f.extension.lowercase()) {
        "pdf" -> "application/pdf"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "txt" -> "text/plain"
        "zip" -> "application/zip"
        "rtf" -> "text/rtf"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "bmp" -> "image/bmp"
        "webp" -> "image/webp"
        else -> "*/*"
    }
}

object Actions {
    fun open(c: Context, f: File) {
        Prefs.setInt(c, "viewed", Prefs.viewed(c) + 1)
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Store.uri(c, f), Store.mime(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { c.startActivity(i) } catch (e: ActivityNotFoundException) {
            toast(c, "کھولنے کے لیے ایپ نہیں ملی / No app found to open this file")
        }
    }

    fun share(c: Context, f: File) {
        val i = Intent(Intent.ACTION_SEND).setType(Store.mime(f))
            .putExtra(Intent.EXTRA_STREAM, Store.uri(c, f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(i, f.name))
        Prefs.add(c, "shared", f.name)
    }

    fun print(c: Context, f: File) {
        val pdf: File = if (f.extension.lowercase() == "pdf") f else (Converter.toTempPdf(c, f) ?: run {
            toast(c, "پرنٹ کے لیے تبدیل نہیں ہو سکی / Cannot print this file"); return
        })
        printPdf(c, f.name, pdf, Prefs.printAttrs(c))
    }

    fun printPdf(c: Context, jobName: String, pdf: File, attrs: PrintAttributes) {
        val pm = c.getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print(jobName, object : PrintDocumentAdapter() {
            override fun onLayout(
                old: PrintAttributes?, new: PrintAttributes?, cs: CancellationSignal?,
                cb: LayoutResultCallback, extras: Bundle?
            ) {
                if (cs?.isCanceled == true) { cb.onLayoutCancelled(); return }
                cb.onLayoutFinished(
                    PrintDocumentInfo.Builder(jobName.substringBeforeLast('.') + ".pdf")
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true
                )
            }

            override fun onWrite(
                pages: Array<out PageRange>?, dest: ParcelFileDescriptor, cs: CancellationSignal?,
                cb: WriteResultCallback
            ) {
                try {
                    FileInputStream(pdf).use { i -> FileOutputStream(dest.fileDescriptor).use { o -> i.copyTo(o) } }
                    cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) { cb.onWriteFailed(e.message) }
            }
        }, attrs)
    }
}
