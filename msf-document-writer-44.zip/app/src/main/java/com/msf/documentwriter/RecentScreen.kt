@file:OptIn(ExperimentalMaterial3Api::class)

package com.msf.documentwriter

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val RcBg = Color(0xFF1B1D21)
private val RcBar = Color(0xFF26282C)
private val RcField = Color(0xFF2E3035)
private val RcAcc = Color(0xFF3D6FF0)
private val RcText = Color(0xFFF1F1F1)
private val RcGrey = Color(0xFF9EA2A8)
private val RcTile = Color(0xFF2B3040)

/** Bottom bar of the Recent design: Recent · Files · Scanner · Discover · Settings. [selected] 0, 1, 3 or 4 (2 = Scanner). */
@Composable
fun RecentBar(nav: NavController, selected: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var photo by remember { mutableStateOf<File?>(null) }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = photo
        if (ok && f != null && f.exists()) {
            scope.launch {
                val out = withContext(Dispatchers.IO) {
                    try {
                        val b = PdfBuilder(Prefs.paper(ctx), Prefs.landscape(ctx))
                        if (Converter.append(ctx, Store.uri(ctx, f), "scan.jpg", b)) {
                            val o = Store.uniqueFile(ctx, "Scan_" + stamp(), "pdf")
                            b.finish(o)
                            o
                        } else { b.discard(); null }
                    } catch (e: Throwable) { null } finally { f.delete() }
                }
                if (out != null) {
                    toast(ctx, "اسکین PDF بن گئی / Scan saved: ${out.name}")
                    goTo(nav, "docs/browse")
                } else toast(ctx, "اسکین نہیں ہو سکا / Scan failed")
            }
        }
    }
    fun scan() {
        try {
            val f = File(ctx.cacheDir, "scan_" + System.currentTimeMillis() + ".jpg")
            photo = f
            cam.launch(Store.uri(ctx, f))
        } catch (e: Throwable) { toast(ctx, "کیمرہ نہیں کھل سکا / Camera not available") }
    }
    Row(Modifier.fillMaxWidth().background(RcBar).height(76.dp), verticalAlignment = Alignment.CenterVertically) {
        RcNavItem(Icons.Filled.Home, "Recent", selected == 0, Modifier.weight(1f)) { if (selected != 0) goHome(nav) }
        RcNavItem(Icons.Filled.Description, "Files", selected == 1, Modifier.weight(1f)) { goTo(nav, "docs/browse") }
        Box(Modifier.weight(1f).fillMaxHeight().clickable { scan() }) {
            Box(
                Modifier.align(Alignment.TopCenter).offset(y = (-22).dp).size(64.dp).clip(CircleShape).background(RcAcc),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.CameraAlt, "Scanner", tint = Color.White, modifier = Modifier.size(32.dp)) }
            Text("Scanner", color = RcText, fontSize = 13.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp))
        }
        RcNavItem(Icons.Filled.Explore, "Discover", selected == 3, Modifier.weight(1f)) { if (selected != 3) goTo(nav, "discover") }
        RcNavItem(Icons.Filled.Settings, "Settings", selected == 4, Modifier.weight(1f)) { if (selected != 4) goTo(nav, "settings") }
    }
}

@Composable
private fun RcNavItem(icon: ImageVector, label: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.fillMaxHeight().clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, label, tint = if (on) RcAcc else RcGrey, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (on) RcAcc else RcGrey, fontSize = 13.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
    }
}

@Composable
private fun RcKindTile(kind: DocKind) {
    Box(Modifier.size(46.dp).clip(RoundedCornerShape(10.dp)).background(RcTile), contentAlignment = Alignment.Center) {
        when (kind) {
            DocKind.WORD -> Icon(Icons.Filled.Description, null, tint = Color(0xFF4A8BEF), modifier = Modifier.size(28.dp))
            DocKind.TEXT -> Text("T", color = Color(0xFFB8C2E0), fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
            DocKind.PDF -> Icon(Icons.Filled.PictureAsPdf, null, tint = Color(0xFFE5524B), modifier = Modifier.size(28.dp))
            DocKind.IMAGE -> Icon(Icons.Filled.Image, null, tint = Color(0xFF4FC3F7), modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
private fun RcRow(f: File, starred: Boolean, nav: NavController, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val kind = kindOf(f.name) ?: DocKind.TEXT
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable { openFile(nav, ctx, f) }.padding(start = 14.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RcKindTile(kind)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(
                if (Prefs.showExt(ctx)) f.name else f.nameWithoutExtension,
                color = RcText, fontSize = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Text(
                SimpleDateFormat("dd/MM", Locale.US).format(Date(f.lastModified())) + " · My Documents" + (if (starred) "  ★" else ""),
                color = RcGrey, fontSize = 14.sp, maxLines = 1
            )
        }
        IconButton(onClick = { Actions.open(ctx, f) }) { Icon(Icons.Filled.OpenInNew, "Open with", tint = RcGrey) }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "More", tint = RcGrey) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Open / کھولیں") }, onClick = { menu = false; openFile(nav, ctx, f) })
                DropdownMenuItem(
                    text = { Text(if (starred) "Remove star / ستارہ ہٹائیں" else "Star / ستارہ لگائیں") },
                    onClick = { menu = false; Prefs.toggle(ctx, "starred", f.name); onChanged() }
                )
                DropdownMenuItem(text = { Text("Share / شیئر کریں") }, onClick = { menu = false; Actions.share(ctx, f) })
                DropdownMenuItem(text = { Text("Print / پرنٹ کریں") }, onClick = { menu = false; Actions.print(ctx, f) })
                DropdownMenuItem(text = { Text("Rename / نام بدلیں") }, onClick = { menu = false; rename = true })
                DropdownMenuItem(text = { Text("Delete / حذف کریں", color = Color(0xFFD32F2F)) }, onClick = { menu = false; del = true })
            }
        }
    }
    if (rename) {
        var nm by remember { mutableStateOf(f.nameWithoutExtension) }
        AlertDialog(
            onDismissRequest = { rename = false },
            title = { Text("Rename / نام تبدیل کریں") },
            text = { OutlinedTextField(value = nm, onValueChange = { nm = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val t = File(f.parentFile, nm.trim() + "." + f.extension)
                    if (nm.isNotBlank() && !t.exists()) f.renameTo(t)
                    rename = false; onChanged()
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { rename = false }) { Text("Cancel") } }
        )
    }
    if (del) AlertDialog(
        onDismissRequest = { del = false },
        title = { Text("Delete / حذف کریں") },
        text = { Text("${f.name}\n\nکیا آپ واقعی حذف کرنا چاہتے ہیں؟ / Delete this file?") },
        confirmButton = { TextButton(onClick = { f.delete(); del = false; onChanged() }) { Text("Delete", color = Color(0xFFD32F2F)) } },
        dismissButton = { TextButton(onClick = { del = false }) { Text("Cancel") } }
    )
}

// ───────────────────────── RECENT (home) ─────────────────────────
@Composable
fun HomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    val act = ctx as? Activity
    DisposableEffect(Unit) {
        act?.window?.statusBarColor = RcBg.toArgb()
        act?.window?.navigationBarColor = RcBar.toArgb()
        onDispose {
            act?.window?.statusBarColor = Blue.toArgb()
            act?.window?.navigationBarColor = Blue.toArgb()
        }
    }
    var tick by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var kindSel by remember { mutableIntStateOf(0) }
    var sort by remember { mutableIntStateOf(0) }
    var mMain by remember { mutableStateOf(false) }
    var mQuick by remember { mutableStateOf(false) }
    var mFilter by remember { mutableStateOf(false) }
    var mCreate by remember { mutableStateOf(false) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val n = uris.count { Store.importUri(ctx, it) != null }
            tick++
            toast(ctx, if (n > 0) "$n فائل شامل ہو گئی / $n file(s) added" else "سپورٹڈ فائل نہیں ملی / No supported file found")
        }
    }
    val all = remember(tick) { Store.list(ctx) }
    val starred = remember(tick) { Prefs.items(ctx, "starred") }
    val kinds = listOf<DocKind?>(null, DocKind.WORD, DocKind.PDF, DocKind.TEXT, DocKind.IMAGE)
    var list = all.filter { f ->
        (tab == 0 || f.name in starred) && (kinds[kindSel] == null || kindOf(f.name) == kinds[kindSel])
    }
    list = when (sort) {
        1 -> list.sortedBy { it.name.lowercase() }
        2 -> list.sortedByDescending { it.length() }
        else -> list
    }

    Scaffold(containerColor = RcBg, bottomBar = { RecentBar(nav, 0) }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                // search bar
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp).height(58.dp)
                        .clip(RoundedCornerShape(30.dp)).background(RcField),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        Box(Modifier.size(58.dp).clickable { mMain = true }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Menu, "Menu", tint = RcText, modifier = Modifier.size(30.dp))
                        }
                        Box(Modifier.align(Alignment.TopEnd).padding(top = 12.dp, end = 12.dp).size(9.dp).clip(CircleShape).background(Color(0xFFE5523B)))
                        DropdownMenu(expanded = mMain, onDismissRequest = { mMain = false }) {
                            DropdownMenuItem(text = { Text("Profile / پروفائل") }, onClick = { mMain = false; nav.navigate("profile") })
                            DropdownMenuItem(text = { Text("Import files / فائلیں شامل کریں") }, onClick = { mMain = false; importer.launch(arrayOf("*/*")) })
                            DropdownMenuItem(text = { Text("Privacy & Security / حفاظت") }, onClick = { mMain = false; nav.navigate("security") })
                            DropdownMenuItem(text = { Text("Settings / سیٹنگز") }, onClick = { mMain = false; goTo(nav, "settings") })
                            DropdownMenuItem(text = { Text("Terms / شرائط") }, onClick = { mMain = false; nav.navigate("terms") })
                            DropdownMenuItem(text = { Text("About / ایپ کے بارے میں") }, onClick = { mMain = false; nav.navigate("about") })
                        }
                    }
                    Text(
                        "Search files, tools", color = RcGrey, fontSize = 18.sp,
                        modifier = Modifier.weight(1f).fillMaxHeight().clickable { nav.navigate("search") }.wrapContentHeight(Alignment.CenterVertically)
                    )
                    Box {
                        Box(
                            Modifier.size(44.dp).clip(CircleShape).background(RcAcc).clickable { mQuick = true },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.FlashOn, "Quick tools", tint = Color.White, modifier = Modifier.size(26.dp)) }
                        DropdownMenu(expanded = mQuick, onDismissRequest = { mQuick = false }) {
                            DropdownMenuItem(text = { Text("PDF Maker / پی ڈی ایف بنائیں") }, onClick = { mQuick = false; nav.navigate("pdfmaker") })
                            DropdownMenuItem(text = { Text("Print / پرنٹ") }, onClick = { mQuick = false; nav.navigate("print") })
                            DropdownMenuItem(text = { Text("Share / شیئر") }, onClick = { mQuick = false; nav.navigate("docs/share") })
                            DropdownMenuItem(text = { Text("Search / تلاش") }, onClick = { mQuick = false; nav.navigate("search") })
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier.size(44.dp).clip(CircleShape).background(Color(0xFFD9D9D9)).clickable { nav.navigate("profile") },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Person, "Profile", tint = Color(0xFF6B6B6B), modifier = Modifier.size(30.dp)) }
                    Spacer(Modifier.width(8.dp))
                }
                // tabs + filter
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.width(14.dp))
                    listOf("Recent", "Starred").forEachIndexed { i, t ->
                        Column(Modifier.clickable { tab = i }.padding(horizontal = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(t, color = if (tab == i) RcAcc else RcGrey, fontSize = 18.sp, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal)
                            Spacer(Modifier.height(10.dp))
                            Box(Modifier.width(if (i == 0) 84.dp else 84.dp).height(3.dp).background(if (tab == i) RcAcc else Color.Transparent))
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Box {
                        IconButton(onClick = { mFilter = true }) { Icon(Icons.Filled.FilterList, "Filter", tint = RcText, modifier = Modifier.size(30.dp)) }
                        DropdownMenu(expanded = mFilter, onDismissRequest = { mFilter = false }) {
                            listOf("All files", "Word", "PDF", "Text", "Images").forEachIndexed { i, l ->
                                DropdownMenuItem(text = { Text((if (kindSel == i) "✓ " else "") + l) }, onClick = { kindSel = i; mFilter = false })
                            }
                            Divider()
                            listOf("Sort by date / تاریخ", "Sort by name / نام", "Sort by size / سائز").forEachIndexed { i, l ->
                                DropdownMenuItem(text = { Text((if (sort == i) "✓ " else "") + l) }, onClick = { sort = i; mFilter = false })
                            }
                        }
                    }
                    Spacer(Modifier.width(6.dp))
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF34363B)))
                LazyColumn(Modifier.weight(1f)) {
                    if (list.isEmpty()) item {
                        Text(
                            if (tab == 1) "ستارہ والی کوئی فائل نہیں / No starred files" else "کوئی فائل نہیں۔ Create دبائیں / No files yet. Tap Create.",
                            color = RcGrey, fontSize = 16.sp, modifier = Modifier.padding(28.dp)
                        )
                    }
                    items(list, key = { it.absolutePath }) { f -> RcRow(f, f.name in starred, nav) { tick++ } }
                    item { Spacer(Modifier.height(100.dp)) }
                }
            }
            // Create button
            Box(Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 18.dp)) {
                Row(
                    Modifier.height(60.dp).clip(RoundedCornerShape(30.dp)).background(Color(0xFF4285F4)).clickable { mCreate = true }.padding(horizontal = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Create", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
                DropdownMenu(expanded = mCreate, onDismissRequest = { mCreate = false }) {
                    DropdownMenuItem(text = { Text("New Document / نئی دستاویز") }, onClick = { mCreate = false; nav.navigate("new") })
                    DropdownMenuItem(text = { Text("Blank Page / خالی صفحہ") }, onClick = { mCreate = false; Doc.new(ctx, DocKind.WORD); nav.navigate("blank") })
                    DropdownMenuItem(text = { Text("Text Formatting / ٹیکسٹ فارمیٹنگ") }, onClick = { mCreate = false; Doc.new(ctx, DocKind.WORD); nav.navigate("format") })
                    DropdownMenuItem(text = { Text("Urdu & Arabic / اردو اور عربی") }, onClick = { mCreate = false; Doc.new(ctx, DocKind.WORD, rtl = true); nav.navigate("urdu") })
                    DropdownMenuItem(text = { Text("PDF Maker / پی ڈی ایف بنائیں") }, onClick = { mCreate = false; nav.navigate("pdfmaker") })
                    DropdownMenuItem(text = { Text("Import files / فائلیں شامل کریں") }, onClick = { mCreate = false; importer.launch(arrayOf("*/*")) })
                }
            }
        }
    }
}
