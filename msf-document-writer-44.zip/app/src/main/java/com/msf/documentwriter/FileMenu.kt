package com.msf.documentwriter

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.util.Base64
import android.widget.EditText
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MergeType
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.SaveAlt
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

private val FmBody = Color(0xFF1E1E1E)
private val FmGap = Color(0xFF111111)
private val FmLine = Color(0xFF333333)
private val FmIcon = Color(0xFFD6D6D6)
private val FmGrey = Color(0xFF8E8E8E)
private val FmAcc = Color(0xFF4A8BEF)

/** What the File tab needs from the editor. */
class FileActions(
    val onSave: () -> Unit,
    val onSaveAs: () -> Unit,
    val onExportPdf: () -> Unit,
    /** Saves the document and returns the saved file (null on failure). */
    val savedFile: () -> File?,
    /** Writes the current document to a temporary PDF (null on failure). Must be called on the main thread. */
    val makePdf: () -> File?,
    val docName: () -> String,
    /** words, characters */
    val textStats: () -> Pair<Int, Int>,
    val paperName: () -> String,
    val pageNow: Int
)

class FileResult(val title: String, val message: String, val files: List<File>)

@Composable
fun FileTab(a: FileActions) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<FileResult?>(null) }
    var dlg by remember { mutableStateOf("") }
    var enc by remember { mutableStateOf(FileTools.hasPass(ctx, a.docName())) }
    var pwd by remember { mutableStateOf("") }
    var pwd2 by remember { mutableStateOf("") }
    var range by remember { mutableStateOf("") }
    var extractSrc by remember { mutableStateOf<File?>(null) }
    var extractTotal by remember { mutableStateOf(0) }
    var infoRows by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }

    fun go(work: () -> FileResult?) {
        busy = true
        scope.launch {
            val r = try {
                withContext(Dispatchers.IO) { work() }
            } catch (e: Throwable) {
                FileResult("Error / خرابی", "کام نہیں ہو سکا / Could not finish.\n${e.message ?: ""}", emptyList())
            }
            busy = false
            if (r != null) result = r
        }
    }

    val cloudMime = when (Doc.kind) {
        DocKind.PDF -> "application/pdf"
        DocKind.TEXT -> "text/plain"
        else -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    }
    var cloudFile by remember { mutableStateOf<File?>(null) }
    val cloudL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(cloudMime)) { u: Uri? ->
        val f = cloudFile
        if (u != null && f != null) {
            try {
                ctx.contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                toast(ctx, "کاپی محفوظ ہو گئی / Copy saved")
            } catch (_: Exception) { toast(ctx, "کاپی محفوظ نہیں ہوئی / Copy failed") }
        }
    }

    val mergeL = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val cur = a.makePdf()
            go { FileTools.merge(ctx, cur, uris, a.docName()) }
        }
    }

    Column(Modifier.fillMaxWidth().background(FmGap)) {
        // ── group 1
        FmGroup {
            FmRow(Icons.Outlined.Save, "Save") { a.onSave() }
            FmDivider()
            FmRow(Icons.Outlined.SaveAlt, "Save As") { a.onSaveAs() }
            FmDivider()
            FmRow(Icons.Outlined.PictureAsPdf, "Export to PDF") { a.onExportPdf() }
        }
        Spacer(Modifier.height(10.dp))
        // ── group 2
        FmGroup {
            FmRow(Icons.Outlined.Share, "Share as Options", trailing = {
                FmShareDot(Color(0xFFE8466B), Icons.Outlined.Email) {
                    a.savedFile()?.let { FileTools.shareTo(ctx, it, "email") }
                }
                Spacer(Modifier.width(18.dp))
                FmShareDot(Color(0xFF5B9BE6), Icons.Outlined.Cloud) {
                    val f = a.savedFile()
                    if (f != null) { cloudFile = f; try { cloudL.launch(f.name) } catch (_: Exception) { toast(ctx, "Failed") } }
                }
                Spacer(Modifier.width(18.dp))
                FmShareDot(Color(0xFF25B34B), Icons.Outlined.Chat, round = true) {
                    a.savedFile()?.let { FileTools.shareTo(ctx, it, "whatsapp") }
                }
                Spacer(Modifier.width(14.dp))
                Text("• • •", color = FmGrey, fontSize = 14.sp, modifier = Modifier.clickable {
                    a.savedFile()?.let { Actions.share(ctx, it) }
                }.padding(8.dp))
            }) { a.savedFile()?.let { Actions.share(ctx, it) } }
            FmDivider()
            FmRow(Icons.Outlined.Image, "Export Images") {
                val pdf = a.makePdf()
                if (pdf == null) toast(ctx, "تصاویر نہیں بن سکیں / Could not export")
                else go { FileTools.exportImages(ctx, pdf, a.docName()) }
            }
        }
        Spacer(Modifier.height(10.dp))
        // ── group 3
        FmGroup {
            FmRow(Icons.Outlined.ContentCut, "Extract Pages") {
                val pdf = a.makePdf()
                if (pdf == null) toast(ctx, "Could not read pages")
                else {
                    extractSrc = pdf
                    extractTotal = FileTools.pageCount(pdf)
                    range = if (extractTotal > 0) "1" else ""
                    dlg = "extract"
                }
            }
            FmDivider()
            FmRow(Icons.Outlined.MergeType, "Merge Documents") {
                try { mergeL.launch(arrayOf("application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain", "image/*")) }
                catch (_: Exception) { toast(ctx, "Failed") }
            }
            FmDivider()
            FmRow(Icons.Outlined.Archive, "File Compressor") {
                val f = a.savedFile()
                if (f != null) go { FileTools.compress(ctx, f) }
            }
            FmDivider()
            FmRow(Icons.Outlined.Lock, "Document Encryption", trailing = {
                Switch(
                    checked = enc, onCheckedChange = null,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White, checkedTrackColor = FmAcc,
                        uncheckedThumbColor = Color.White, uncheckedTrackColor = Color(0xFF5A5A5A), uncheckedBorderColor = Color(0xFF5A5A5A)
                    )
                )
            }) {
                if (enc) { dlg = "decrypt"; pwd = "" }
                else {
                    // the document needs a saved name first
                    if (a.savedFile() != null) { dlg = "encrypt"; pwd = ""; pwd2 = "" }
                }
            }
            FmDivider()
            FmRow(Icons.Outlined.Print, "Print", trailing = {
                Text("Page ${a.pageNow}", color = FmGrey, fontSize = 17.sp)
            }) {
                val pdf = a.makePdf()
                if (pdf == null) toast(ctx, "پرنٹ نہیں ہو سکا / Cannot print")
                else try {
                    val job = File(ctx.cacheDir, "print_job.pdf")
                    pdf.copyTo(job, overwrite = true)
                    Actions.printPdf(ctx, a.docName().ifBlank { "Document" } + ".pdf", job, Prefs.printAttrs(ctx))
                } catch (e: Exception) { toast(ctx, "پرنٹ نہیں ہو سکا / Cannot print") }
            }
        }
        Spacer(Modifier.height(10.dp))
        // ── group 4
        FmGroup {
            FmRow(Icons.Outlined.Info, "File Info") {
                val saved = Doc.saved.values.firstOrNull { it.exists() }
                val pdf = a.makePdf()
                val (words, chars) = a.textStats()
                val rows = ArrayList<Pair<String, String>>()
                rows.add("Name / نام" to a.docName().ifBlank { "Document" })
                rows.add("Type / قسم" to (if (Doc.kind == DocKind.IMAGE) DocKind.WORD else Doc.kind).en)
                rows.add("Pages / صفحات" to (if (pdf != null) FileTools.pageCount(pdf).toString() else "-"))
                rows.add("Words / الفاظ" to words.toString())
                rows.add("Characters / حروف" to chars.toString())
                rows.add("Paper / کاغذ" to a.paperName())
                if (saved != null) {
                    rows.add("Size / سائز" to fmtSize(saved.length()))
                    rows.add("Modified / تبدیلی" to fmtDate(saved.lastModified()))
                    rows.add("Location / جگہ" to PublicSave.where(ctx))
                } else rows.add("Status / حالت" to "Not saved yet / ابھی محفوظ نہیں")
                if (enc) rows.add("Password / پاس ورڈ" to "On / آن")
                infoRows = rows
                dlg = "info"
            }
            FmDivider()
            FmRow(Icons.Outlined.HelpOutline, "Help & Feedback") { dlg = "help" }
        }
        Spacer(Modifier.height(26.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(40.dp).height(1.dp).background(FmLine))
            Text("  MSF DOCUMENT WRITER  ", color = FmGrey, fontSize = 15.sp)
            Box(Modifier.width(40.dp).height(1.dp).background(FmLine))
        }
        Spacer(Modifier.height(30.dp))
    }

    // ───────────── dialogs
    if (busy) AlertDialog(
        onDismissRequest = {}, confirmButton = {},
        title = { Text("Please wait… / انتظار کریں") },
        text = { Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
    )

    result?.let { r ->
        AlertDialog(
            onDismissRequest = { result = null },
            title = { Text(r.title) },
            text = { Text(r.message) },
            confirmButton = {
                Row {
                    if (r.files.isNotEmpty()) TextButton(onClick = { FileTools.shareMany(ctx, r.files) }) { Text("Share") }
                    if (r.files.isNotEmpty()) TextButton(onClick = { Actions.open(ctx, r.files.first()) }) { Text("Open") }
                    TextButton(onClick = { result = null }) { Text("OK") }
                }
            }
        )
    }

    if (dlg == "extract") AlertDialog(
        onDismissRequest = { dlg = "" },
        title = { Text("Extract Pages / صفحات نکالیں") },
        text = {
            Column {
                Text("Total pages / کل صفحات: $extractTotal")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = range, onValueChange = { range = it }, singleLine = true,
                    label = { Text("e.g. 1-3, 5") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val src = extractSrc
                val pages = FileTools.parseRange(range, extractTotal)
                if (src == null || pages.isEmpty()) toast(ctx, "صفحات درست لکھیں / Enter valid pages")
                else { dlg = ""; go { FileTools.extract(ctx, src, pages, a.docName()) } }
            }) { Text("Extract") }
        },
        dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
    )

    if (dlg == "encrypt") AlertDialog(
        onDismissRequest = { dlg = "" },
        title = { Text("Set Password / پاس ورڈ لگائیں") },
        text = {
            Column {
                Text("This document will ask for this password every time it is opened in the app.\nیہ دستاویز کھولنے پر پاس ورڈ مانگے گی۔", fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = pwd, onValueChange = { pwd = it }, singleLine = true, label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = pwd2, onValueChange = { pwd2 = it }, singleLine = true, label = { Text("Repeat password") },
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (pwd.length < 4) toast(ctx, "کم از کم 4 حروف / At least 4 characters")
                else if (pwd != pwd2) toast(ctx, "پاس ورڈ میل نہیں کھاتے / Passwords differ")
                else {
                    FileTools.setPass(ctx, a.docName(), pwd)
                    enc = true; dlg = ""
                    toast(ctx, "پاس ورڈ لگ گیا / Password set")
                }
            }) { Text("Set") }
        },
        dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
    )

    if (dlg == "decrypt") AlertDialog(
        onDismissRequest = { dlg = "" },
        title = { Text("Remove Password / پاس ورڈ ہٹائیں") },
        text = {
            OutlinedTextField(value = pwd, onValueChange = { pwd = it }, singleLine = true, label = { Text("Current password") },
                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
        },
        confirmButton = {
            TextButton(onClick = {
                if (FileTools.checkPass(ctx, a.docName(), pwd)) {
                    FileTools.clearPass(ctx, a.docName()); enc = false; dlg = ""
                    toast(ctx, "پاس ورڈ ہٹ گیا / Password removed")
                } else toast(ctx, "غلط پاس ورڈ / Wrong password")
            }) { Text("Remove") }
        },
        dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
    )

    if (dlg == "info") AlertDialog(
        onDismissRequest = { dlg = "" },
        title = { Text("File Info / فائل کی معلومات") },
        text = {
            Column {
                infoRows.forEach { (k, v) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Text(k, fontSize = 13.sp, color = Color(0xFF666666), modifier = Modifier.weight(0.42f))
                        Text(v, fontSize = 14.sp, modifier = Modifier.weight(0.58f))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { dlg = "" }) { Text("OK") } }
    )

    if (dlg == "help") AlertDialog(
        onDismissRequest = { dlg = "" },
        title = { Text("Help & Feedback / مدد") },
        text = {
            Text(
                "• Save: دستاویز ایپ میں اور فائل مینیجر میں محفوظ کرتا ہے۔\n" +
                    "• Export Images: ہر صفحے کی الگ تصویر (JPG) بناتا ہے۔\n" +
                    "• Extract Pages: چنے ہوئے صفحات کی نئی PDF۔\n" +
                    "• Merge Documents: کئی فائلیں ایک PDF میں جوڑتا ہے۔\n" +
                    "• File Compressor: فائل کی ZIP بناتا ہے۔\n" +
                    "• Document Encryption: کھولنے کے لیے پاس ورڈ۔",
                fontSize = 14.sp
            )
        },
        confirmButton = {
            TextButton(onClick = {
                dlg = ""
                try {
                    ctx.startActivity(
                        Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$SUPPORT_EMAIL"))
                            .putExtra(Intent.EXTRA_SUBJECT, "MSF Document Writer - Feedback")
                    )
                } catch (_: Exception) { toast(ctx, "No email app / ای میل ایپ نہیں ملی") }
            }) { Text("Send Feedback") }
        },
        dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Close") } }
    )
}

// ───────────── small UI pieces

@Composable
private fun FmGroup(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().background(FmBody)) { content() }
}

@Composable
private fun FmDivider() {
    Row(Modifier.fillMaxWidth().height(1.dp)) {
        Spacer(Modifier.width(76.dp))
        Box(Modifier.weight(1f).height(1.dp).background(FmLine))
    }
}

@Composable
private fun FmRow(
    icon: ImageVector, label: String,
    trailing: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().height(64.dp).clickable { onClick() }.padding(start = 24.dp, end = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = FmIcon, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(26.dp))
        Text(label, color = Color.White, fontSize = 19.sp, modifier = Modifier.weight(1f))
        if (trailing != null) trailing()
    }
}

@Composable
private fun FmShareDot(bg: Color, icon: ImageVector, round: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).background(bg, if (round) CircleShape else RoundedCornerShape(7.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(19.dp)) }
}

// ───────────── the real work

object FileTools {
    // ---- page helpers
    fun pageCount(pdf: File): Int = try {
        val pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        val n = r.pageCount
        r.close(); pfd.close()
        n
    } catch (_: Exception) { 0 }

    /** "1-3, 5" -> [1,2,3,5] (only pages 1..total, no duplicates). */
    fun parseRange(s: String, total: Int): List<Int> {
        val out = LinkedHashSet<Int>()
        s.split(',', ';', ' ', '،').map { it.trim() }.filter { it.isNotEmpty() }.forEach { part ->
            if (part.contains('-')) {
                val a = part.substringBefore('-').trim().toIntOrNull()
                val b = part.substringAfter('-').trim().toIntOrNull()
                if (a != null && b != null) {
                    val lo = minOf(a, b); val hi = maxOf(a, b)
                    for (p in lo..hi) if (p in 1..total) out.add(p)
                }
            } else part.toIntOrNull()?.let { if (it in 1..total) out.add(it) }
        }
        return out.toList()
    }

    /** Draws the given pages (0-based) of [pdf] into the open [doc]; returns the number of pages added. */
    private fun appendPages(doc: PdfDocument, startNo: Int, pdf: File, pages: List<Int>?): Int {
        val pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        var added = 0
        try {
            val list = pages ?: (0 until r.pageCount).toList()
            for (idx in list) {
                if (idx < 0 || idx >= r.pageCount) continue
                val pg = r.openPage(idx)
                val w = pg.width
                val h = pg.height
                val bmp = Bitmap.createBitmap(w * 2, h * 2, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                pg.close()
                val info = PdfDocument.PageInfo.Builder(w, h, startNo + added).create()
                val page = doc.startPage(info)
                page.canvas.drawBitmap(bmp, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
                doc.finishPage(page)
                bmp.recycle()
                added++
            }
        } finally { r.close(); pfd.close() }
        return added
    }

    private fun writeDoc(doc: PdfDocument, out: File) {
        java.io.FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
    }

    private fun clean(name: String) = name.trim().ifEmpty { "Document" }

    // ---- Export Images (one JPG per page)
    fun exportImages(ctx: Context, pdf: File, name: String): FileResult {
        val pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        val files = ArrayList<File>()
        try {
            val n = r.pageCount
            for (i in 0 until n) {
                val pg = r.openPage(i)
                val width = 1240
                val height = (width.toFloat() * pg.height / pg.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                pg.close()
                val out = Store.uniqueFile(ctx, clean(name) + "_page" + (i + 1), "jpg")
                java.io.FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                bmp.recycle()
                PublicSave.copy(ctx, out)
                files.add(out)
            }
        } finally { r.close(); pfd.close() }
        return FileResult(
            "Export Images / تصاویر",
            "${files.size} تصاویر بن گئیں / images saved.\n${PublicSave.note(ctx)}",
            files
        )
    }

    // ---- Extract Pages
    fun extract(ctx: Context, src: File, pages1: List<Int>, name: String): FileResult {
        val doc = PdfDocument()
        val n = appendPages(doc, 1, src, pages1.map { it - 1 })
        if (n == 0) { doc.close(); return FileResult("Extract Pages", "کوئی صفحہ نہیں ملا / No pages found.", emptyList()) }
        val out = Store.uniqueFile(ctx, clean(name) + "_extract", "pdf")
        writeDoc(doc, out)
        PublicSave.copy(ctx, out)
        return FileResult("Extract Pages / صفحات", "$n صفحات کی PDF بن گئی / pages saved:\n${out.name}\n${PublicSave.note(ctx)}", listOf(out))
    }

    // ---- Merge Documents (current document first, then the chosen files) -> one PDF
    fun merge(ctx: Context, current: File?, uris: List<Uri>, name: String): FileResult {
        val doc = PdfDocument()
        var no = 1
        var skipped = 0
        val tmpDir = File(ctx.cacheDir, "merge_in").apply { deleteRecursively(); mkdirs() }
        try {
            if (current != null) no += appendPages(doc, no, current, null)
            for (u in uris) {
                val nm = Store.nameOf(ctx, u)
                val f = File(tmpDir, nm.replace(Regex("[\\\\/:*?\"<>|]"), "_"))
                try {
                    ctx.contentResolver.openInputStream(u)?.use { i -> java.io.FileOutputStream(f).use { o -> i.copyTo(o) } }
                    val pdf: File? = if (f.extension.lowercase() == "pdf") f else Converter.toTempPdf(ctx, f)
                    if (pdf == null) skipped++ else no += appendPages(doc, no, pdf, null)
                    if (pdf != null && pdf != f) pdf.delete()
                } catch (_: Exception) { skipped++ }
                f.delete()
            }
        } finally { tmpDir.deleteRecursively() }
        if (no == 1) { doc.close(); return FileResult("Merge Documents", "کچھ جوڑا نہیں جا سکا / Nothing to merge.", emptyList()) }
        val out = Store.uniqueFile(ctx, clean(name) + "_merged", "pdf")
        writeDoc(doc, out)
        PublicSave.copy(ctx, out)
        return FileResult(
            "Merge Documents / فائلیں جوڑیں",
            "${no - 1} صفحات کی PDF بن گئی / pages merged:\n${out.name}\n${PublicSave.note(ctx)}" +
                (if (skipped > 0) "\n$skipped فائل سپورٹڈ نہیں / unsupported" else ""),
            listOf(out)
        )
    }

    // ---- File Compressor (ZIP with the strongest compression)
    fun compress(ctx: Context, f: File): FileResult {
        val out = Store.uniqueFile(ctx, f.nameWithoutExtension, "zip")
        ZipOutputStream(java.io.FileOutputStream(out)).use { z ->
            z.setLevel(Deflater.BEST_COMPRESSION)
            z.putNextEntry(ZipEntry(f.name))
            f.inputStream().use { it.copyTo(z) }
            z.closeEntry()
        }
        PublicSave.copy(ctx, out)
        val before = f.length()
        val after = out.length()
        return FileResult(
            "File Compressor / فائل کمپریس",
            "Before / پہلے: ${fmtSize(before)}\nAfter / بعد: ${fmtSize(after)}\n\n${out.name}\n${PublicSave.note(ctx)}",
            listOf(out)
        )
    }

    // ---- sharing
    fun shareTo(ctx: Context, f: File, target: String) {
        val i = Intent(Intent.ACTION_SEND).setType(Store.mime(f))
            .putExtra(Intent.EXTRA_STREAM, Store.uri(ctx, f))
            .putExtra(Intent.EXTRA_SUBJECT, f.name)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            if (target == "whatsapp") {
                i.setPackage("com.whatsapp")
                try { ctx.startActivity(i) } catch (_: Exception) {
                    i.setPackage("com.whatsapp.w4b")
                    ctx.startActivity(i)
                }
            } else {
                i.selector = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                ctx.startActivity(i)
            }
            Prefs.add(ctx, "shared", f.name)
        } catch (_: Exception) {
            toast(ctx, if (target == "whatsapp") "WhatsApp نہیں ملا / WhatsApp not installed" else "ای میل ایپ نہیں ملی / No email app")
        }
    }

    fun shareMany(ctx: Context, files: List<File>) {
        try {
            if (files.size == 1) { Actions.share(ctx, files[0]); return }
            val uris = ArrayList<Uri>(files.map { Store.uri(ctx, it) })
            val i = Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*")
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, "Share"))
        } catch (_: Exception) { toast(ctx, "Share failed") }
    }

    // ---- document password (checked when the document is opened from My Documents)
    private fun key(name: String) = "docpw_" + name.trim().ifEmpty { "Document" }

    private fun hash(pw: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 10000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
    }

    fun hasPass(ctx: Context, name: String) = Prefs.str(ctx, key(name), "").isNotEmpty()

    fun setPass(ctx: Context, name: String, pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val h = hash(pw, salt)
        Prefs.setStr(ctx, key(name), Base64.encodeToString(salt, Base64.NO_WRAP) + ":" + Base64.encodeToString(h, Base64.NO_WRAP))
    }

    fun checkPass(ctx: Context, name: String, pw: String): Boolean {
        val s = Prefs.str(ctx, key(name), "")
        if (s.isEmpty()) return true
        return try {
            val salt = Base64.decode(s.substringBefore(':'), Base64.NO_WRAP)
            val want = Base64.decode(s.substringAfter(':'), Base64.NO_WRAP)
            MessageDigest.isEqual(want, hash(pw, salt))
        } catch (_: Exception) { false }
    }

    fun clearPass(ctx: Context, name: String) = Prefs.setStr(ctx, key(name), "")

    private fun activityOf(c: Context): Activity? {
        var x: Context? = c
        while (x is ContextWrapper) { if (x is Activity) return x; x = x.baseContext }
        return null
    }

    /** Opens [then] directly, or after the right password was typed when the document is protected. */
    fun gate(ctx: Context, f: File, then: () -> Unit) {
        val nm = f.nameWithoutExtension
        val act = activityOf(ctx)
        if (!hasPass(ctx, nm) || act == null) { then(); return }
        val et = EditText(act)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        et.hint = "Password / پاس ورڈ"
        android.app.AlertDialog.Builder(act)
            .setTitle("🔒 $nm")
            .setView(et)
            .setPositiveButton("Open") { _, _ ->
                if (checkPass(ctx, nm, et.text.toString())) then() else toast(ctx, "غلط پاس ورڈ / Wrong password")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
