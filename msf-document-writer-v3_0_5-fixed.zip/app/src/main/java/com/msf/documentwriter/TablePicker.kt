package com.msf.documentwriter

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private val TbBar = Color(0xFF151515)
private val TbAcc = Color(0xFF4A8BEF)
private val TbGrey = Color(0xFF8E8E8E)
private val TbLine = Color(0xFF3C3C3C)
private const val MAX_ROWS = 50
private const val MAX_COLS = 10

private fun two(n: Int): String = String.format(java.util.Locale.US, "%02d", n)
private fun wrap(n: Int, max: Int): Int = if (n < 1) max else if (n > max) 1 else n

/** Draws a rows x cols table in the colours of [style]. */
@Composable
internal fun TableDraw(rows: Int, cols: Int, style: Int, modifier: Modifier, rule: Color) {
    Canvas(modifier) {
        val cw = size.width / cols
        val ch = size.height / rows
        for (r in 0 until rows) {
            drawRect(Color(TableStyles.fill(style, r)), topLeft = Offset(0f, r * ch), size = Size(size.width, ch))
        }
        val w = 1.dp.toPx()
        for (r in 0..rows) drawLine(rule, Offset(0f, r * ch), Offset(size.width, r * ch), w)
        for (c in 0..cols) drawLine(rule, Offset(c * cw, 0f), Offset(c * cw, size.height), w)
    }
}

@Composable
private fun Tri(up: Boolean, left: Boolean, horizontal: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(48.dp).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(22.dp)) {
            val p = Path()
            val w = size.width
            val h = size.height
            if (horizontal) {
                if (left) { p.moveTo(w, 0f); p.lineTo(0f, h / 2f); p.lineTo(w, h) }
                else { p.moveTo(0f, 0f); p.lineTo(w, h / 2f); p.lineTo(0f, h) }
            } else {
                if (up) { p.moveTo(0f, h); p.lineTo(w / 2f, 0f); p.lineTo(w, h) }
                else { p.moveTo(0f, 0f); p.lineTo(w / 2f, h); p.lineTo(w, 0f) }
            }
            p.close()
            drawPath(p, Color(0xFF8A8A8A))
        }
    }
}

@Composable
private fun Num(n: Int, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(two(n), color = if (on) TbAcc else Color.White, fontSize = 22.sp, textAlign = TextAlign.Center)
    }
}

/** Full-screen "insert table" page: size preview, row and column pickers and eight table styles. */
@Composable
fun TablePickerDialog(
    initRows: Int, initCols: Int, initHeader: Boolean, initStyle: Int,
    onCancel: () -> Unit, onOk: (Int, Int, Boolean, Int) -> Unit,
    /** "Full page" layout: 20 rows x 2 columns (narrow + wide) that fill one page. */
    onPage: () -> Unit = {}
) {
    var rows by remember { mutableIntStateOf(initRows.coerceIn(1, MAX_ROWS)) }
    var cols by remember { mutableIntStateOf(initCols.coerceIn(1, MAX_COLS)) }
    var header by remember { mutableStateOf(initHeader) }
    var style by remember { mutableIntStateOf(initStyle.coerceIn(0, 7)) }

    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color.Black)) {
            Row(Modifier.fillMaxWidth().height(56.dp).background(TbBar), verticalAlignment = Alignment.CenterVertically) {
                Text("Cancel", color = Color(0xFFE6E6E6), fontSize = 18.sp, modifier = Modifier.clickable { onCancel() }.padding(horizontal = 20.dp, vertical = 14.dp))
                Spacer(Modifier.weight(1f))
                Text("OK", color = Color(0xFFE6E6E6), fontSize = 18.sp, modifier = Modifier.clickable { onOk(rows, cols, header, style) }.padding(horizontal = 20.dp, vertical = 14.dp))
            }
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TableDraw(rows, cols, style, Modifier.weight(1f).aspectRatio(1.65f).border(1.dp, Color(0xFF666666)), Color(0xFF222222))
                    Column(Modifier.width(78.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Tri(true, false, false) { rows = wrap(rows - 1, MAX_ROWS) }
                        Num(wrap(rows - 1, MAX_ROWS), false, Modifier.height(44.dp).width(60.dp)) { rows = wrap(rows - 1, MAX_ROWS) }
                        Box(Modifier.width(44.dp).height(1.dp).background(TbLine))
                        Num(rows, true, Modifier.height(44.dp).width(60.dp)) { }
                        Box(Modifier.width(44.dp).height(1.dp).background(TbLine))
                        Num(wrap(rows + 1, MAX_ROWS), false, Modifier.height(44.dp).width(60.dp)) { rows = wrap(rows + 1, MAX_ROWS) }
                        Tri(false, false, false) { rows = wrap(rows + 1, MAX_ROWS) }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Tri(false, true, true) { cols = wrap(cols - 1, MAX_COLS) }
                    Num(wrap(cols - 1, MAX_COLS), false, Modifier.height(44.dp).width(64.dp)) { cols = wrap(cols - 1, MAX_COLS) }
                    Box(Modifier.width(1.dp).height(30.dp).background(TbLine))
                    Num(cols, true, Modifier.height(44.dp).width(64.dp)) { }
                    Box(Modifier.width(1.dp).height(30.dp).background(TbLine))
                    Num(wrap(cols + 1, MAX_COLS), false, Modifier.height(44.dp).width(64.dp)) { cols = wrap(cols + 1, MAX_COLS) }
                    Tri(false, false, true) { cols = wrap(cols + 1, MAX_COLS) }
                }
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier.fillMaxWidth().border(1.dp, TbAcc, RoundedCornerShape(10.dp)).clickable { onPage() }.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Canvas(Modifier.size(width = 46.dp, height = 62.dp)) {
                        val rule = Color(0xFF8E8E8E)
                        val w = 1.dp.toPx()
                        val cx = size.width * 0.28f
                        for (i in 0..10) drawLine(rule, Offset(0f, i * size.height / 10f), Offset(size.width, i * size.height / 10f), w)
                        drawLine(rule, Offset(0f, 0f), Offset(0f, size.height), w)
                        drawLine(rule, Offset(cx, 0f), Offset(cx, size.height), w)
                        drawLine(rule, Offset(size.width, 0f), Offset(size.width, size.height), w)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Full page / پورے صفحے کی ترتیب", color = Color.White, fontSize = 16.sp)
                        Text("20 قطاریں × 2 کالم (پہلا تنگ، دوسرا چوڑا) — پورا صفحہ بھر جاتا ہے", color = TbGrey, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF222222)))
                Row(
                    Modifier.fillMaxWidth().height(56.dp).clickable { header = !header },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Header row  /  پہلی قطار عنوان", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Switch(
                        checked = header, onCheckedChange = { header = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White, checkedTrackColor = TbAcc,
                            uncheckedThumbColor = Color.White, uncheckedTrackColor = Color(0xFF555555), uncheckedBorderColor = Color(0xFF555555)
                        )
                    )
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF222222)))
                Spacer(Modifier.height(12.dp))
                Text("Table Style", color = TbGrey, fontSize = 16.sp)
                Spacer(Modifier.height(12.dp))
                (0 until 8).chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(36.dp)) {
                        pair.forEach { i ->
                            val on = style == i
                            Box(
                                Modifier.weight(1f).aspectRatio(1.65f)
                                    .border(if (on) 3.dp else 1.dp, if (on) TbAcc else Color.Transparent, RoundedCornerShape(2.dp))
                                    .clickable { style = i }.padding(3.dp)
                            ) {
                                TableDraw(4, 5, i, Modifier.fillMaxSize(), if (i == 0) Color(0xFF222222) else Color(0xFF444444))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
