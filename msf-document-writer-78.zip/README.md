# MSF Document Writer (Android)

Kotlin + Jetpack Compose. Create / edit / share / print Word (.docx), PDF and Text documents with rich formatting, Urdu & Arabic (RTL) writing, search, PDF Maker, backup & restore.

## Screens
Home · Print (new) · New Document · Text Formatting · Urdu & Arabic Writing · Save Document · My Documents · Word Documents · Search · PDF Maker · Settings · Privacy · Terms · About

## Build
- **Android Studio**: open this folder, sync Gradle, Run.
- **GitHub**: push; Actions → *Build APK* produces a debug APK artifact.

## Notes
- Documents are stored privately in the app (no INTERNET permission). "Cloud" = copy saved through the system file picker (Drive etc.).
- Set your real support e-mail in `Settings.kt` (`SUPPORT_EMAIL`).
- Fonts use system fonts; `Noto Nastaliq Urdu` / `Noto Naskh Arabic` appear only if the device has them (otherwise default Arabic-script font is used).
- Legacy .doc/.xls/.ppt are not supported in PDF Maker.

## Update
- Text Formatting, Urdu & Arabic Writing and Save Document screens redesigned to match the new mock-ups.
- Urdu & Arabic: two ornate panels (Arabic text + Urdu translation); tap the Bismillah pill to insert it; Insert Template adds Surah Al-Fatiha with its Urdu translation. The translation is saved with the document.
- Style (B/I/U), size, colour and font indicators now follow the cursor/selection.

## Update 2 (mock-up redesign)
- New **Print** screen: page preview with pager, Printer / Copies / Paper Size / Orientation / Color Mode / Print Quality, Print button, and Quick Actions (Save as PDF, Share, Preview, Advanced Settings: margins & two-sided).
- Common bottom bar on all main screens: Home - My Documents - New - Print - Settings.
- Header now has a 3-dot menu (Home and shortcuts). Document rows and Search filter chips (with counts) match the mock-ups.
- Import files moved to the My Documents 3-dot menu.

## Update 3 (Profile and Privacy & Security)
- **Profile** screen: photo (tap to change), name/email, stats (Total Documents, Created Today, Files Viewed, Bookmarks), Edit Profile, Privacy & Security, Notifications (opens the phone's notification settings), Appearance (theme), About App, Log Out.
- **Privacy & Security** screen: App Lock (phone PIN/pattern/fingerprint at app start), Fingerprint Authentication, Change PIN/Pattern (opens phone security settings), Hide Sensitive Files, Data Encryption (information), Backup & Restore, Privacy Policy, Clear Private Data.
- New dependency: androidx.biometric:biometric:1.1.0 (the app still has no INTERNET permission).

## Update 4 (crash fix)
- Fixed: the app closed when tapping **Add Font** or any option in the 3-dot menu (Add image etc.). Cause: `biometric:1.1.0` pulled in an old `fragment` library that rejects Activity Result API request codes ("Can only use lower 16 bits for requestCode"). Added `androidx.fragment:fragment-ktx:1.6.2`. This also fixes every other picker (Save as, Import, Backup/Restore, profile photo).
- Picker launches in the editor are now wrapped in `safe { }` so a failure shows a message instead of closing the app.
- Version bumped to 1.0.1 (versionCode 2).

## Update 5 (pages)
- New **page designs** (assets/pages): Golden Border and Islamic Frame. Pick them in *New Document → Page Design*, or in the editor via ⋮ → *Page design*.
- New **New page / نیا صفحہ** (⋮ menu) inserts a page break (a line holding U+000C, drawn as a "New page" label). Text also flows to a new page automatically in PDF/Word/Image output.
- PDF, Word (.docx, border as a header background image) and Image exports draw the design on every page and respect page breaks. Portrait only (the border is ignored in landscape).
- The editor shows the chosen design as an A4 sheet when a design is selected.

## Update 6 (fonts)
- Choosing or adding a font with no text selected now sets the font for the whole document (and for new typing). Before, it did nothing on an empty document.
- Added fonts: file type is detected from the file header when the picker hides the name; re-adding a font replaces the old copy.

## Update 7 (blank page, separate pages, page numbers, tables)
- ⋮ menu: **New page**, **Blank page / خالی صفحہ**, **Insert table / ٹیبل**, **Page numbers / صفحہ نمبر** (on by default), **Page design**.
- Page breaks are drawn in the editor as a full-width band "Page N ends | Page N+1 starts", so every page is clearly separate.
- PDF / Word / Image-with-pages: every page is separate, with its own page number centred at the bottom (Word uses a real PAGE field in the footer).
- Tables are stored as `|cell|cell|` lines (a `|---|---|` line after the first row = header row) and exported as real tables in PDF and Word; Word tables are read back into this form when a .docx is opened again.

## Update 8 (keyboard + page fixes)
- Page-design editor (Golden Border / Islamic Frame): the sheet is now full width and scrolls, so it no longer shrinks to a tiny strip when the keyboard opens.
- While the keyboard is open the bottom navigation bar and the header / Font-Size-Style-Color cards are hidden to give the page more room; the line being typed is scrolled into view above the keyboard.
- Blank page editor: page-break calculation re-checks itself (up to 3 passes) and ignores impossible values, so lines of one paragraph are no longer pushed apart with big gaps.

## Update 9 (blank page fonts)
- Blank page: choosing a font with no selection now applies it to the whole text and re-measures the page, so every font in the list takes effect (not just one).

## Update 10 (design pages = real pages)
- Page-design editor (Golden Border etc.) now uses the same sheet-by-sheet editor as the Blank Page: when a page is full, the text continues on a new sheet below with the same design; "New page" also starts a new sheet. PDF / Word export already writes every page with the design.
- Blank page formatting (bold, size, font, colour) applies only to the selected text, or to what is typed next when nothing is selected.

## Update 11 (selection kept while using menus)
- Opening the Font / Size / Colour menu made Android collapse the text selection, so the format was not applied to the selected text. The editor now remembers the last real selection (until you tap the text or type) and applies fonts, sizes, bold, underline etc. to exactly that text. Different fonts/sizes/styles can now live on one page.
- Page-design editor: the Font / Size / Style / Color row stays visible while the keyboard is open. With nothing selected, a format change only affects the text typed next.

## Update 12 (saving: File Manager + same pages as on screen)
- Every saved file (PDF, Word, text, image) is also copied to a folder the phone's File Manager can see: Documents/MSF Document Writer by default, or any folder / SD card chosen in Settings → Save Location (also on the Save screen: "Save Folder → Change"). The "saved" message shows the real folder, or a warning if the copy failed.
- PDF now follows the page breaks of the editor (Blank Page and design pages): a page that is full on screen stays one page in the PDF instead of spilling onto the next page.

## Update 13 (add design pages with "+")
- Page-design editor: a round "+" button (bottom right of the pages, and menu → "+ Add design page") adds a new page after all the text with a design of your choice. Pages can now have different designs (e.g. page 1 Golden Border, page 2 Islamic Frame). "Page design" in the menu still changes the design of all pages.
- The text margins are the widest of the designs used, so text never touches any border. PDF export draws each page with its own design. Word (.docx) export keeps only the first page's design.
- Changing the design in the menu now also updates the pages already on screen.

## Update 14 (blank / extra pages)
- Editor (Blank Page & design pages): a line that holds only the page-break mark no longer starts a sheet of its own when the previous sheet is full. Before, the break line was pushed to a new sheet and the forced break then pushed the following text to yet another sheet, which showed up as an extra empty page.
- PDF: the newline written before a page-break mark no longer creates an empty line at the end of the page. On a full page that line spilled onto a new page and the page break added another one, which left a blank page in the middle of the PDF.

## Update 15 (Page Setup + Page Number screens)
- **Page Setup** (bottom bar frame icon, or ⊞ menu → Page setup): dark full-screen page like the mock-up. Page Size (A3, A4, A5, B4, B5, Letter, Tabloid, Ledger, Legal, Statement, Executive, Folio, Quarto), Orientation (Portrait / Landscape) and Page Margins with a cm / inch switch. The page sketch has blue arrows on all four edges: tap an arrow = move that margin by 0.1, or drag it. "Default" restores the normal margins. Everything is applied at once to the editor, PDF, Word and Image export (each side can have its own margin; text size/wrapping follows).
- **Page Number** (the "1" box at the top right of the editor, or ⊞ menu → Page number…): Location (Header / Footer), Alignment (Left / Center / Right), Number Format (1,2,3 · I,II,III · i,ii,iii · A,B,C · a,b,c · 1st · One · First · ア · イロハ · 壱弐参 · ①②③ · １２３ · 甲乙丙 · 子丑寅 · 一二三 · 壹貳叁 · -1-) and Start Number (type it or use − / +). Shown on every sheet in the editor, in PDF and in Word (.docx: real PAGE field in the header/footer + `pgNumType` for format and start). The settings are read back when an app-made .docx is opened again.
- Editor 3-dot menu (design pages) also has "Page number…".
- New paper sizes added to the Paper list (B4, Ledger, Statement, Executive, Folio, Quarto). Version 1.0.13 (versionCode 14).
- Build note: this update was written without an Android SDK on hand, so please run the GitHub "Build APK" action once and tell me if the compiler reports anything.

## Update 16 (Aa format sheet)
- The **Aa** button now opens a dark bottom sheet with tabs **Home / File / Insert / View** (chevron = close, keyboard icon = show/hide keyboard).
- Home: Size, Font (with "Add font"), **B / I / U / S**, Text Color (5 quick colours, "···" opens the full Text Color page with Standard Colors, "Automatic" resets), Highlight (5 colours, No Fill, "···" opens the full Highlight page), line spacing "Multiple" (1.0 – 3.0) and alignment: left, centre, right, justify, right-to-left.
- File: Save, Save as…, Save as PDF, Share, Clear all. Insert: New page, Blank page, Table, Image, Page number…. View: Page setup, page numbers on/off, page border, RTL, Justify.
- Line spacing is applied in the editor and in PDF output (not yet written to Word files).
- As before this was written without an Android SDK; please run the GitHub build and send me any compiler message.

## Update 17 (Aa sheet: Style, Bullets & Numbers, Indents & Spacing, Smart Typography)
- **Style** row (Normal, Heading 1-3, and "···" for Title, Subtitle, Quote). Works on the paragraph(s) under the cursor/selection; on an empty line it styles what you type next. The current style is highlighted.
- **Bullets & Numbers**: bullet, dash, 1. 2. 3., multilevel 1.1.1., "no list" and "···" (7 bullet symbols; 1. / 1) / (1) / a. / A. / i. / I. / ۱۔). Numbers are renumbered automatically. **Increase / Decrease** change the list level (or the indent of normal paragraphs). **Restart / Continue** control the numbering of the item under the cursor. **Auto Numbering** switch: Enter continues the list, Enter on an empty item ends it.
- **Indents & Spacing**: left indent, first-line / hanging indent, space before / after paragraph, line spacing, reset. Written to PDF and Word (w:ind / w:spacing) and read back from Word files. Line spacing is now also written to Word.
- **Smart Typography**: smart quotes, dashes, ellipsis and Urdu punctuation (? , ; to ؟ ، ؛) while typing, plus "Apply now" for the selection or the whole document (table rows are skipped).
- New file `ParaFormat.kt`. Version 1.0.15 (versionCode 16).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me the compiler message if there is one.

## Update 18 (Insert Table page)
- New full-screen **Insert Table** page (Cancel / OK) like the mock-up: live preview of the table, row picker (up / down arrows, tap the numbers) and column picker (left / right arrows) with wrap-around, a Header row switch, and **Table Style**: eight styles (Plain, Gray, Blue, Red, Green, Purple, Teal, Orange) with banded rows.
- The style is kept with the table (editor row colours, PDF, Word and Image export). In Word the rows get the style colours and `w:tblLook firstRow`; an app-made .docx is read back with its style. Tables up to 50 rows x 10 columns.
- Used by the Blank Page editor and the older editor. New files: `TablePicker.kt` (page), style code in `Tables.kt`. Version 1.0.16 (versionCode 17).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update 19 (table on the page, columns, Small Caps / All Caps, T² / T₂)
- **Tables on the page**: a table is now drawn as a real grid (equal, aligned columns with vertical and horizontal rules; the `|---|` header line is hidden). While the cursor is inside a table the handles sit on the page itself: column letters **A B C** above the table, row numbers **1 2 3** at its left, a round **+** at the right (add column) and below (add row), and the four-arrow button that opens the menu **Select / Select All / Table Properties** (plus Row above, Column left, Delete row / column / table). Tap a letter or a number to jump to that column / row. New file `TableGrid.kt`.
- **Aa sheet (Home tab)** now ends with: **Columns** (One, Two, Three, Left, Right), **T² / T₂** (superscript / subscript) and **Small Caps | All Caps** (toggles on the selected text), laid out like the mock-up.
- **Columns**: the page shows the text in 1-3 columns (first column on the right for right-to-left documents); typing, selecting and scrolling work as in one long column. PDF and Word (.docx, `w:cols`) follow the same columns and the setting is read back from an app-made .docx. Left / Right are two columns of equal width for now. New file `Columns.kt`.
- Superscript / subscript are written to Word (`w:vertAlign`) and read back; PDF shows them as well.
- Version 1.0.17 (versionCode 18).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update 20 (resizable table columns / rows, paragraph bar)
- **Drag to resize**: while the cursor is in a table, drag any inner **column border** left or right and any **row border** up or down. A blue dashed guide line with a two-way arrow ↔ (↕ for rows) shows where the border will land; the columns beside it grow / shrink (minimum width kept). Columns can now be unequal (e.g. A narrow, B wide, C narrow).
- The widths are stored with the table (`TableWidthSpan`, `RowHeightSpan` in `Tables.kt`), used by the editor grid (`TableGrid.fit`), the **PDF** (`drawTable`) and **Word** (`w:gridCol`, `w:tcW`, `w:trHeight`) and are read back from an app-made .docx. Adding / deleting a column resets that table to equal columns.
- **Floating paragraph bar**: tap the Align button in the bottom bar to show a dark bar above it with bullets, numbering, increase indent, decrease indent, align left, align centre and "•••" (right / justify). The Align icon is highlighted while the bar is open.
- Known limit: text in an editor cell does not wrap onto several lines (the cell widens instead); in PDF / Word long cell text wraps and rows grow.
- Version 1.0.18 (versionCode 19).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update (File menu redesign)
- Editor → panel → **File** tab redesigned like the WPS mock-up (icons, grouped rows, footer) and every item works:
  Save · Save As · Export to PDF · Share as Options (E-mail, Cloud/Drive picker, WhatsApp, more) · Export Images (one JPG per page) ·
  Extract Pages (e.g. `1-3, 5` -> new PDF) · Merge Documents (this document + chosen PDF/DOCX/TXT/images -> one PDF) ·
  File Compressor (ZIP, before/after size) · Document Encryption (password asked when the document is opened in the app) ·
  Print (system print dialog) · File Info · Help & Feedback.
- New file: `FileMenu.kt`. Extract/Merge create image-based PDF pages (text is not selectable in those PDFs).

## Update (page designs in Blank Page)
- Blank Page editor now has all 24 **page designs** (same as New Document -> Page Design): bottom-left menu -> *Page design* / *+ Add design page*, the *+ Insert* menu -> *Design page*, and the Aa panel -> View tab.
- A design is shown on every sheet, text stays inside the frame, and it is used in PDF / Word / image export. *Add design page* adds a new page with a different design.
- New file: `DesignPicker.kt` (gallery dialog with small previews).

## Update (blank first / last page, design kept, own designs)
- **PDF: no more empty first or last page.** PdfBuilder now starts a page only when something is drawn on it. Page breaks / blank lines in front of the first text and after the last text are ignored (before, "Add design page" on an empty document, a trailing page break or trailing blank lines on a full page gave an empty page 1 / last page). Page breaks between texts and intentional blank pages in the middle are kept.
- **Design no longer disappears.** The Blank Page screen used to reset the design to "plain page" every time it was opened (e.g. coming back from Save / Done). It now restores the design and the extra design pages from `Doc`.
- "Add design page" on an empty document now just puts the design on page 1 (no empty page in front).
- New Document -> "Blank Document" now uses the Page Design chosen on that screen.
- **Own designs from Gallery / File Manager.** Page Design and "+ Add design page" (Blank Page editor, old editor, New Document screen) have a green "＋ Choose from Gallery / File Manager" button. The picture is cut to page shape (A4), saved inside the app, and the text margin (small / medium / large) is asked. Long-press an own design in the list to delete it. Own designs work in the editor, PDF, Word and Image export. New: `CustomDesigns` in `PageDesigns.kt`.
- Version 1.0.25 (versionCode 26).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update (crash report)
- Blank Page start hardened (design restore in try/catch); "Blank Document" no longer carries the chosen design (as in 1.0.24).
- New `CrashLog.kt`: if the app closes by itself, the next start shows the error text with Copy / Share buttons, to be sent to the developer.
- Version 1.0.26 (versionCode 27).

## Update (VerifyError fix)
- Fixed: the app closed when opening Blank Page (`VerifyError ... BlankPageKt.BlankPageScreen`): the screen function had become too large for Android's verifier. All new design code now lives in small separate composables (`GalleryDesignButton`, `DesignMarginDialog` in `DesignPicker.kt`). The old editor now uses the same `DesignPickerDialog` as Blank Page (smaller `RichEditorScreen`).
- Version 1.0.27 (versionCode 28).

## Update (Insert tab like Office)
- New `InsertTab.kt`: the Insert tab of the Aa sheet now has icon rows: Picture, Text Box (one-cell table), Shapes (30 shapes, 4 colour pages: orange, green, blue, white->black; tap to insert at the cursor, swipe or tap the dots to change colour), Signature (draw with the finger; stamped at the end of the last page of PDF / Image; also in `PdfBuilder.signature`, `Doc.signature`), Comment (yellow highlighted note at the cursor), Table, Blank Page, New Page, Page Number.
- The big `BlankPageScreen` only got one line (`InsertBridge.et = et`) to stay below the Android verifier limit.
- Version 1.0.28 (versionCode 29).

## Update (Insert + View tabs like WPS)
- Insert tab: Picture, Text Box, Shapes, Signature, Comment, Table, Page Number, Date & Time (6 formats), Hyperlink ("text (address)" in blue, underlined), Bookmark, Attachment (writes the file name + size as a line), Portrait Blank Page, Landscape Blank Page (opens Page Setup: landscape applies to the whole document), Page Break.
- New `ViewTab.kt` (View tab): Find & Replace (find next / replace / replace all), Word Count, Screen Always On, Night Mode, Eye Protection Mode, Page Background colours (4 + more), Copy / Paste / Cut, Add Bookmark, All Bookmarks (tap to jump, X to delete), Thumbnail (page list, tap to jump), Content (headings: lines starting with # or in a bigger size), Lock Screen (locks rotation) and the earlier page settings.
- Night mode / eye protection / page background change only the view on screen, not the exported file.
- Left out on purpose: Evernote, AI Translate, Set Mobile View as Default (need online services / nothing to do in this app).
- Version 1.0.29 (versionCode 30).

## Update (Review + Pen tabs)
- The tab row now scrolls: Home, File, Insert, View, Review, Pen.
- **Pen** (`InkTab.kt`): Ink on/off, "Use Finger", pencil / highlighter / eraser, 5 colours, 4 line widths, Clear all ink. The ink layer (`InkView`) lies over the pages; strokes are stored as fractions of the page and are drawn into the PDF / Image (`PdfBuilder.ink`). Not in Word. Turn ink off to scroll and type.
- **Review** (`ReviewTab.kt`): Export Text Highlights (share a .txt of all highlighted text), Remove All Comments, Show Comments (yellow highlight on/off + list), Show Changes, Comments and Revisions List, Enter Revise Mode (text typed is marked red as a change), Accept / Reject All Changes, Modify User Name (used in new comments), Spell Check (keyboard suggestions on/off).
- Left out: AI Translate (needs an online service).
- Version 1.0.30 (versionCode 31).

## Update (compile fix + mock-up pages: Style, Bullets, Font, File Tabs)
- **Build fix**: `Review` in `ReviewTab.kt` had properties and functions with the same JVM name (`setShowComments` etc.). The functions are now `applyShowComments`, `applyShowChanges`, `applyRevise`, `applySpell`.
- **Style** page (Aa → Home → Style "···"): Normal, Heading 1-9, Title, Subtitle, Emphasis, Intense Emphasis, Subtle Emphasis, Strong, Quote, Intense Quote, Subtle Reference, Intense Reference, Book Title, List Paragraph. The current style is blue with a tick. New styles replace each other (`StyleFmt.applyAny`).
- **Bullets** page: Bullets (7 symbols), Numbers (1. 1) (1) I. A. a. i.), Levels (1.1.1., Urdu numbers) and a "no list" box in each group.
- **Font** page: tap the font name in the Aa sheet → full list, each font shown in its own face, tick on the current one, "+ Add font" at the top.
- **File Tabs**: the first icon of the bottom bar opens the "File Tabs" drop-down (open document, Home, Create new, Tools). Unsaved changes ask Save / Discard first.
- New file: `FileTabs.kt`. Version 1.0.31 (versionCode 32).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update (Recent home + Spacing page)
- **Recent** is the new home screen (dark): search bar (menu, "Search files, tools", quick-tools bolt, profile), tabs **Recent / Starred**, filter + sort menu, file rows (icon, name, date · My Documents, open-with, ⋮ menu: Open, Star, Share, Print, Rename, Delete) and the blue **Create** button (New Document, Blank Page, Text Formatting, Urdu & Arabic, PDF Maker, Import).
- Bottom bar: **Recent · Files · Scanner · Discover · Settings**. Scanner takes a photo with the system camera and saves it as a PDF in My Documents. Discover is the old tile page with all tools. (The mock-up's "Premium" is Settings here, the app has nothing to buy.)
- **Spacing** page (Aa → Home → the Multiple box): radio **Multiple** (0.5 – 6.0 in steps of 0.25) and **Exactly (pt)** (6 – 72) with a stepper each (arrows or tap a number). Exactly is converted to the editor/PDF/Word line-spacing multiple.
- New files: `RecentScreen.kt`. Version 1.0.32 (versionCode 33).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update (table borders like WPS)
- Dragging a column border now changes only the two columns beside it; every other column keeps its stored width exactly (before, all widths were re-normalised on release and could shift slightly). The blue dashed guide line now runs the full height of the page, as in the WPS video.
- Version 1.0.39 (versionCode 40).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update (full & fast .docx opening, one-click Open Word)
- **New streaming Word reader** (`RichDocx.parse` in `RichText.kt`, XmlPullParser): reads the whole document once, in seconds, instead of thousands of regex scans. It also reads `styles.xml` (document defaults, paragraph / character styles with `basedOn`), so headings, colours, sizes, bold / italic and fonts defined by styles are kept; Urdu text uses the complex-script size / font (`szCs`, `cs`). Tables (grid widths, header row, row heights, locks), indents, spacing, alignment, justify, RTL and page breaks are read as before. The old regex reader stays as a fallback (`parseXml`) if the XML cannot be streamed.
- **No more half-opened files.** A long document now opens in ONE piece (limit raised from 40 000 to 1 500 000 characters; 80 000 words is about 600 000). Time budget: full reader 22 s, then the plain-text reader (also complete) - the whole open stays under ~30 s. After a crash the safe mode now opens parts of 120 000 characters (before: 8 000) and the rest loads from the menu.
- **One-click Open Word (.docx)**: Create menu (Recent screen) and a tile on Discover. Pick a .docx and it is read in the background and opens straight on the Blank Page.
- Not read yet: automatic list numbering (numbering.xml), pictures, headers / footers text, theme fonts.
- Version 1.0.41 (versionCode 42): empty-result guard (falls back to the complete plain-text reader) and a diagnostic note next to "Full text" in the Blank Page that says how the file was opened.
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update 1.0.42 (VerifyError fix again)
- 1.0.41 added the diagnostic label inside `BlankPageScreen`, which pushed it over the verifier limit again (`VerifyError ... BlankPageScreen`). The label now lives in the small composable `FullTextLabel` (BlankPage.kt), so `BlankPageScreen` is smaller than before. RULE: never add code to `BlankPageScreen`; put new UI in separate composables.

## Update 1.0.43 (look of Word books: header on every page, table colours)
- **Running page header**: the text of a Word file's page header (e.g. the book title + page number) is read (`RunHeader.of`, new file `RunHeader.kt`), drawn at the top of every page in the Blank Page editor with a thin line under it, drawn the same way in the PDF (`PdfBuilder.headerText`) and written back into `header1.xml` when saved as .docx. When the page number sits in the header it is drawn together with the text.
- **Table header colour**: the real colour of a table's first row is now kept (custom table style `TableStyles.CUSTOM | RRGGBB`: coloured header, white body rows). Before, only the 7 built-in colours were recognised and every other table became plain white.
- Text colours / sizes / bold from the document and its styles were already read by the 1.0.40 reader.
- Version 1.0.43 (versionCode 44). Nothing was added to `BlankPageScreen` (only to the `PageSheets` view class).

## Update 1.0.44 (list numbers, row colours, header colour, fonts)
- **Automatic list numbers**: `numbering.xml` is read; numbered / bulleted paragraphs (direct or through their style) get their number / bullet as text at the start (decimal, letters, roman, bullets; counters per list and level).
- **Table row colours**: the shading of table rows is kept per row (`RowFillSpan`, dominant colour when at least half the cells of the row are shaded). The editor, PDF and .docx writer use it. Different colours of single cells inside ONE row are not supported (the editor draws tables row by row).
- **Header colour / size** of the page header are read and used in the editor, PDF and .docx.
- **Word font names** like "Noori Nastaleeq", "Jameel Noori", "AlQalam Quran" now map to the bundled fonts (`Fonts.bundledLabel`).
- NOT done: pictures inside the text (the editor has no inline-picture support; would need its own engine).
- Version 1.0.44 (versionCode 45).

## Update 1.0.45 (WPS-style page view)
- Pages now look like the WPS Office viewer: wider grey gap between sheets with a thin edge line, the red "Page N end" dashed line removed, lighter grey table borders, and a floating **page pill** ("9 / 233") at the bottom that follows the scroll (new file `PagePill.kt`).
- Nothing was added to `BlankPageScreen` (only `FullTextLabel` and `PageSheets` changed).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update 1.0.46 (rich reader fix: formatting, tables and colours were lost)
- Bug seen on a phone: the label said "rich failed: IllegalStateException rich reader found no text", so the .docx opened as plain text (no tables, colours, fonts).
- `RichDocx.parse(File)` now reads the .docx with `ZipFile` (same way the plain reader does, tolerant of odd entry names); the stream reader stays as a second route. If the streaming parser returns no text, the regex reader runs before giving up. The failure label now also says why (`RichDocx.lastError`, e.g. the entry names found in the zip).
- Version 1.0.46 (versionCode 47).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update 1.0.47 (rich reader was timing out on a 227-page Urdu file)
- Phone label after 1.0.46 said "rich failed: TimeoutException slow": the full reader (fonts, tables, colours) was cut off at 22 s and the file opened as plain text.
- The full reader now gets up to 170 s on very long files (`Doc.open`), the wait dialog shows "Reading formatting… Ns", and the label under the page now says which reader ran: `rich ok (stream|regex) <ms> <chars>`.
- If the stream reader returns no text, the message includes the XML size so the cause is visible.
- Version 1.0.47 (versionCode 48). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.48 (plain / fast mode removed)
- `Doc.open` no longer falls back to the plain-text reader and has no time limit: a Word file always opens with the full reader (fonts, colours, tables, header, page numbers). If it truly cannot be read, the open fails and the toast shows the reason (`Doc.diag`) instead of silently losing the formatting.
- The "fast mode / plain text" toast was removed. (`editSafe` is still in the code but is never called.)
- Version 1.0.48 (versionCode 49). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.49 (stuck at "99%" while opening a 227-page Urdu file)
- The wait dialog stuck at 99% = the whole 165 000-character document was being put into the page editor in one go (layout of every page on the UI thread).
- A long .docx now opens in parts of about 50 000 characters (about the first 60 pages) and `PageSheets` adds the remaining parts automatically every 2.5 s while the person already reads. Nothing is dropped and the rest is saved with the file. The old "Load next part" menu item still exists.
- `APP_VER` (the "(v…)" in the wait dialog) was hard-coded as 1.0.44; it now says 1.0.49, so it is clear which build is running.
- Version 1.0.49 (versionCode 50). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.50 (still stuck at 99% in 1.0.49)
- "99%" is only ever shown by the regex reader (`parseXml`), so the streaming reader gives no text on this file and the regex reader then hangs. `parseXml` cut the document into paragraphs/tables/rows/cells/runs with lazy `.*?` regexes over a custom CharSequence on a multi-MB string = extremely slow. It now cuts them with plain `indexOf` scans (`nextOpen`, `endOf`, `blocksOf`): linear, no regex backtracking. Output format is unchanged.
- `Doc.edit` now shows "step 2 / 3 / 4" in the wait dialog after the text is read, so a stall can be located from a screenshot.
- Version 1.0.50 (versionCode 51). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.51 (1.0.50 still stopped at 99%, no "step 2" shown)
- "step 2" never appeared, so the stall is inside the reader after the last paragraph, i.e. most likely while the finished text is turned into a SpannableStringBuilder with its (very many) spans.
- `SpanBuf` now merges character styles that touch (or are only a line break / space apart) into one span, so far fewer spans are built.
- `SpanBuf.build()` now shows "اسپین بنا رہا ہے… i / N (spans)" in the wait dialog every 20 000 spans: the next screenshot shows how many spans there are and how fast they are built.
- Version 1.0.51 (versionCode 52). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.52 (table of contents: doubled cells / rows fixed)
- Bug seen on a phone: the table of contents of a 137-page Urdu book opened with the same text repeated in several columns and rows.
- Cause: the Word file has tables inside table cells (nested tables). The regex reader (`parseXml`) cut rows / cells at the FIRST closing tag, so the inner table's rows and cells were read again as extra rows and columns. `endOf` now counts the nesting depth for `w:tbl`, `w:tr` and `w:tc`; text of a nested table is kept inside its outer cell (flattened), never as new rows / columns.
- Merged cells (`w:gridSpan`) are now kept as ONE cell followed by empty cells (both readers), so every row keeps the same number of columns and the text is not repeated.
- Version 1.0.52 (versionCode 53). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.53 (doubled text, second fix)
- The regex reader read both copies of text boxes / shapes (`mc:AlternateContent` = `Choice` + `Fallback`), so the same text appeared twice. `dropFallback` removes `<mc:Fallback>` before reading (the stream reader already skipped it).
- `endOf` is now nesting-aware for paragraphs and runs too (text boxes inside runs hold paragraphs of their own), so nothing inside a text box is read a second time.
- Version 1.0.53 (versionCode 54). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.56 (table text shown 2-4 times: real cause found and fixed)
- Real cause (found with the user's own .docx: 1 table, 102 rows, 3 columns, no nested tables): `CellSpan` (TableGrid.kt) is a ReplacementSpan. Android calls a ReplacementSpan once per piece of its range that has another character style or text direction. A title cell made of 20 Word runs therefore drew the whole cell 20 times and took 20 column widths, so rows wrapped into several bands with the same text in each. `CellSpan.getSize/draw` now work only for the piece that starts where the span starts (`isFirstPiece`).
- The guess-based "remove repeated text in a row" code of 1.0.54 / 1.0.55 was REMOVED (it could delete real repeated data).
- `w:tblGridChange` (an old copy of the column widths inside `w:tblGrid`) is ignored, so the real widths 1420 / 7980 / 1060 are applied (stream and regex reader).
- Kept: nesting-aware row / cell scan, merged cells (gridSpan), dropping `mc:Fallback`.
- Version 1.0.56 (versionCode 57). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.57 (column order like Word / WPS, table cut cleanly at the page end)
- **Column order**: a Word table without `<w:bidiVisual/>` lists its cells from the LEFT; the editor / PDF put the first cell of a right-to-left table at the RIGHT edge, so the number column ended at the left. The regex reader now stores the cells of such a table (Urdu paragraphs, no bidiVisual) in reverse order and reverses the column widths too. Number column = right edge, title in the middle, page at the left, as in WPS. Saving writes `<w:bidiVisual/>` (as before), so Word shows the same order. (The stream reader is not changed.)
- **Page end**: the page push (bottom margin + gap + top margin) sits at the top of the first row of the next sheet. Rules, row colour and cell text of that row used to start at the top of the push, so the table was drawn through the page gap and the last row looked huge. `RowPush.at` (TableGrid.kt) gives the push of a line; `CellSpan`, `PipeSpan` and `TableRowSpan` now start below it. The next sheet continues with the next row.
- NOT done: repeating the header row at the top of every sheet (WPS does it).
- Version 1.0.57 (versionCode 58). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.58 (footnotes / حوالہ جات)
- `word/footnotes.xml` is now read (regex reader). Every `w:footnoteReference` in the text becomes a small raised number (1, 2, 3 ... in reading order) and the footnote itself (its own number + the text, small size) is written right under the paragraph that refers to it, after a thin grey rule. Footnote text keeps its colour / size / font runs. Footnotes are part of the document text, so they are in PDF / Word / image export and are saved with the file.
- Known difference to Word / WPS: those programs put the footnote at the bottom of the PAGE and restart the number on every page; here it stands under its paragraph and the numbers run on (1 ... 106). Footnotes inside table cells and the stream reader are not covered yet.
- Version 1.0.58 (versionCode 59). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.59 (first line of a page no longer runs into the header; Header settings)
- **Bug fixed**: the first line of every new sheet was drawn too high, on top of the running header (e.g. "اہل السنت والجماعت کا عقیدہ"). Cause: `PagePushSpan` moved the baseline by only d / 1.25 instead of d (the extra space ended up below the text). Now the whole push sits above the text, so the text starts at the top margin, below the header. Table rows keep the old behaviour (they are drawn below the push, see `RowPush`).
- **Word-like page layout**: the header sits at "Header from top" (read from `w:pgMar w:header` of the .docx, written back on save; default 1.25 cm) and the body starts below it (`Doc.headerTop()`), in the editor and in the PDF. The thin line under the header is also written to the .docx (`w:pBdr`).
- **Header settings**: Page Setup now has a **Header** row -> dialog with header text, size, colour, alignment (Auto / Left / Center / Right), line on/off, distance from the top, "Remove" and a "Page number…" shortcut (Header / Footer location lives in the existing Page Number dialog). Used by the editor, PDF and .docx.
- Version 1.0.59 (versionCode 60). Written without an Android SDK; run the GitHub "Build APK" action and send me any compiler message.

## Update 1.0.60 (footnotes / حوالہ جات under the writer's control)
- New file `Footnotes.kt`. Aa -> **Insert** tab has two new rows:
  - **Footnote / حوالہ**: type the footnote text and choose where it goes: under its paragraph, bottom of this page, top of this page, end of the document, or at the cursor. A raised number is put at the cursor and "number  text" goes into a footnote block (thin rule + small text). If a block is already at that place, the note is added to it.
  - **Move Footnote / حوالہ منتقل**: put the cursor inside a footnote (or select its lines) and move it to the bottom / top of the page, the end of the document, or one paragraph up / down.
- Footnotes stay ordinary text, so they can be edited freely. Footnotes read from a .docx (1.0.58) can be moved the same way.
- Known limit: a footnote is part of the text flow, so if body text above it grows, the block moves down with it (it is not fixed to the page bottom yet). Use "Move footnote" to put it back.
- Version 1.0.60 (versionCode 61). Written without an Android SDK; run the GitHub "Build APK" action and send me any compiler message.

## Update 1.0.61 (header font)
- The Header dialog (Page Setup -> Header) now has a **Font** row with the same font list as the text (Default, system fonts, the bundled Urdu / Quran fonts, and fonts you added). The font is used by the editor, the PDF and the .docx (`w:rFonts` in the header run).
- The font of the page header of an opened .docx is read too (before, it was always drawn in the default font). The dialog scrolls on small screens.
- Version 1.0.61 (versionCode 62). Written without an Android SDK; run the GitHub "Build APK" action.

## Update 1.0.62 (Margins presets like Word)
- Page Setup now has a **Margins** row (between Header and Page Margins). Tap it for the Word list: **Normal** (1" all round), **Narrow** (0.5"), **Moderate** (top/bottom 1", left/right 0.75"), **Wide** (top/bottom 1", left/right 2"), **Mirrored** (top/bottom 1", inside 1.25", outside 1"), **Office 2003 Default** (top/bottom 1", left/right 1.25") and **Custom Margins**. Each row shows a small page picture and the values in the chosen unit (inch or cm). The current choice is highlighted; if the margins match no preset the row says "Custom Margins" (use the blue arrows).
- A preset is applied at once to the editor, PDF, Word and Image export, like the arrows. Too-wide presets on small paper are shrunk so a 1-inch text area stays.
- Known limit: Mirrored uses Inside = left and Outside = right on every page (pages are not swapped left/right yet, and `w:mirrorMargins` is not written to .docx).
- Code: `PageSetup.kt` only (`MarPreset`, `MarginPresetsDialog`, `MarIcon`). Version 1.0.62 (versionCode 63). Written without an Android SDK; run the GitHub "Build APK" action and send me any compiler message.

## Update 1.0.63 (full Shapes gallery like Word)
- Aa -> **Insert -> Shapes** now shows the same groups as Word's Insert > Shapes, in one scrolling page: **Recently Used Shapes** (last 12, kept between sessions), **Lines**, **Rectangles**, **Basic Shapes** (circles, triangles, diamonds, polygons, pies, crosses, heart, smiley, sun, moon, cloud, brackets and braces), **Block Arrows** (about 35), **Equation Shapes** (+ − × ÷ = ≠ and more), **Flowchart**, **Stars and Banners** and **Callouts**. About 190 shapes in all (the old page had 30).
- Tap a shape to insert it at the cursor. The four colour pages (orange, green, blue, white->black) still work: swipe sideways or tap the dots (now at the top of the page). Swiping is horizontal only, so the page scrolls up / down normally.
- Shapes are text symbols (Unicode), not drawn objects, so they behave like text: size, colour, copy and paste work, and they are saved in PDF / Word / Image. Word-only shapes without a symbol (for example snip / round-corner rectangles, 3-D cube, wave banners) are approximated by the nearest symbol. The Callouts use phone emoji, which keep their own colour.
- Code: `InsertTab.kt` only (`ShapeGroup`, `ShapeGroups`, new `ShapesPage`). Version 1.0.63 (versionCode 64). Written without an Android SDK; run the GitHub "Build APK" action and send me any compiler message.

## Update 1.0.64 (footer, Header & Footer row, footnote move fixes)
- **Footer**: the page footer now has the same settings as the header (text, size, font, colour, alignment, line, "From bottom"). Page Setup has a new **Footer** row; Aa -> Insert has a new **Header & Footer / ہیڈر اور فُٹر** row that opens Header or Footer. The footer is drawn on every sheet in the editor (the text stops above it), in the PDF and in the .docx (`footer1.xml`, line above the text, `w:footer` distance); it is read back when a .docx is opened. If the page number is in the footer it is drawn together with the footer text.
- **Footnote bugs found and fixed** (`Footnotes.kt`):
  1. *Adding a footnote at "Bottom of this page" (the default)* used the page ends measured BEFORE the number was typed in, so the footnote was cut into the last line of the page a few letters before its end. The page is now measured before and shifted by the length of the number.
  2. *A page is always full*, so a footnote put at the end of a page did not fit: its lines ran over to the TOP of the next page (or were cut in two). Now the block is measured in the editor and put in front of the line from which it still fits (the last lines of the page go to the next page, below the footnote, like Word). A footnote block that already ends the page takes the new note.
  3. *Move -> Bottom of this page* for a footnote that stood across a page change said "already there" or moved it to the wrong page. The page of the LAST line of the block is used now.
  4. *One paragraph up / down* stopped on empty lines and page-break lines and could land inside another footnote; blank lines are skipped and another footnote block is jumped over.
- **New in Move Footnote**: *Bottom of the previous page*, *Top of the next page* and **Pick up** -> put the cursor anywhere -> Insert -> **Drop Footnote Here**. The picked-up footnote stays in the text (marked) until it is dropped, so nothing is lost.
- Known limit: cutting a footnote into a page splits the paragraph at that line (the text after it is a new paragraph), because footnotes are ordinary text lines.
- Version 1.0.64 (versionCode 65). Written without an Android SDK; run the GitHub "Build APK" action and send me any compiler message.

## Update 1.0.65 (real drawn shapes, same as Word's Insert > Shapes gallery)
- **Aa -> Insert -> Shapes** now shows the SAME shapes as the Word gallery (about 160): Lines (12), Rectangles (9), Basic Shapes (42), Block Arrows (27), Equation Shapes (6), Flowchart (28), Stars and Banners (20), Callouts (16), plus Recently Used Shapes. The old text symbols are gone.
- The shapes are really DRAWN (new file `ShapeArt.kt`: one path per shape in a 100 x 100 box), so they look like Word's, not like nearest symbols. Default colour is **black**; the new **Outline / Filled** chips at the top choose outline only (like the Word gallery pictures) or filled. The four colour pages still work (black, orange, green, blue).
- An inserted shape is one object character in the text (`ShapeSpan`, U+FFFC): colour = text colour, size = font size (the normal Text tools change them), like a letter; wide shapes (rectangles, banners, callouts ...) are 1.5 times as wide as high. They show in the PDF / Image export too.
- **Saved to Word as real Word shapes**: the preset names are Word's own (`rightArrow`, `star5`, `flowChartDecision` ...) and are written as DrawingML `wps:wsp` with `a:prstGeom` (outline colour, fill, arrow ends); `wp:docPr descr="msfshape:<name>:<fill>"` is our marker, so the app reads them back as shapes. Shapes made by Word itself are not read as shapes (as before). Word has no exact preset for the freeform / curve / scribble lines; they are saved as a straight line / arc.
- Known limits: shapes are drawn by hand from the picture, so some (curved arrows, scrolls, ribbons, callout leaders) are close but not pixel-identical to Word; a shape inside a table cell is removed (TableGrid strips replacement spans); they cannot be resized by dragging, only by font size.
- Code: `ShapeArt.kt` (new), `InsertTab.kt` (`InsertOps.shapeArt`, `ShapesPage`), `RichText.kt` (both readers + writer). Version 1.0.65 (versionCode 66). Written without an Android SDK; run the GitHub "Build APK" action and send me any compiler message.
