package com.msf.documentwriter

import android.graphics.Bitmap
import android.graphics.Canvas as ACanvas
import android.graphics.Paint as APaint
import android.graphics.Path as APath
import android.widget.EditText
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FormatListNumbered
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.NoteAdd
import androidx.compose.material.icons.outlined.TableChart
import androidx.compose.material.icons.outlined.TextFields
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CropLandscape
import androidx.compose.material.icons.outlined.CropPortrait
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.ViewAgenda
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Lets the Insert tab reach the open editor without making the big editor screen even bigger. */
object InsertBridge {
    var et: EditText? = null
}

/** After the header / footer changed: measure the pages again so the text stops above the footer and starts below the header. */
object HfRefresh {
    fun now() {
        Doc.dirty = true
        val et = InsertBridge.et ?: return
        (et.parent as? PageSheets)?.schedule()
        et.invalidate()
    }
}

/** Inserting shapes / comments into the text of the editor. */
object InsertOps {
    fun shape(glyph: String, color: Int, pt: Int = 36): Boolean {
        val et = InsertBridge.et ?: return false
        val pos = maxOf(et.selectionStart, et.selectionEnd).coerceIn(0, et.text.length)
        et.text.insert(pos, glyph)
        Rich.color(et.text, pos, pos + glyph.length, color)
        Rich.size(et.text, pos, pos + glyph.length, pt)
        et.setSelection(pos + glyph.length)
        Doc.dirty = true
        return true
    }

    /** A drawn shape (see ShapeArt): one object character; colour and size are the text colour and size. */
    fun shapeArt(id: String, color: Int, fill: Boolean, pt: Int = 44): Boolean {
        val et = InsertBridge.et ?: return false
        val pos = maxOf(et.selectionStart, et.selectionEnd).coerceIn(0, et.text.length)
        et.text.insert(pos, "\uFFFC")
        et.text.setSpan(ShapeSpan(id, fill), pos, pos + 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        Rich.color(et.text, pos, pos + 1, color)
        Rich.size(et.text, pos, pos + 1, pt)
        et.setSelection(pos + 1)
        Doc.dirty = true
        return true
    }

    /** A text box is a one-cell table. */
    fun textBox(): Boolean {
        val et = InsertBridge.et ?: return false
        val pos = maxOf(et.selectionStart, et.selectionEnd).coerceIn(0, et.text.length)
        val np = Tables.insert(et.text, pos, 1, 1, false, 0)
        decorateBlank(et.text)
        et.setSelection(np.coerceIn(0, et.text.length))
        Doc.dirty = true
        return true
    }

    fun pos(et: EditText) = maxOf(et.selectionStart, et.selectionEnd).coerceIn(0, et.text.length)

    fun plain(text: String): Boolean {
        val et = InsertBridge.et ?: return false
        val p = pos(et)
        et.text.insert(p, text)
        et.setSelection(p + text.length)
        Doc.dirty = true
        return true
    }

    /** "text (url)" in blue with an underline. */
    fun link(label: String, url: String): Boolean {
        val et = InsertBridge.et ?: return false
        val u = url.trim()
        if (u.isEmpty()) return false
        val shown = if (label.isBlank() || label.trim() == u) u else label.trim() + " (" + u + ")"
        val p = pos(et)
        et.text.insert(p, shown)
        Rich.color(et.text, p, p + shown.length, 0xFF1565C0.toInt())
        Rich.underline(et.text, p, p + shown.length)
        et.setSelection(p + shown.length)
        Doc.dirty = true
        return true
    }

    fun comment(text: String): Boolean {
        val et = InsertBridge.et ?: return false
        val t = text.trim()
        if (t.isEmpty()) return false
        val pos = maxOf(et.selectionStart, et.selectionEnd).coerceIn(0, et.text.length)
        val s = "【تبصرہ: $t】"
        et.text.insert(pos, s)
        Rich.highlight(et.text, pos, pos + s.length, 0xFFFFF59D.toInt())
        et.setSelection(pos + s.length)
        Doc.dirty = true
        return true
    }
}

// preview colour on the dark sheet, colour that is really inserted (the white theme is inserted in black so it can be seen)
private val ShapeThemes = listOf(
    Pair(Color.White, 0xFF000000.toInt()),
    Pair(Color(0xFFE07B39), 0xFFE07B39.toInt()),
    Pair(Color(0xFF2BA36A), 0xFF2BA36A.toInt()),
    Pair(Color(0xFF3B8EDB), 0xFF3B8EDB.toInt())
)

@Composable
fun InsRow(icon: ImageVector, label: String, onClick: () -> Unit, extra: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, label, tint = Color(0xFFD0D0D0), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(20.dp))
        Text(label, color = Color.White, fontSize = 19.sp, modifier = Modifier.weight(1f))
        extra()
    }
    Box(Modifier.fillMaxWidth().padding(start = 68.dp).height(1.dp).background(Color(0xFF2E2E2E)))
}

/**
 * The Insert tab: Picture, Text Box, Shapes, Signature, Comment, Table, Blank Page, Page Number.
 * [items] are the editor's own actions (keys are the start of their labels).
 */
@Composable
fun InsertPanel(items: List<Pair<String, () -> Unit>>) {
    val ctx = LocalContext.current
    var sub by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf("") }
    fun act(key: String): () -> Unit = items.firstOrNull { it.first.startsWith(key) }?.second ?: {}
    val attach = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            var name: String? = null
            var size = -1L
            try {
                ctx.contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) { name = c.getString(0); size = c.getLong(1) } }
            } catch (_: Exception) {}
            val n = name ?: u.lastPathSegment ?: "file"
            val kb = if (size > 0) " (" + (if (size >= 1048576) "%.1f MB".format(size / 1048576f) else "${(size + 1023) / 1024} KB") + ")" else ""
            if (InsertOps.plain("📎 $n$kb")) toast(ctx, "فائل کا نام دستاویز میں لکھ دیا گیا / File name added to the document")
        }
    }

    if (sub == "shapes") {
        ShapesPage(onBack = { sub = "" })
    } else {
        Column(Modifier.fillMaxWidth()) {
            InsRow(Icons.Outlined.Image, "Picture", act("Image"))
            InsRow(Icons.Outlined.TextFields, "Text Box", {
                if (InsertOps.textBox()) toast(ctx, "ٹیکسٹ باکس شامل ہو گیا / Text box added") else toast(ctx, "پہلے دستاویز میں کرسر رکھیں / Tap inside the document first")
            })
            InsRow(Icons.Outlined.Category, "Shapes", { sub = "shapes" }) {
                Text("▢   ↘   ○   …", color = Color(0xFF9A9A9A), fontSize = 20.sp)
            }
            InsRow(Icons.Outlined.Edit, "Signature", { dlg = "sign" }) {
                if (Doc.signature != null) Text("✓", color = Color(0xFF4A8BEF), fontSize = 20.sp)
            }
            InsRow(Icons.Outlined.ChatBubbleOutline, "Comment", { dlg = "comment" })
            InsRow(Icons.Outlined.TableChart, "Table", act("Insert table"))
            InsRow(Icons.Outlined.FormatListNumbered, "Page Number", act("Page number"))
            InsRow(Icons.Outlined.CropPortrait, "Header & Footer / ہیڈر اور فُٹر", { dlg = "hf" }) {
                if (Doc.headerText.isNotBlank() || Doc.footerText.isNotBlank()) Text("✓", color = Color(0xFF4A8BEF), fontSize = 20.sp)
            }
            InsRow(Icons.Outlined.Schedule, "Date & Time", { dlg = "date" })
            InsRow(Icons.Outlined.Link, "Hyperlink", { dlg = "link" })
            InsRow(Icons.Outlined.Edit, "Footnote / حوالہ", { dlg = "foot" })
            InsRow(Icons.Outlined.ViewAgenda, "Move Footnote / حوالہ منتقل", { dlg = "footmove" })
            InsRow(Icons.Outlined.ViewAgenda, "Drop Footnote Here / حوالہ یہاں رکھیں", {
                val et = InsertBridge.et
                if (et == null) toast(ctx, "پہلے دستاویز میں کرسر رکھیں / Tap inside the document first")
                else when (FootOps.drop(et)) {
                    0 -> toast(ctx, "حوالہ کرسر کی جگہ رکھ دیا گیا / Footnote dropped at the cursor")
                    2 -> toast(ctx, "کرسر اسی حوالے کے اندر ہے؛ کرسر کسی اور جگہ رکھیں / The cursor is inside the picked-up footnote; put it somewhere else")
                    else -> toast(ctx, "پہلے \"Move Footnote\" میں \"Pick up\" چنیں / First choose \"Pick up\" in Move Footnote")
                }
            })
            InsRow(Icons.Outlined.BookmarkBorder, "Bookmark", {
                if (InsertBridge.et == null) toast(ctx, "پہلے دستاویز میں کرسر رکھیں / Tap inside the document first")
                else toast(ctx, "بُک مارک شامل ہو گیا / Bookmark added: " + ViewOps.addBookmark() + "\nView > All Bookmarks")
            })
            InsRow(Icons.Outlined.AttachFile, "Attachment", { safe(ctx) { attach.launch("*/*") } })
            Box(Modifier.fillMaxWidth().height(10.dp).background(Color(0xFF181818)))
            InsRow(Icons.Outlined.CropPortrait, "Portrait Blank Page", act("Blank page"))
            InsRow(Icons.Outlined.CropLandscape, "Landscape Blank Page", {
                toast(ctx, "پوری دستاویز کا کاغذ Landscape کر دیں / Choose Landscape: it applies to the whole document")
                act("Page setup")()
            })
            InsRow(Icons.Outlined.ViewAgenda, "Page Break", act("New page"))
        }
    }
    when (dlg) {
        "sign" -> SignatureDialog(
            onDone = { dlg = ""; toast(ctx, "دستخط دستاویز کے آخری صفحے پر PDF/Image میں آئے گا / Signature is placed at the end of the last page of the PDF / Image") },
            onCancel = { dlg = "" }
        )
        "comment" -> CommentDialog(
            onOk = { t -> dlg = ""; if (!InsertOps.comment(t)) toast(ctx, "پہلے دستاویز میں کرسر رکھیں / Tap inside the document first") },
            onCancel = { dlg = "" }
        )
        "date" -> DateDialog(onClose = { dlg = "" })
        "link" -> LinkDialog(onClose = { dlg = "" })
        "hf" -> AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("Header & Footer / ہیڈر اور فُٹر") },
            text = {
                Column {
                    Text(
                        "Header / ہیڈر: " + Doc.headerText.ifBlank { "—" }, fontSize = 17.sp,
                        modifier = Modifier.fillMaxWidth().clickable { dlg = "hdr" }.padding(vertical = 14.dp)
                    )
                    Text(
                        "Footer / فُٹر: " + Doc.footerText.ifBlank { "—" }, fontSize = 17.sp,
                        modifier = Modifier.fillMaxWidth().clickable { dlg = "ftr" }.padding(vertical = 14.dp)
                    )
                }
            },
            confirmButton = { TextButton(onClick = { dlg = "" }) { Text("Close") } }
        )
        "hdr", "ftr" -> HeaderDialog(
            onPageNumber = { dlg = ""; HfRefresh.now(); act("Page number")() },
            onDone = { dlg = ""; HfRefresh.now() },
            onCancel = { dlg = "hf" },
            footer = dlg == "ftr"
        )
        "foot" -> FootnoteDialog(onClose = { dlg = "" })
        "footmove" -> FootMoveDialog(onClose = { dlg = "" })
    }
}

@Composable
private fun DateDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val now = java.util.Date()
    val fm = listOf("dd/MM/yyyy", "d MMMM yyyy", "EEEE, d MMMM yyyy", "HH:mm", "dd/MM/yyyy HH:mm", "hh:mm a")
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Date & Time / تاریخ اور وقت") },
        text = {
            Column {
                fm.forEach { f ->
                    val t = java.text.SimpleDateFormat(f, java.util.Locale.getDefault()).format(now)
                    Text(
                        t, fontSize = 17.sp,
                        modifier = Modifier.fillMaxWidth().clickable {
                            if (!InsertOps.plain(t)) toast(ctx, "پہلے دستاویز میں کرسر رکھیں / Tap inside the document first")
                            onClose()
                        }.padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
private fun LinkDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("https://") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Hyperlink / لنک") },
        text = {
            Column {
                OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Text / عبارت") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Address / پتہ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (!InsertOps.link(text, url)) toast(ctx, "پتہ لکھیں اور دستاویز میں کرسر رکھیں / Enter the address and tap inside the document")
                onClose()
            }) { Text("Add / شامل کریں") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
private fun ShapesPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var theme by remember { mutableIntStateOf(0) }
    // "Recently Used Shapes" (kept between sessions, newest first, at most 12)
    val recent = remember {
        mutableStateListOf<String>().also { l ->
            try { Prefs.str(ctx, "shape_recent", "").split("\n").filter { it.isNotEmpty() && ShapeArt.has(it) }.take(12).forEach { l.add(it) } } catch (_: Exception) {}
        }
    }
    var filled by remember { mutableStateOf(false) }
    fun pick(g: String) {
        if (InsertOps.shapeArt(g, ShapeThemes[theme].second, filled)) {
            toast(ctx, "شکل شامل ہو گئی / Shape added")
            recent.remove(g)
            recent.add(0, g)
            while (recent.size > 12) recent.removeAt(recent.size - 1)
            try { Prefs.setStr(ctx, "shape_recent", recent.joinToString("\n")) } catch (_: Exception) {}
        } else toast(ctx, "پہلے دستاویز میں کرسر رکھیں / Tap inside the document first")
    }
    Column(
        Modifier.fillMaxWidth().pointerInput(Unit) {
            var dx = 0f
            detectHorizontalDragGestures(
                onDragStart = { dx = 0f },
                onDragEnd = {
                    if (dx < -80f) theme = minOf(theme + 1, 3)
                    else if (dx > 80f) theme = maxOf(theme - 1, 0)
                },
                onHorizontalDrag = { _, d -> dx += d }
            )
        }
    ) {
        Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clickable { onBack() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.ArrowBack, "Back", tint = Color(0xFFD0D0D0))
            }
            Text("Shapes", color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(52.dp))
        }
        // colour pages (swipe left / right or tap a dot)
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.Center) {
            for (i in 0..3) {
                Box(
                    Modifier.padding(horizontal = 7.dp).size(if (i == theme) 11.dp else 9.dp)
                        .background(if (i == theme) Color(0xFF4A8BEF) else Color(0xFF8E8E8E), CircleShape)
                        .clickable { theme = i }
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.Center) {
            for ((label, f) in listOf("Outline" to false, "Filled" to true)) {
                Text(
                    label, color = if (filled == f) Color.White else Color(0xFF9A9A9A), fontSize = 15.sp,
                    modifier = Modifier.padding(horizontal = 6.dp)
                        .background(if (filled == f) Color(0xFF3B5B99) else Color(0xFF2A2A2A), RoundedCornerShape(14.dp))
                        .clickable { filled = f }.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }
        val col = ShapeThemes[theme].first
        val groups = (if (recent.isEmpty()) emptyList() else listOf("Recently Used Shapes" to recent.toList())) + ShapeArt.groups
        groups.forEach { grp ->
            Box(Modifier.fillMaxWidth().background(Color(0xFF2A3345)).padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(grp.first, color = Color(0xFF9DB9E8), fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(4.dp))
            grp.second.chunked(6).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                    for (i in 0 until 6) {
                        val s = row.getOrNull(i)
                        Box(
                            Modifier.weight(1f).height(52.dp).then(if (s != null) Modifier.clickable { pick(s) } else Modifier),
                            contentAlignment = Alignment.Center
                        ) {
                            if (s != null) {
                                val colInt = col.toArgb()
                                androidx.compose.foundation.Canvas(Modifier.size(40.dp)) {
                                    val asp = ShapeArt.aspect(s)
                                    val side = size.minDimension - 6.dp.toPx()
                                    val w = if (asp > 1f) side else side
                                    val h = if (asp > 1f) side / asp else side
                                    drawIntoCanvas { cv ->
                                        ShapeArt.draw(cv.nativeCanvas, s, (size.width - w) / 2f, (size.height - h) / 2f, w, h, colInt, filled, 1.6.dp.toPx())
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun CommentDialog(onOk: (String) -> Unit, onCancel: () -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Comment / تبصرہ") },
        text = {
            Column {
                Text("تبصرہ کرسر کی جگہ پیلے رنگ میں لکھا جائے گا۔\nThe comment is written at the cursor, highlighted in yellow.", fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = t, onValueChange = { t = it }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(onClick = { onOk(t) }) { Text("Add / شامل کریں") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

/** Draw a signature with the finger; it is stamped at the end of the last page of the PDF / Image. */
@Composable
private fun SignatureDialog(onDone: () -> Unit, onCancel: () -> Unit) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var cur by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var w by remember { mutableIntStateOf(1) }
    var h by remember { mutableIntStateOf(1) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Signature / دستخط") },
        text = {
            Column {
                Text("نیچے انگلی سے دستخط کریں۔\nDraw your signature below.", fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(170.dp).background(Color.White, RoundedCornerShape(8.dp)).border(1.dp, Color(0xFF888888), RoundedCornerShape(8.dp))) {
                    Canvas(
                        Modifier.fillMaxWidth().height(170.dp).onSizeChanged { w = it.width.coerceAtLeast(1); h = it.height.coerceAtLeast(1) }.pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { o -> cur = listOf(o) },
                                onDragEnd = { if (cur.size > 1) strokes.add(cur); cur = emptyList() },
                                onDragCancel = { cur = emptyList() },
                                onDrag = { ch, _ -> cur = cur + ch.position }
                            )
                        }
                    ) {
                        fun draw(pts: List<Offset>) {
                            if (pts.size < 2) return
                            val p = Path()
                            p.moveTo(pts[0].x, pts[0].y)
                            for (i in 1 until pts.size) p.lineTo(pts[i].x, pts[i].y)
                            drawPath(p, Color(0xFF111111), style = Stroke(width = 4.dp.toPx()))
                        }
                        strokes.forEach { draw(it) }
                        draw(cur)
                    }
                }
                if (Doc.signature != null) {
                    TextButton(onClick = { Doc.signature = null; Doc.dirty = true; onCancel() }) { Text("Remove old signature / پرانا دستخط ہٹائیں", color = Color(0xFFD32F2F)) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (strokes.isEmpty()) onCancel() else {
                val bmp = Bitmap.createBitmap(480, (480f * h / w).toInt().coerceAtLeast(60), Bitmap.Config.ARGB_8888)
                val cv = ACanvas(bmp)
                val sc = 480f / w
                val pt = APaint(APaint.ANTI_ALIAS_FLAG).apply {
                    style = APaint.Style.STROKE; strokeWidth = 5f; strokeCap = APaint.Cap.ROUND; strokeJoin = APaint.Join.ROUND
                    color = 0xFF111111.toInt()
                }
                for (s in strokes) {
                    val p = APath()
                    p.moveTo(s[0].x * sc, s[0].y * sc)
                    for (i in 1 until s.size) p.lineTo(s[i].x * sc, s[i].y * sc)
                    cv.drawPath(p, pt)
                }
                Doc.signature = trimSignature(bmp)
                Doc.dirty = true
                onDone()
                }
            }) { Text("Add / شامل کریں") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { strokes.clear(); cur = emptyList() }) { Text("Clear") }
                TextButton(onClick = onCancel) { Text("Cancel") }
            }
        }
    )
}

/** Cuts the empty space around the drawn signature. */
private fun trimSignature(b: Bitmap): Bitmap {
    var l = b.width; var t = b.height; var r = 0; var bt = 0
    val px = IntArray(b.width * b.height)
    b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
    for (y in 0 until b.height) for (x in 0 until b.width) if ((px[y * b.width + x] ushr 24) > 0) {
        if (x < l) l = x; if (x > r) r = x; if (y < t) t = y; if (y > bt) bt = y
    }
    if (r <= l || bt <= t) return b
    val m = 6
    l = (l - m).coerceAtLeast(0); t = (t - m).coerceAtLeast(0)
    r = (r + m).coerceAtMost(b.width - 1); bt = (bt + m).coerceAtMost(b.height - 1)
    return Bitmap.createBitmap(b, l, t, r - l + 1, bt - t + 1)
}
